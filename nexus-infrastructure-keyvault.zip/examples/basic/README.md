# Key Vault Example: Basic

This example shows basic consumption of the Key Vault module. It creates a resource group then deploys the Key Vault module into that resource group.

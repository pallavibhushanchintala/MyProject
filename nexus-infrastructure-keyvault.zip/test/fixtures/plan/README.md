# Plan Generator

This test fixture is used for generating the plan output during the module continuous integration build. It has enough in place to create these items but is not unique/secure enough to actually deploy directly.

A module like this is required so we can override the remote state block in the main module.

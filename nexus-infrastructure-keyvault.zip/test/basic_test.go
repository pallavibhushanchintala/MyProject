package test

import (
	"context"
	"fmt"
	"strings"
	"testing"

	"github.com/Azure/azure-sdk-for-go/services/graphrbac/1.6/graphrbac"
	"github.com/Azure/azure-sdk-for-go/services/keyvault/mgmt/2019-09-01/keyvault"
	"github.com/Azure/go-autorest/autorest"
	"github.com/Azure/go-autorest/autorest/adal"
	"github.com/Azure/go-autorest/autorest/azure"
	"github.com/Azure/go-autorest/autorest/azure/auth"
	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
	uuid "github.com/satori/go.uuid"
	"github.com/stretchr/testify/assert"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

var (
	graphAuthorizer autorest.Authorizer
)

func TestBasicExample(t *testing.T) {
	const exampleDir = "../examples/basic"

	t.Parallel()

	uniqueID := strings.ToLower(random.UniqueId())
	opts := &terraform.Options{
		TerraformDir: exampleDir,

		Vars: map[string]interface{}{
			"location":                 "westus2",
			"resource_group_name_base": fmt.Sprintf("test%s", uniqueID),
			"key_vault_name_base":      fmt.Sprintf("test%s", uniqueID),
		},
	}

	// Deploy the cluster. Setting SKIP_destroy or SKIP_apply will
	// skip the corresponding stage for easier local test development.
	defer stage(t, "destroy", func() { destroy(t, exampleDir) })
	stage(t, "apply", func() { apply(t, exampleDir, opts) })

	// Validate the cluster works. Setting SKIP_validate will skip
	// this so an apply/destroy cycle can be tested without failing
	// on assertions.
	stage(t, "validate", func() { validateBasicExample(t, exampleDir) })
}

func validateBasicExample(t *testing.T, dir string) {
	opts := test_structure.LoadTerraformOptions(t, dir)

	vaultName := terraform.OutputRequired(t, opts, "key_vault_name")
	vaultID := terraform.OutputRequired(t, opts, "key_vault_id")
	vaultURI := terraform.OutputRequired(t, opts, "key_vault_uri")
	resourceGroupName := terraform.OutputRequired(t, opts, "resource_group_name")
	resourceGroupID := terraform.OutputRequired(t, opts, "resource_group_id")

	assert.True(t, strings.Index(vaultID, vaultName) > 0, "The vault ID should include the vault name.")

	// Azure SDK for Go needs environment variables to authenticate and read
	// things from the environment.
	authorizer, err := auth.NewAuthorizerFromEnvironment()
	assert.Nil(t, err)

	// The resource group ID is like
	// /subscriptions/be62f057-87be-48e5-9c5f-c6fc74ac9d19/resourceGroups/testnae62B-zfkvf14i
	// so this is an easy way to get the subscription of the deployed set of
	// resources without having to re-read environment variables.
	subscriptionID := strings.Split(resourceGroupID, "/")[2]

	ctx := context.Background()

	vaultsClient := keyvault.NewVaultsClient(subscriptionID)
	vaultsClient.Authorizer = authorizer
	vault, err := vaultsClient.Get(ctx, resourceGroupName, vaultName)
	assert.Nil(t, err)
	assert.NotNil(t, vault)
	assert.Equal(t, vaultID, *vault.ID, "The vault ID was not what the module claimed.")
	assert.Equal(t, vaultURI, *vault.Properties.VaultURI, "The vault URI was not what the module claimed.")
	assert.Equal(t, keyvault.SkuName("standard"), (*(vault.Properties).Sku).Name, "The SKU should default to standard.")

	// Settings required for CMK to work.
	assert.True(t, *vault.Properties.EnabledForDiskEncryption, "The vault was not enabled for disk encryption.")
	assert.True(t, *vault.Properties.EnableSoftDelete, "The vault was not enabled for soft delete.")
	assert.True(t, *vault.Properties.EnablePurgeProtection, "The vault was not enabled for purge protection.")

	// Access policy setup.
	foundCosmosPrincipal := false
	assert.Equal(t, 2, len(*vault.Properties.AccessPolicies), "Two access policies should have been created - one for the deployment account, one for Cosmos DB.")
	for _, policy := range *vault.Properties.AccessPolicies {
		principalClient := getGraphClient(policy.TenantID)
		principal, err := principalClient.Get(ctx, fmt.Sprintf("%s", *policy.ObjectID))

		// Find the well-known app name/ID.
		if err == nil && *principal.DisplayName == "Azure Cosmos DB" && *principal.AppID == "a232010e-820c-4083-83bb-3ace5fc29d0b" {
			foundCosmosPrincipal = true
			break
		}
	}
	assert.True(t, foundCosmosPrincipal, "The Cosmos DB principal should have had a policy assigned.")
}

func getGraphClient(tenantID *uuid.UUID) graphrbac.ServicePrincipalsClient {
	principalClient := graphrbac.NewServicePrincipalsClient(fmt.Sprintf("%s", tenantID))
	a, _ := getGraphAuthorizer()
	principalClient.Authorizer = a
	return principalClient
}

// Logic from Azure SDK example:
// https://github.com/Azure-Samples/azure-sdk-for-go-samples/blob/ffcdafe9818d55dbc2134db1548e1ed10b4a6092/internal/iam/authorizers.go#L91
// It seems you need a token specifically for AAD graph; you can't just use the
// same standard authorizer as the management API uses.
func getGraphAuthorizer() (autorest.Authorizer, error) {
	if graphAuthorizer != nil {
		return graphAuthorizer, nil
	}

	cloudName := "AzurePublicCloud"
	env, err := azure.EnvironmentFromName(cloudName)
	if err != nil {
		panic(fmt.Sprintf("invalid cloud name '%s' specified, cannot continue\n", cloudName))
	}

	settings, err := auth.GetSettingsFromEnvironment()
	if err != nil {
		panic("invalid settings in environment, cannot continue")
	}

	oauthConfig, err := adal.NewOAuthConfig(env.ActiveDirectoryEndpoint, settings.Values[auth.TenantID])
	if err != nil {
		return nil, err
	}

	token, err := adal.NewServicePrincipalToken(*oauthConfig, settings.Values[auth.ClientID], settings.Values[auth.ClientSecret], env.GraphEndpoint)
	if err != nil {
		return nil, err
	}

	a := autorest.NewBearerAuthorizer(token)
	return a, nil
}

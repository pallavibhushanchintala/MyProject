context.setVariable("jwt_client_id", context.getVariable("apigee.client_id"));
context.setVariable("jwt_tid", context.getVariable("app.tenantId"));
context.setVariable("jwt_scp", context.getVariable("oauthv2accesstoken.get-access-token-scopes.scope"));

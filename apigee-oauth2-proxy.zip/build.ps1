﻿$artifactsFolder = Join-Path $PSScriptRoot "artifacts"
If (Test-Path $artifactsFolder) {
    Write-Host "Cleaning artifacts folder."
    Remove-Item $artifactsFolder -Recurse -Force
}

Write-Host "Creating artifacts folder."
New-Item $artifactsFolder -Force -ItemType Directory | Out-Null

Write-Host "Building proxy zip file."
$apiProxyArchive = Join-Path $artifactsFolder "dsl-authentication.zip"
$apiProxySource = Join-Path $PSScriptRoot "apiproxy"
Compress-Archive -Path $apiProxySource -DestinationPath $apiProxyArchive

Write-Host "Done."

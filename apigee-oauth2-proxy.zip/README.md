# Apigee: OAuth2 Proxy Flow

This Apigee API proxy provides the `client_credentials` token issuance support for the [Day One Apigee identity provider mechanism](https://dev.azure.com/F-DC/Digital%20Nexus/_wiki/wikis/architecture/604/Apigee-as-an-OAuth2-Identity-Provider). It isn't intended to be a full-fledged identity provider/token issuance mechanism; it's a stop-gap until we get a full identity provider in place.

You can tell it's a `client_credentials` token because it will not have a `sub` claim and will have a `client_id` claim with the ID of the application that authenticated.

## Build

The build right now is manual while we work on an automated pipeline. It generates an `apiproxy.zip` for upload to Apigee.

```powershell
./build.ps1
```

## Deploy

Deployment occurs via the automated pipeline. The proxy will get packaged up and deployed as part of any commit to `main`.

> :warning: The signing key information is _not_ checked in here and is _not_ part of this proxy, but it is consumed by the access token generation process. Be sure to deploy `dsl-jwt-privatekey` with `private-key` and `private-key-password` values _and_ `dsl-jwt` with a `public-key` value to the Admin/Environments/Key Value Maps section or things won't work. Not everyone has the ability to create key value maps at the global level so you may need help with this.

After it's deployed, you can look at it in the Apigee UI.

1. Log into [Apigee Edge](https://apigee.com/edge).
2. Select the organization and environment into which the proxy was deployed. These are variables in the deployment pipeline.
3. Expand the Develop/API Proxies tab.
4. Search for `dsl-authentication` - that's the proxy.

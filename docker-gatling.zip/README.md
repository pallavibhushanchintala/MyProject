# Gatling Base Container

This builds Gatling runner containers that also support Istio. This is required so the Gatling tests can run and then terminate the Istio Envoy sidecar, otherwise the container is seen as failed and will never finish to return results.

- [`denvazh/gatling` container](https://github.com/denvazh/gatling)
- [Gatling download](https://gatling.io/open-source/)

## Usage

The container works just like the `denvazh/gatling` container but has extra work in the entrypoint such that in an environment where Kubernetes is detected, the `quitquitquit` endpoint on the Istio Envoy container will be called when the tests are done.

```powershell
docker run -it --rm digitalnexus.azurecr.io/digital-nexus/gatling
```

Mount configuration and simulation files from the host machine and run gatling in interactive mode

```powershell
# Docker doesn't like Windows path separators.
$current = $pwd -replace '\\','/'

# Run the container and mount the locations you need.
docker run -it --rm `
  -v $current/gatling/conf:/opt/gatling/conf `
  -v $current/gatling/user-files:/opt/gatling/user-files `
  -v $current/gatling/results:/opt/gatling/results `
  digitalnexus.azurecr.io/digital-nexus/gatling

# If you want to try the local test simulations, mount those.
docker run -it --rm `
  -v $current/test:/opt/gatling/user-files `
  digitalnexus.azurecr.io/digital-nexus/gatling
```

Use the `-e` switch to use `JAVA_OPTS` or to pass parameters to Gatling tests via the environment.

```powershell
docker run `
  -e JAVA_OPTS="-Djava.awt.headless=true" `
  -it --rm `
  digitalnexus.azurecr.io/digital-nexus/gatling
```

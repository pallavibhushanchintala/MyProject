package gatling.container.loadtest

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class DemoSimulation extends Simulation {
  val httpConf = http
    .baseUrl("http://httpbin.org")
    .acceptHeader("*/*")
    .acceptEncodingHeader("gzip, deflate")
    .userAgentHeader("Gatling/2.0");

  val scn1 = scenario("Success")
    .exec(http("Get 200")
      .get("/status/200"))
    .pause(5)

  setUp(scn1.inject(constantUsersPerSec(1) during (10 seconds)).protocols(httpConf))
}

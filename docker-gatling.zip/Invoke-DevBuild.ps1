﻿<#
.SYNOPSIS
    Cleans the local environment and runs a local dev build to test container
    changes.
.DESCRIPTION
    Cleans the local environment using `git clean -dfx` - all local files not
    controlled by git will be removed! This is to allow any state, packages,
    etc. to be controlled by the local container.

    Builds and tests a local version of the container. Represents a smaller
    version of what happens in the matrix pipeline.
.PARAMETER GatlingVersion
    The version of Gatling to put in the test container.
.EXAMPLE
    ./Invoke-DevBuild.ps1
.EXAMPLE
    ./Invoke-DevBuild -GatlingVersion 3.8.4
.EXAMPLE
    ./Invoke-DevBuild -GatlingVersion 3.8.4 -SkipClean
#>
[CmdletBinding()]
Param(
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]
    $GatlingVersion = "3.8.4",

    [Parameter()]
    [Switch]
    $SkipClean
)

If (-Not $SkipClean) {
    &git clean -dfx
}

$tag = "gatling-local"
&docker build -t $tag --build-arg GATLING_VERSION=$GatlingVersion --build-arg GIT_COMMIT=local --build-arg GIT_REPO=local .

New-Item "artifacts/log" -ItemType Directory -Force
$logDir = (Join-Path -Path $PSScriptRoot -ChildPath "artifacts/log") -replace '\\', '/'
$testDir = (Join-Path -Path $PSScriptRoot -ChildPath "test") -replace '\\', '/'
&docker run --rm `
    -v $testDir`:/opt/gatling/user-files `
    -v $logDir`:/opt/gatling/results `
    $tag `
    -s gatling.container.loadtest.DemoSimulation -nr

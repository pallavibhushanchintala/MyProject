#!/bin/sh
# The test container finishes but the Istio sidecar stays alive so we have to
# manually exit or the job never finishes. To support local running, we only do
# this if the Kubernetes service account mount is present.
# https://github.com/istio/istio/issues/11659
if [ -d "/var/run/secrets/kubernetes.io/serviceaccount" ]; then
  echo "Running in Kubernetes context, will end Istio sidecar when finished."
  trap "echo \"Telling Envoy sidecar to exit...\";curl --max-time 2 -f -XPOST http://127.0.0.1:15020/quitquitquit" EXIT
  while ! curl -s -f http://127.0.0.1:15020/healthz/ready; do
    echo "Waiting for Envoy sidecar ready..."
    sleep 1;
  done
else
  echo "No Kubernetes service account detected; skipping Istio sidecar handling."
fi

# Because java emits warnings to stderr,
# redirect stderr to stdout for the gatling run.
gatling.sh "$@" 2>&1

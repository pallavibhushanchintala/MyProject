# Cron Job Helm Templates

Helm template for deploying a cron job to a Kubernetes cluster using Istio. This is used via `helm template` during continuous deployment, not deployed as an infrastructure package.

A typical run basically provides the image name and Git hash tag. Note the tag usually gets injected by the build pipeline based on commit info. That can be done via an `overrides.yaml` file as shown earlier, or via command line directly:

```powershell
helm template my-cronjob oci://digitalnexus.azurecr.io/helm/cronjob-deployment `
  --namespace banking `
  --set image.repository=digitalnexus.azurecr.io/digital-nexus/cronjob/job `
  --set image.tag=git-hash-tag-here
```

A very simple cronjob deployment might look like this (note: this does not handle shutting down the Istio sidecar!)

```yaml
image:
  repository: busybox
  tag: latest

cronjob:
  schedule: "0,5,10,15,20,25,30,35,40,45,50,55 * * * *"
  ttlSecondsAfterFinished: 120
  command:
  - /bin/sh
  - -c
  - date; echo Hello from the Kubernetes cluster
```

You can [generate crontab schedule strings at `crontab.guru`](https://crontab.guru/).

> :warning: **All jobs need to be aware of the Istio sidecar and be able to shut it down if it's present.** If you don't shut down the sidecar, the job will never be seen as complete.

An example of an `entrypoint.sh` script for a job might look like this:

```sh
if [ -d "/var/run/secrets/kubernetes.io/serviceaccount" ]; then
  echo "Running in Kubernetes context, will end Istio sidecar when finished."
  trap "echo \"Telling Envoy sidecar to exit...\";curl --max-time 2 -f -XPOST http://127.0.0.1:15020/quitquitquit" EXIT
  while ! curl -s -f http://127.0.0.1:15020/healthz/ready; do
    echo "Waiting for Envoy sidecar ready..."
    sleep 1;
  done
else
  echo "No Kubernetes service account detected; skipping Istio sidecar handling."
fi

your-real-entrypoint.sh "$@" 2>&1
```

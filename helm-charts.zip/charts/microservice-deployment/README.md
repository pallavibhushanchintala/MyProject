# Microservice Deployment Template

Helm template for deploying a microservice to a Kubernetes cluster using Istio. This is used via `helm template` during continuous deployment, not deployed as an infrastructure package.

A typical run basically provides the image name and Git hash tag. Note the tag usually gets injected by the build pipeline based on commit info. That can be done via an `overrides.yaml` file as shown earlier, or via command line directly:

```powershell
helm template my-service oci://digitalnexus.azurecr.io/helm/microservice-deployment `
  --namespace banking `
  --set image.repository=digitalnexus.azurecr.io/digital-nexus/myservice/service `
  --set image.tag=git-hash-tag-here
```

# k6 Load Test Helm Template

Helm template for executing a Kubernetes job that runs k6 load tests. This is used via `helm template` during continuous deployment, not deployed as an infrastructure package.

A typical run basically provides the service name, Git hash tag, and environment variables required for testing. That can be done via an `overrides.yaml` file as shown earlier, or via command line directly:

```powershell
helm template load-test oci://digitalnexus.azurecr.io/helm/k6-job-deployment `
  --namespace banking `
  --set service=banking/accounts `
  --set image.tag=git-hash-tag-here `
  --set env[0].name=CLIENT_ID `
  --set env[0].value=client-id-here `
  --set env[1].name=CLIENT_SECRET `
  --set env[1].value=client-secret-here
```

# Digital Nexus: Helm Charts and Templates

This repo holds the DBP-specific Helm charts and templates used for deploying services.

If you are looking for the Helm charts that deploy cluster infrastructure, those are [over here](https://dev.azure.com/F-DC/Infrastructure/_git/helm-charts).

## Consuming Deployment Templates

Charts/deployment templates are published as [OCI artifacts to Azure Container Registry](https://helm.sh/docs/topics/registries/). Deployment templates are not actually _installed_ like a standard Helm chart, though; instead, they're used via `helm template` to create a template for continuous deployment. This is because continuous deployment has additional features (like canary deployment and lack of semantic versioning) that make it incompatible with the standard concept of a Helm deployment.

To consume a deployment template, the basic steps are:

- Authenticate to the registry using Helm. The `Mount-HelmAcr.ps1` script in this repo can help with that if you're testing interactively.
- Pull the chart that you want to use as a template.
- Use `helm template` to generate the full deployment.
- Use `kubectl apply` to deploy the templated files.

In a real deployment pipeline, some of these things get done by Azure DevOps tasks rather than manual execution. For example, the `kubectl apply` is done by the canary deployment task because it also controls labels and load balancing.

A local test might look like:

```powershell
# Connect to Azure Container Registry with Helm.
./Mount-HelmAcr.ps1

# Use helm template with some values to see what happens. If you want a specific chart version, add --version to the arguments.
helm template test `
  oci://digitalnexus.azurecr.io/helm/background-service-deployment `
  --set image.repository=my-image `
  --set image.tag=0.1.2
```

In a deployment template, you'll have some tasks to execute. This is an abbreviated pipeline showing some of the things you'll need to do. **Our Azure DevOps build pipeline templates handle all this for you** but in the event you need to work with templates in a custom fashion, this is provided as explanation.

```yaml
variables:
  # You need a service account that can authenticate to the Azure Container Registry.
  azureSubscription: "ARM 35abf82e-a23b-49c4-8bae-88baead6f7d3"

  # This is the registry (digitalnexus.azurecr.io) where the charts are stored.
  registryName: "digitalnexus"

stages:
  - stage: "build"
    jobs:
      - job: "build"
        steps:
          # Get the latest Helm.
          - task: HelmInstaller@1
            inputs:
              helmVersionToInstall: 'latest'
          # Authenticate to ACR with Helm and bake the manifest all in one task.
          # Once the AzureCLI task exits, it logs out and clears the credentials.
          - task: AzureCLI@2
            inputs:
              azureSubscription: $(azureSubscription)
              scriptType: pscore
              addSpnToEnvironment: true
              scriptLocation: inlineScript
              inlineScript: |
                $username = $env:servicePrincipalId
                $password = $env:servicePrincipalKey
                helm registry login $(registryName).azurecr.io --username $username --password $password
                helm template my-deployment `
                  oci://$(registryName).azurecr.io/helm/background-service-deployment `
                  -n my-namespace `
                  -f my-values.yaml > manifest-bundle.yaml
          # Deploy the manifest that was baked in the previous step.
          - task: KubernetesManifest@0
            inputs:
              action: deploy
              namespace: my-namespace
              manifests: manifest-bundle.yaml
```

## Developing Charts

### Tools

You'll need...

- [PowerShell Core](https://github.com/PowerShell/PowerShell)
- [Helm 3.8+](https://github.com/helm/helm)

There is some extra support in here if you're working with VS Code. For example, there are recommended extensions like `redhat.vscode-yaml` that can help add validation from [the JSON schema store](http://schemastore.org/api/json/catalog.json) to YAML files you work with.

On Mac, Homebrew has all the stuff you need to get going:

```powershell
brew cask install powershell
brew install helm
```

On Windows you can use [winget](https://learn.microsoft.com/en-us/windows/package-manager/winget/) to install PowerShell Core and [Chocolatey](https://chocolatey.org/install) for installing Helm:

```powershell
winget install Microsoft.PowerShell
choco install kubernetes-helm
```

### Build

The `build.ps1` script will execute Helm linting and packaging for all the Helm charts in the repository.

The VS Code integration will run this script as the default build action. However, `helm lint` doesn't make it easy to create a problem matcher (an [issue has been created](https://github.com/helm/helm/issues/11365) for that) so the Problems window won't necessarily link you right to the file with the problem.

### Making Changes

Charts - including charts that are used as deployment templates rather than as infrastructure deployment - are versioned in the `Chart.yaml`. If you update the chart, you need to update the semantic version in there. **The build does not stop you from stomping an existing version of the chart with a changed version.** Each chart is independently versioned; it's not controlled from a central build.

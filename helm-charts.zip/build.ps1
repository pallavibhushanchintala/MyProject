﻿<#
.SYNOPSIS
    Builds the Helm chart repo.
.DESCRIPTION
    Executes Helm chart validation and packaging for all charts in the `charts` folder.
.EXAMPLE
    ./build.ps1

    Executes the build.
.EXAMPLE
    ./build.ps1 -Verbose

    Executes the build with additional logging.
#>
[CmdletBinding(SupportsShouldProcess = $False)]
Param(
)

Process {
    If ($Env:BUILD_ARTIFACTSTAGINGDIRECTORY) {
        $artifactsPath = $Env:BUILD_ARTIFACTSTAGINGDIRECTORY
        Write-Verbose "Executing on build server. Artifacts will go to $artifactsPath."
    }
    Else {
        $artifactsPath = Join-Path $PSScriptRoot "artifacts"
        Write-Verbose "Executing in local development. Artifacts will go to $artifactsPath."
        If (Test-Path "$artifactsPath") {
            Remove-Item "$artifactsPath" -Force -Recurse | Out-Null
        }
        New-Item "$artifactsPath" -ItemType Directory | Out-Null
    }

    $chartsPath = Join-Path $PSScriptRoot "charts"
    Get-ChildItem "$chartsPath" -Directory | ForEach-Object {
        $name = $_.Name
        $path = $_.FullName

        Write-Verbose "Linting chart: $name"
        If ($VerbosePreference -eq 'SilentlyContinue') {
            $quietPreference = "--quiet"
        }

        helm lint "$path" $quietPreference --strict --with-subcharts
        If ($LASTEXITCODE -ne 0) {
            throw "Chart $name failed linting."
        }

        Write-Verbose "Packaging chart: $name"
        helm package "$path" -d "$artifactsPath"
        If ($LASTEXITCODE -ne 0) {
            throw "Chart $name failed packaging."
        }
    }
}

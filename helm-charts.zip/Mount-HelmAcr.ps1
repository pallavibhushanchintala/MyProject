﻿<#
.SYNOPSIS
    Authenticate to Azure Container Registry using Helm.
.DESCRIPTION
    Enables OCI support in Helm via environment variable, then attempts to
    authenticate with the container registry using Helm so charts can be
    accessed.

    The `az` CLI is required if you authenticate as a standard user (not a
    service account) so a token can be retrieved for ACR login.
.PARAMETER Username
    The username to use for authentication. If you're logging in as yourself,
    omit this parameter - the value will come from the `az` CLI.
.PARAMETER Password
    The password/token to use for authentication. If you're logging in as
    yourself, omit this parameter - the value will come from the `az` CLI. If
    you provide a username but no password, you'll be prompted to enter a
    password.
.PARAMETER AcrName
    The name of the container registry storing Helm charts.
.EXAMPLE
    ./Mount-HelmAcr.ps1

    Authenticate as a user where the ACR token can be retrieved via the az CLI.
.EXAMPLE
    ./Mount-HelmAcr.ps1 -Username $serviceAccountId -Password $serviceAccountKey

    Authenticate as a service account as part of a build.
#>
[CmdletBinding(SupportsShouldProcess = $False)]
[OutputType([int])]
Param(
    [Parameter(Mandatory = $True, ParameterSetName = "ProvidedCredentials")]
    [ValidateNotNullOrEmpty()]
    [string]
    $Username,

    [Parameter(Mandatory = $True, ParameterSetName = "ProvidedCredentials")]
    [ValidateNotNullOrEmpty()]
    [SecureString]
    $Password,

    [Parameter(ParameterSetName = "ProvidedCredentials")]
    [Parameter(ParameterSetName = "InferredCredentials")]
    [ValidateNotNullOrEmpty()]
    [string]
    $AcrName = "digitalnexus.azurecr.io"
)

# The logic in the script automates what's specified in the docs:
# https://learn.microsoft.com/en-us/azure/container-registry/container-registry-helm-repos#authenticate-with-the-registry
Begin {
    $helm = Get-Command "helm" -ErrorAction Ignore | Select-Object -ExpandProperty Source
    If ($Null -eq $helm) {
        throw "Helm was not found. This is required for inferred credentials."
    }

    $version = & "$helm" version --template='{{.Version}}'
    $version = New-Object -TypeName "System.Version" -ArgumentList $version.TrimStart('v')

    # OCI support became standard in Helm 3.8.0
    # https://helm.sh/docs/topics/registries/
    $minimumVersion = New-Object -TypeName "System.Version" -ArgumentList "3.8.0"
    If ($version -le $minimumVersion) {
        throw "You have Helm version $version installed. You must have at least $minimumVersion to support OCI registries."
    }

    If ($PSCmdlet.ParameterSetName -eq "InferredCredentials") {
        $az = Get-Command "az" -ErrorAction Ignore
        If ($Null -eq $az) {
            throw "The az command line was not found. This is required for inferred credentials."
        }

        Write-Verbose "az command line found."
        $az = $az.Source
    }
}

Process {
    If (-not $AcrName.EndsWith("azurecr.io", [System.StringComparison]::OrdinalIgnoreCase)) {
        $AcrName = "$AcrName.azurecr.io"
    }

    If ($PSCmdlet.ParameterSetName -eq "InferredCredentials") {
        # Username is always empty GUID for token-based user auth.
        $Username = "00000000-0000-0000-0000-000000000000"

        Write-Verbose "Getting token for $AcrName."
        $PlaintextPassword = & "$az" acr login --name $AcrName --expose-token --output tsv --query accessToken --only-show-errors
    }
    Else {
        $PlaintextPassword = ConvertFrom-SecureString -SecureString $Password -AsPlainText
    }

    Write-Verbose "Using $helm to authenticate to $AcrName as $Username."
    & "$helm" registry login $AcrName --username $Username --password $PlaintextPassword
}

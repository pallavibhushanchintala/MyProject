using Fiserv.Accounts.Service.Controllers;
using Fiserv.Accounts.Service.Data;

namespace Fiserv.Accounts.Service.Test.Controllers;

public class DocumentExtensionsTests
{
    [Theory]
    [InlineData(null)]
    [InlineData("user")]
    public void UserHasAccess_NullDocument(string userId)
    {
        Assert.False(DocumentExtensions.UserHasAccess(null, userId));
    }

    [Theory]
    [CombinatorialData]
    public void UserHasAccess_ActAsApplication(bool hasUsers)
    {
        var document = new Account();
        if (hasUsers)
        {
            document.Users = new string[] { "user" };
        }

        Assert.True(document.UserHasAccess(null));
    }

    [Fact]
    public void UserHasAccess_ActAsUser_NullUserList()
    {
        var document = new Account
        {
            Users = null,
        };

        Assert.False(document.UserHasAccess("user"));
    }

    [Fact]
    public void UserHasAccess_ActAsUser_UserInList()
    {
        var document = new Account
        {
            Users = new string[] { "user" },
        };

        Assert.True(document.UserHasAccess("user"));
    }

    [Fact]
    public void UserHasAccess_ActAsUser_UserIdIsCaseSensitive()
    {
        var document = new Account
        {
            Users = new string[] { "USER" },
        };

        Assert.False(document.UserHasAccess("user"));
    }

    [Fact]
    public void UserHasAccess_ActAsUser_UserNotInList()
    {
        var document = new Account
        {
            Users = new string[] { "other-user" },
        };

        Assert.False(document.UserHasAccess("user"));
    }
}

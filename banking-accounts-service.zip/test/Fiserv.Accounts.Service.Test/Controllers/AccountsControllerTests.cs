﻿using System.Security.Claims;
using System.Text.Json;
using AutoMapper;
using Fiserv.Accounts.Service.Controllers;
using Fiserv.Accounts.Service.Models;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Repo = Fiserv.Accounts.Service.Data;

namespace Fiserv.Accounts.Service.Test.Controllers;

public class AccountsControllerTests
{
    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    };

    [Fact]
    public void Ctor_NullDataService()
    {
        var logger = Mock.Of<ILogger<AccountsController>>();
        var mapper = Mock.Of<IMapper>();
        Assert.Throws<ArgumentNullException>(() => new AccountsController(logger, null, mapper));
    }

    [Fact]
    public void Ctor_NullLogger()
    {
        var dataService = Mock.Of<IDataRepository>();
        var mapper = Mock.Of<IMapper>();
        Assert.Throws<ArgumentNullException>(() => new AccountsController(null, dataService, mapper));
    }

    [Fact]
    public void Ctor_NullMapper()
    {
        var logger = Mock.Of<ILogger<AccountsController>>();
        var dataService = Mock.Of<IDataRepository>();
        Assert.Throws<ArgumentNullException>(() => new AccountsController(logger, dataService, null));
    }

    [Fact]
    public void Ctor_SetsDependencies()
    {
        var logger = Mock.Of<ILogger<AccountsController>>();
        var dataService = Mock.Of<IDataRepository>();
        var mapper = Mock.Of<IMapper>();
        var controller = new AccountsController(logger, dataService, mapper);
        Assert.Same(logger, controller.Logger);
        Assert.Same(dataService, controller.DataService);
        Assert.Same(mapper, controller.Mapper);
    }

    [Fact]
    public async Task GetAccountByIdAsync_NotFound()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.GetAccountByIdAsync("does-not-exist", null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(404, response.StatusCode);
    }

    [Fact]
    public async Task GetAccountsAsync_GetsAccountsForUserWithAccounts()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.GetAccountsAsync(StubDataPopulator.UserId);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<AccountResponse>>(response);
        Assert.Equal(3, content.Count());
    }

    [Fact]
    public async Task GetAccountsAsync_GetsAccountsForUserWithoutAccounts()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.GetAccountsAsync("no-accounts");
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<AccountResponse>>(response);
        Assert.Empty(content);
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_AccountNotFound()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.GetBalancesByAccountIdAsync("does-not-exist", null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(404, response.StatusCode);
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_AccountWithBalances()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var id = await GetValidAccountIdForUserAsync(controller);
        var expected = (await controller.DataService.GetAccountsAsync(StubDataPopulator.UserId, StubDataPopulator.TenantId)).First(x => x.AccountType == "CHECKING");
        var result = await controller.GetBalancesByAccountIdAsync(expected.AccountId, StubDataPopulator.UserId);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<Balance>>(response);
        Assert.Equal(2, content.Count());
        Assert.All(content, item => Assert.Equal(item.AccountId, id));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_AccountNotFound()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.GetProductsByAccountIdAsync("does-not-exist", null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(404, response.StatusCode);
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_Success()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var id = await GetValidAccountIdForUserAsync(controller);
        var expected = (await controller.DataService.GetAccountsAsync(StubDataPopulator.UserId, StubDataPopulator.TenantId)).First(x => x.AccountType == "CHECKING");
        var result = await controller.GetProductsByAccountIdAsync(expected.AccountId, StubDataPopulator.UserId);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<ProductResponse>>(response);
        Assert.Equal(3, content.Count());
        Assert.All(content, item => Assert.Equal(item.AccountId, id));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_AccountNotFound()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.GetTransactionsByAccountIdAsync("does-not-exist", null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(404, response.StatusCode);
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_EffectiveDateFallsBackToPostedDate()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();

        var repository = controller.DataService as MemoryRepository;
        var account = await repository.UpsertAccountAsync(
            new Repo.Account
            {
                AccountType = "CD",
                AlternateIdentifiers = new List<Repo.AlternateIdentifier>
                {
                    new Repo.AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Number = Guid.NewGuid().ToString(),
            },
            StubDataPopulator.TenantId);

        await repository.AddTransactionAsync(
            new Repo.Transaction
            {
                AccountId = account.Id,
                Amount = new Repo.Amount { CurrencyCode = "USD", Value = 5.49 },

                // Importer may fail to put effective time in.
                EffectiveDateTime = null,
                PostedDateTime = DateTimeOffset.Now,
            },
            StubDataPopulator.TenantId);

        var result = await controller.GetTransactionsByAccountIdAsync(account.Id, null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<Transaction>>(response);
        Assert.Single(content);
        var transaction = content.First();

        // Verify we got the right transaction back
        Assert.Equal(account.Id, transaction.AccountId);
        Assert.Equal(5.49, transaction.Amount.Value);

        // Verify effective time was populated
        Assert.NotEqual(DateTimeOffset.MinValue, transaction.EffectiveDateTime);
        Assert.Equal(transaction.PostedDateTime, transaction.EffectiveDateTime);
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_Success()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var id = await GetValidAccountIdForUserAsync(controller);
        var expected = (await controller.DataService.GetAccountsAsync(StubDataPopulator.UserId, StubDataPopulator.TenantId)).First(x => x.AccountType == "CHECKING");
        var result = await controller.GetTransactionsByAccountIdAsync(expected.AccountId, StubDataPopulator.UserId);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<Transaction>>(response);
        Assert.Equal(2, content.Count());
        Assert.All(content, item => Assert.Equal(item.AccountId, id));
    }

    [Fact]
    public async Task SearchForAccountAsync_MultipleMatches()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();

        var repository = controller.DataService as MemoryRepository;

        // Upsert 3 accounts that are all CD. Note we're executing as an
        // application so we should get all the results.
        await repository.UpsertAccountAsync(
            new Repo.Account
            {
                AccountType = "CD",
                AlternateIdentifiers = new List<Repo.AlternateIdentifier>
                {
                    new Repo.AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Number = Guid.NewGuid().ToString(),
            },
            StubDataPopulator.TenantId);
        await repository.UpsertAccountAsync(
            new Repo.Account
            {
                AccountType = "CD",
                AlternateIdentifiers = new List<Repo.AlternateIdentifier>
                {
                    new Repo.AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Number = Guid.NewGuid().ToString(),
            },
            StubDataPopulator.TenantId);
        await repository.UpsertAccountAsync(
            new Repo.Account
            {
                AccountType = "CD",
                AlternateIdentifiers = new List<Repo.AlternateIdentifier>
                {
                    new Repo.AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Number = Guid.NewGuid().ToString(),
            },
            StubDataPopulator.TenantId);

        var searchRequest = new AccountBase
        {
            AccountType = AccountType.CD,
        };

        var result = await controller.SearchForAccountAsync(searchRequest, null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<AccountResponse>>(response);
        Assert.Equal(3, content.Count());
    }

    [Fact]
    public async Task SearchForAccountAsync_SingleMatch()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var toFind = await GetValidAccountForUserAsync(controller);
        var searchRequest = new AccountBase
        {
            AccountType = Enum.Parse<AccountType>(toFind.AccountType),
            AlternateIdentifiers = new List<AlternateIdentifier>
            {
                new AlternateIdentifier
                {
                    Id = toFind.AlternateIdentifiers.First(x => x.Scheme == AlternateIdentifierScheme.RoutingTransitNumber).Id,
                    Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                },
            },
            Number = toFind.Number,
        };

        var result = await controller.SearchForAccountAsync(searchRequest, null);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<IEnumerable<AccountResponse>>(response);
        Assert.Single(content);
        Assert.Equal(toFind.Id, content.First().Id);
    }

    [Fact]
    public async Task UpdateProductsByAccountIdAsync_AccountNotFound()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.UpdateProductsByAccountIdAsync("not-found", new List<ProductBase>());
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(404, response.StatusCode);
    }

    [Fact]
    public async Task UpdateProductsByAccountIdAsync_ProductsUpdated()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();

        var repository = controller.DataService as MemoryRepository;
        var account = await repository.UpsertAccountAsync(
            new Repo.Account
            {
                AccountType = "CD",
                AlternateIdentifiers = new List<Repo.AlternateIdentifier>
                {
                    new Repo.AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Number = Guid.NewGuid().ToString(),
            },
            StubDataPopulator.TenantId);

        var products = new ProductBase[]
        {
            new ProductBase
            {
                Scheme = "Scheme",
                Value = "Value",
            },
        };

        var result = await controller.UpdateProductsByAccountIdAsync(account.Id, products);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);

        var content = GetResponseContent<IEnumerable<ProductResponse>>(response);
        Assert.Single(content);
    }

    [Fact]
    public async Task UpsertAccountAsync_EmptyAlternateIdentifiers()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var putRequest = CreateAccountPutRequest(1);
        putRequest.AlternateIdentifiers = Array.Empty<AlternateIdentifier>();
        var result = await controller.UpsertAccountAsync(putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(422, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountAsync_NullAlternateIdentifiers()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var putRequest = CreateAccountPutRequest(1);
        putRequest.AlternateIdentifiers = null;
        var result = await controller.UpsertAccountAsync(putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(422, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountAsync_RepositoryValidationFailure()
    {
        // The `AccountPutRequest` has data validation on it to ensure the
        // number and type are there; and we have tests to verify that the
        // alternate identifiers are present. However, if somehow any of that
        // slips through, the repository will also verify that the "magic
        // trinity" is available and will fail to write if it's not.
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var putRequest = CreateAccountPutRequest(1);

        // This is the part that would normally be caught by data validation.
        putRequest.Number = null;

        var result = await controller.UpsertAccountAsync(putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(422, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountAsync_InitialCreation()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var putRequest = CreateAccountPutRequest(1);
        var result = await controller.UpsertAccountAsync(putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<AccountResponse>(response);
        Assert.NotNull(content.Id);
        Assert.Equal(putRequest.Number, content.Number);
    }

    [Fact]
    public async Task UpsertAccountAsync_OverwriteExistingAccount()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var account = await GetValidAccountForUserAsync(controller);
        var putRequest = CreateAccountPutRequest(account);
        putRequest.Currency = "JPY";
        var result = await controller.UpsertAccountAsync(putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<AccountResponse>(response);
        Assert.NotNull(content.Id);
        Assert.Equal(putRequest.Number, content.Number);
        Assert.Equal(putRequest.Currency, content.Currency);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountNotFound()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var result = await controller.UpsertAccountByIdAsync("123", CreateAccountPutRequest(1));
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(404, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_EmptyAlternateIdentifiers()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var account = await GetValidAccountForUserAsync(controller);
        var putRequest = CreateAccountPutRequest(account);
        putRequest.AlternateIdentifiers = Array.Empty<AlternateIdentifier>();
        var result = await controller.UpsertAccountByIdAsync(account.Id, putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(422, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullAlternateIdentifiers()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var account = await GetValidAccountForUserAsync(controller);
        var putRequest = CreateAccountPutRequest(account);
        putRequest.AlternateIdentifiers = null;
        var result = await controller.UpsertAccountByIdAsync(account.Id, putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(422, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_OverwriteExistingAccount()
    {
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var account = await GetValidAccountForUserAsync(controller);
        var putRequest = CreateAccountPutRequest(account);
        putRequest.Currency = "JPY";
        var result = await controller.UpsertAccountByIdAsync(account.Id, putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(200, response.StatusCode);
        var content = GetResponseContent<AccountResponse>(response);
        Assert.NotNull(content.Id);
        Assert.Equal(putRequest.Number, content.Number);
        Assert.Equal(putRequest.Currency, content.Currency);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_RepositoryValidationFailure()
    {
        // The `AccountPutRequest` has data validation on it to ensure the
        // number and type are there; and we have tests to verify that the
        // alternate identifiers are present. However, if somehow any of that
        // slips through, the repository will also verify that the "magic
        // trinity" is available and will fail to write if it's not.
        var controller = await CreateControllerAsync();
        controller.HttpContext.User = CreateApplicationPrincipal();
        var account = await GetValidAccountForUserAsync(controller);
        var putRequest = CreateAccountPutRequest(account);

        // This is the part that would normally be caught by data validation.
        putRequest.Number = null;

        var result = await controller.UpsertAccountByIdAsync(account.Id, putRequest);
        var response = await ExecuteResultAsync(controller, result);
        Assert.Equal(422, response.StatusCode);
    }

    private static AccountPutRequest CreateAccountPutRequest(int index)
    {
        return new AccountPutRequest
        {
            Number = $"an-{index}",
            AccountType = AccountType.CHECKING,
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
        };
    }

    private static AccountPutRequest CreateAccountPutRequest(Repo.Account toUpdate)
    {
        return new AccountPutRequest
        {
            Number = toUpdate.Number,
            AccountType = Enum.Parse<AccountType>(toUpdate.AccountType),
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier
                {
                    Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    Id = toUpdate.AlternateIdentifiers.First(x => x.Scheme == AlternateIdentifierScheme.RoutingTransitNumber).Id,
                },
            },
        };
    }

    private static ClaimsPrincipal CreateApplicationPrincipal()
    {
        return new ClaimsPrincipal(
            new ClaimsIdentity(
                new Claim[]
                {
                    new Claim("client_id", "app"),
                    new Claim("tid", StubDataPopulator.TenantId),
                },
                "test"));
    }

    private static async Task<AccountsController> CreateControllerAsync()
    {
        var services = CreateServices();
        var repo = services.GetService<MemoryRepository>();
        await StubDataPopulator.Populate(repo);

        var controller = new AccountsController(
            services.GetService<ILogger<AccountsController>>(),
            repo,
            services.GetService<IMapper>())
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    RequestServices = services,
                    Response =
                    {
                        Body = new MemoryStream(),
                    },
                },
            },
        };

        return controller;
    }

    private static IServiceProvider CreateServices()
    {
        var services = new ServiceCollection();
        services.AddMvcCore();
        services.AddIstioAuthentication();
        services.AddOptions<ApiBehaviorOptions>();
        services.AddTransient(typeof(ILogger<>), typeof(NullLogger<>));
        services.AddSingleton<ILoggerFactory>(NullLoggerFactory.Instance);
        services.AddSingleton(provider => new MapperConfiguration(c => c.AddProfile<MappingProfile>()).CreateMapper());
        services.AddSingleton<MemoryRepository>();
        return services.BuildServiceProvider();
    }

    private static async Task<HttpResponse> ExecuteResultAsync(AccountsController controller, IActionResult result)
    {
        await result.ExecuteResultAsync(controller.ControllerContext);
        return controller.HttpContext.Response;
    }

    private static TContent GetResponseContent<TContent>(HttpResponse response)
    {
        response.Body.Position = 0;
        var document = JsonDocument.Parse(response.Body);
        return document.Deserialize<TContent>(SerializerOptions);
    }

    private static async Task<Repo.Account> GetValidAccountForUserAsync(AccountsController controller, string userId = null)
    {
        var repo = controller.DataService as MemoryRepository;
        userId ??= StubDataPopulator.UserId;
        return (await repo.GetAccountsAsync(userId, StubDataPopulator.TenantId)).First();
    }

    private static async Task<string> GetValidAccountIdForUserAsync(AccountsController controller, string userId = null)
    {
        return (await GetValidAccountForUserAsync(controller, userId)).Id;
    }
}

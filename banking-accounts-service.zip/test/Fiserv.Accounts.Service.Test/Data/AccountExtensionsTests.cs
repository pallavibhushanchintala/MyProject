using Fiserv.Accounts.Service.Data;

namespace Fiserv.Accounts.Service.Test.Data;

public class AccountExtensionsTests
{
    [Fact]
    public void CloneForIdentitySearch_DoesNotRequireIdentifiers()
    {
        var account = new Account();
        var clone = account.CloneForIdentitySearch();
        Assert.NotSame(account, clone);
    }

    [Fact]
    public void CloneForIdentitySearch_FiltersProperties()
    {
        var account = new Account
        {
            AccountId = "account-id",
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
                new AlternateIdentifier { Scheme = "not-identity", Id = "value" },
            },
            Asset = true,
            CloseDateTime = DateTimeOffset.Now,
            CurrencyCode = "USD",
            Description = "description",
            ETag = "e-tag",
            Id = "id",
            Number = "number",
            OpenDateTime = DateTimeOffset.Now,
            Users = new string[] { "user" },
        };

        var clone = account.CloneForIdentitySearch();

        // Identifiers get copied
        Assert.Equal(account.AccountType, clone.AccountType);
        Assert.Equal(account.Number, clone.Number);
        Assert.Single(clone.AlternateIdentifiers);
        Assert.Equal(AlternateIdentifierScheme.RoutingTransitNumber, clone.AlternateIdentifiers.First().Scheme);

        // Others remain default/empty
        Assert.Null(clone.AccountId);
        Assert.Null(clone.Asset);
        Assert.Null(clone.CloseDateTime);
        Assert.Null(clone.CurrencyCode);
        Assert.Null(clone.Description);
        Assert.Null(clone.ETag);
        Assert.Null(clone.Id);
        Assert.Null(clone.OpenDateTime);
        Assert.Null(clone.Users);
    }

    [Fact]
    public void CloneForIdentitySearch_NullAccount()
    {
        Assert.Throws<ArgumentNullException>(() => AccountExtensions.CloneForIdentitySearch(null));
    }

    [Fact]
    public void GenerateAccountId_DoesNotRequireIdentifiers()
    {
        var account = new Account();
        Assert.NotNull(account.GenerateAccountId());
    }

    [Fact]
    public void GenerateAccountId_NullAccount()
    {
        Assert.Throws<ArgumentNullException>(() => AccountExtensions.GenerateAccountId(null));
    }

    [Fact]
    public void GenerateAccountId_DifferentIdForDifferentIdentifiers()
    {
        var account = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Number = "number",
        };

        var first = account.GenerateAccountId();

        account.AccountType = "CD";
        var second = account.GenerateAccountId();

        account.Number = "new-number";
        var third = account.GenerateAccountId();

        account.AlternateIdentifiers.First(a => a.Scheme == AlternateIdentifierScheme.RoutingTransitNumber).Id = "new-rtn";
        var fourth = account.GenerateAccountId();

        Assert.NotEqual(first, second);
        Assert.NotEqual(first, third);
        Assert.NotEqual(first, fourth);
        Assert.NotEqual(second, third);
        Assert.NotEqual(second, fourth);
        Assert.NotEqual(third, fourth);
    }

    [Fact]
    public void GenerateAccountId_SameIdForAccountsWithSameIdentifiers()
    {
        var first = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Number = "number",
        };

        var second = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Number = "number",
        };

        var a = first.GenerateAccountId();
        var b = second.GenerateAccountId();
        Assert.Equal(a, b);
    }

    [Fact]
    public void GenerateAccountId_SameIdForSameAccount()
    {
        var account = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Number = "number",
        };

        var a = account.GenerateAccountId();
        var b = account.GenerateAccountId();
        Assert.Equal(a, b);
    }

    [Fact]
    public void GetRoutingTransitNumber_EmptyAlternateIdentifiers()
    {
        var account = new Account
        {
            AlternateIdentifiers = Array.Empty<AlternateIdentifier>(),
        };

        Assert.Null(account.GetRoutingTransitNumber());
    }

    [Fact]
    public void GetRoutingTransitNumber_MissingRoutingTransitNumber()
    {
        var account = new Account
        {
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = "a", Id = "1" },
                new AlternateIdentifier { Scheme = "b", Id = "2" },
            },
        };

        Assert.Null(account.GetRoutingTransitNumber());
    }

    [Fact]
    public void GetRoutingTransitNumber_NullAccount()
    {
        Assert.Throws<ArgumentNullException>(() => AccountExtensions.GetRoutingTransitNumber(null));
    }

    [Fact]
    public void GetRoutingTransitNumber_NullAlternateIdentifiers()
    {
        var account = new Account
        {
            AlternateIdentifiers = null,
        };

        Assert.Null(account.GetRoutingTransitNumber());
    }

    [Fact]
    public void GetRoutingTransitNumber_Success()
    {
        var account = new Account
        {
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = "a", Id = "1" },
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "found" },
                new AlternateIdentifier { Scheme = "b", Id = "2" },
            },
        };

        Assert.Equal("found", account.GetRoutingTransitNumber());
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    public void Validate_MissingAccountType(string accountType)
    {
        var account = new Account
        {
            AccountType = accountType,
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Number = "number",
        };
        Assert.Throws<ArgumentException>(() => account.Validate());
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    public void Validate_MissingNumber(string number)
    {
        var account = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Number = number,
        };
        Assert.Throws<ArgumentException>(() => account.Validate());
    }

    [Fact]
    public void Validate_MissingRoutingTransitNumberEntry()
    {
        var account = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = Array.Empty<AlternateIdentifier>(),
            Number = "number",
        };
        Assert.Throws<ArgumentException>(() => account.Validate());
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    public void Validate_MissingRoutingTransitNumberValue(string rtn)
    {
        var account = new Account
        {
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = rtn },
            },
            Number = "number",
        };
        Assert.Throws<ArgumentException>(() => account.Validate());
    }

    [Fact]
    public void Validate_NullAccount()
    {
        Account account = null;
        Assert.Throws<ArgumentNullException>(() => account.Validate());
    }
}

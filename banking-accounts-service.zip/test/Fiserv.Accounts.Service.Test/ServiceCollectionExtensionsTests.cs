using Fiserv.Security.Tokenization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using V = Fiserv.Security.Tokenization.Voltage;

namespace Fiserv.Accounts.Service.Test;

public class ServiceCollectionExtensionsTests
{
    [Fact]
    public void AddTokenizer_DevelopmentDefault()
    {
        var services = new ServiceCollection();
        var config = new ConfigurationBuilder().AddInMemoryCollection().Build();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var files = CreateFileProvider();
        services.AddTokenizer(config, env, files);

        var service = services.FirstOrDefault(x => x.ServiceType == typeof(ITokenizer));
        Assert.NotNull(service);
        Assert.Equal(typeof(Fiserv.Security.Tokenization.Development.Tokenizer), service.ImplementationType);
    }

    [Fact]
    public void AddTokenizer_DevelopmentUsesVoltageWhenEnabled()
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var files = CreateFileProvider();
        services.AddTokenizer(config, env, files);

        var service = services.FirstOrDefault(x => x.ServiceType == typeof(ITokenizer));
        Assert.NotNull(service);
        Assert.Equal(typeof(V.Tokenizer), service.ImplementationType);
        var provider = services.BuildServiceProvider();
        var options = provider.GetRequiredService<IOptions<V.VoltageOptions>>().Value;
        Assert.Equal("Production", options.EnvironmentName);
        Assert.NotNull(options.ApplicationCredentials);
    }

    [Fact]
    public void AddTokenizer_DevelopmentVoltageMustBeEnabled()
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration(enabled: null);
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var files = CreateFileProvider();
        services.AddTokenizer(config, env, files);

        var service = services.FirstOrDefault(x => x.ServiceType == typeof(ITokenizer));
        Assert.NotNull(service);
        Assert.Equal(typeof(Fiserv.Security.Tokenization.Development.Tokenizer), service.ImplementationType);
    }

    [Fact]
    public void AddTokenizer_NullConfiguration()
    {
        var services = new ServiceCollection();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var files = CreateFileProvider();
        Assert.Throws<ArgumentNullException>(() => services.AddTokenizer(null, env, files));
    }

    [Fact]
    public void AddTokenizer_NullEnvironment()
    {
        var services = new ServiceCollection();
        var config = new ConfigurationBuilder().AddInMemoryCollection().Build();
        var files = CreateFileProvider();
        Assert.Throws<ArgumentNullException>(() => services.AddTokenizer(config, null, files));
    }

    [Fact]
    public void AddTokenizer_NullFileProvider()
    {
        var services = new ServiceCollection();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var config = new ConfigurationBuilder().AddInMemoryCollection().Build();
        Assert.Throws<ArgumentNullException>(() => services.AddTokenizer(config, env, null));
    }

    [Fact]
    public void AddTokenizer_NullServiceCollection()
    {
        var config = new ConfigurationBuilder().AddInMemoryCollection().Build();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var files = CreateFileProvider();
        Assert.Throws<ArgumentNullException>(() => ServiceCollectionExtensions.AddTokenizer(null, config, env, files));
    }

    [Fact]
    public void AddTokenizer_ProductionAlwaysUsesVoltage()
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration(enabled: null);
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Production);
        var files = CreateFileProvider();
        services.AddTokenizer(config, env, files);

        var service = services.FirstOrDefault(x => x.ServiceType == typeof(ITokenizer));
        Assert.NotNull(service);
        Assert.Equal(typeof(V.Tokenizer), service.ImplementationType);
        var provider = services.BuildServiceProvider();
        var options = provider.GetRequiredService<IOptions<V.VoltageOptions>>().Value;
        Assert.Equal("Production", options.EnvironmentName);
        Assert.NotNull(options.ApplicationCredentials);
    }

    [Fact]
    public void AddTokenizer_ReturnsServices()
    {
        var services = new ServiceCollection();
        var config = new ConfigurationBuilder().AddInMemoryCollection().Build();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == Environments.Development);
        var files = CreateFileProvider();
        var actual = services.AddTokenizer(config, env, files);
        Assert.Same(services, actual);
    }

    [Theory]
    [InlineData("Development")]
    [InlineData("Production")]
    public void AddTokenizer_VoltageFallsBackToHostEnvironmentName(string hostEnvironment)
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration(environment: null);
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == hostEnvironment);
        var files = CreateFileProvider();
        services.AddTokenizer(config, env, files);

        var provider = services.BuildServiceProvider();
        var options = provider.GetRequiredService<IOptions<V.VoltageOptions>>().Value;
        Assert.Equal(hostEnvironment, options.EnvironmentName);
    }

    [Theory]
    [InlineData("Development", null, "pass")]
    [InlineData("Development", "user", null)]
    [InlineData("Production", null, "pass")]
    [InlineData("Production", "user", null)]
    public void AddTokenizer_VoltageMissingRequiredConfiguration(string hostEnvironment, string username, string password)
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration(username: username, password: password);
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == hostEnvironment);
        var files = CreateFileProvider();
        Assert.Throws<InvalidOperationException>(() => services.AddTokenizer(config, env, files));
    }

    [Theory]
    [InlineData("Development", false, true)]
    [InlineData("Development", true, false)]
    [InlineData("Development", false, false)]
    [InlineData("Production", false, true)]
    [InlineData("Production", true, false)]
    [InlineData("Production", false, false)]
    public void AddTokenizer_VoltageTrustStoreMustExist(string hostEnvironment, bool exists, bool isDirectory)
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration();
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == hostEnvironment);
        var files = CreateFileProvider(exists, isDirectory);
        Assert.Throws<DirectoryNotFoundException>(() => services.AddTokenizer(config, env, files));
    }

    [Theory]
    [InlineData("Development", "Staging")]
    [InlineData("Production", "Development")]
    public void AddTokenizer_VoltageUsesExplicitEnvironment(string hostEnvironment, string voltageEnvironment)
    {
        var services = new ServiceCollection();
        var config = CreateConfiguration(environment: voltageEnvironment);
        var env = Mock.Of<IWebHostEnvironment>(x => x.EnvironmentName == hostEnvironment);
        var files = CreateFileProvider();
        services.AddTokenizer(config, env, files);

        var provider = services.BuildServiceProvider();
        var options = provider.GetRequiredService<IOptions<V.VoltageOptions>>().Value;
        Assert.Equal(voltageEnvironment, options.EnvironmentName);
    }

    private static IFileProvider CreateFileProvider(bool exists = true, bool isDirectory = true)
    {
        var provider = new Mock<IFileProvider>();

        // Mock the real-but-buggy behavior of IFileProvider
        // https://github.com/dotnet/runtime/issues/36575 - GetFileInfo doesn't support directories
        // https://github.com/dotnet/runtime/issues/36496 - Directory contents doesn't know the directory path
        var trustStoreFile = Mock.Of<IFileInfo>(x => x.Exists == (exists && !isDirectory) && x.IsDirectory == false && x.PhysicalPath == "/trustStore" && x.Name == "trustStore");
        var otherFile = Mock.Of<IFileInfo>(x => x.Exists == false);
        provider.Setup(x => x.GetFileInfo(It.Is<string>("trustStore", StringComparer.Ordinal))).Returns(trustStoreFile);
        provider.Setup(x => x.GetFileInfo(It.Is<string>(s => !s.Equals("trustStore", StringComparison.Ordinal)))).Returns(otherFile);
        var trustStoreFolder = Mock.Of<IDirectoryContents>(x => x.Exists == (isDirectory && exists));
        var otherFolder = Mock.Of<IDirectoryContents>(x => x.Exists == false);
        provider.Setup(x => x.GetDirectoryContents(It.Is<string>("trustStore", StringComparer.Ordinal))).Returns(trustStoreFolder);
        provider.Setup(x => x.GetDirectoryContents(It.Is<string>(s => !s.Equals("trustStore", StringComparison.Ordinal)))).Returns(otherFolder);

        return provider.Object;
    }

    private static IConfigurationRoot CreateConfiguration(string enabled = "true", string username = "user", string password = "pass", string environment = "Production")
    {
        var data = new Dictionary<string, string>
        {
            { "voltage:enabled", enabled },
            { "voltage:environment", environment },
            { "voltage:username", username },
            { "voltage:password", password },
        };
        return new ConfigurationBuilder().AddInMemoryCollection(data).Build();
    }
}

using System.Globalization;
using AutoMapper;
using Fiserv.Accounts.Service.Data;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.Security.Tokenization;
using Fiserv.Security.Tokenization.Development;
using Microsoft.Extensions.Logging;

namespace Fiserv.Accounts.Service.Test.Repositories;

public class TokenizationDecoratorTests
{
    [Fact]
    public void Ctor_NullDecorated()
    {
        var tokenizer = Mock.Of<ITokenizer>();
        var mapper = Mock.Of<IMapper>();
        Assert.Throws<ArgumentNullException>(() => new TokenizationDecorator(null, tokenizer, mapper));
    }

    [Fact]
    public void Ctor_NullMapper()
    {
        var decorated = Mock.Of<IDataRepository>();
        var tokenizer = Mock.Of<ITokenizer>();
        Assert.Throws<ArgumentNullException>(() => new TokenizationDecorator(decorated, tokenizer, null));
    }

    [Fact]
    public void Ctor_NullTokenizer()
    {
        var decorated = Mock.Of<IDataRepository>();
        var mapper = Mock.Of<IMapper>();
        Assert.Throws<ArgumentNullException>(() => new TokenizationDecorator(decorated, null, mapper));
    }

    [Fact]
    public async Task FindAccountAsync_HandlesNumberEncryption()
    {
        var decorator = CreateRepository();
        var input = CreateAccount(1);
        await decorator.UpsertAccountAsync(input, "tenant");
        var search = new Account { AccountType = "CHECKING", Number = "an-1" };
        var found = await decorator.FindAccountAsync(search, null, "tenant");
        Assert.Collection(found, item => Assert.Equal("an-1", item.Number));
    }

    [Fact]
    public async Task FindAccountAsync_NoNumbers()
    {
        var decorator = CreateRepository();
        var input = CreateAccount(1);
        await decorator.UpsertAccountAsync(input, "tenant");
        var search = new Account { AccountType = "CHECKING" };
        var found = await decorator.FindAccountAsync(search, null, "tenant");
        Assert.Collection(found, item => Assert.Equal("an-1", item.Number));
    }

    [Fact]
    public async Task FindAccountAsync_NoResults()
    {
        var decorator = CreateRepository();
        var search = new Account { Number = "1234567890" };
        var found = await decorator.FindAccountAsync(search, null, "tenant");
        Assert.Empty(found);
    }

    [Fact]
    public async Task FindAccountAsync_NullAccount()
    {
        var decorator = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await decorator.FindAccountAsync(null, "user", "tenant"));
    }

    [Fact]
    public async Task GetAccountByIdAsync_AccountNotFound()
    {
        var decorator = CreateRepository();
        Assert.Null(await decorator.GetAccountByIdAsync("not-found", "tenant"));
    }

    [Fact]
    public async Task GetAccountByIdAsync_DecryptsAccountNumber()
    {
        var decorator = CreateRepository();
        var input = CreateAccount(1);
        var upserted = await decorator.UpsertAccountAsync(input, "tenant");
        var found = await decorator.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.Equal(input.Number, found.Number);
    }

    [Fact]
    public async Task GetAccountsAsync_DecryptsAccountNumbers()
    {
        var decorator = CreateRepository();
        var input = new Account[]
        {
            CreateAccount(1),
            CreateAccount(2),
            CreateAccount(3),
        };

        var repo = decorator.Decorated as MemoryRepository;
        foreach (var item in input)
        {
            var added = await decorator.UpsertAccountAsync(item, "tenant");
            await repo.AddUserToAccountAsync("user", added.Id);
        }

        var coll = await decorator.GetAccountsAsync("user", "tenant");
        Assert.Equal(3, coll.Count());
        Assert.All(coll, item => Assert.Contains(input, i => i.Number == item.Number));
    }

    [Fact]
    public async Task GetAccountsAsync_NoAccounts()
    {
        var decorator = CreateRepository();
        var coll = await decorator.GetAccountsAsync("user", "tenant");
        Assert.Empty(coll);
    }

    [Fact]
    public async Task UpsertAccountAsync_NullAccount()
    {
        var decorator = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await decorator.UpsertAccountAsync(null, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_NumberGetsEncrypted()
    {
        var decorator = CreateRepository();
        var input = CreateAccount(1);
        var output = await decorator.UpsertAccountAsync(input, "tenant");
        Assert.NotNull(output);
        Assert.NotSame(input, output);
        var stored = await decorator.Decorated.GetAccountByIdAsync(output.AccountId, "tenant");
        Assert.NotNull(stored);
        Assert.NotSame(output, stored);
        Assert.NotEqual(stored.Number, output.Number);
        Assert.Equal(input.Number, output.Number);
    }

    [Fact]
    public async Task UpsertAccountAsync_UpsertFailure()
    {
        var decorated = new Mock<IDataRepository>();
        decorated
            .Setup(x => x.UpsertAccountAsync(It.IsAny<Account>(), It.IsAny<string>()))
            .ReturnsAsync((Account)null);
        var decorator = CreateRepository(decorated.Object);
        var input = new Account();
        var output = await decorator.UpsertAccountAsync(input, "tenant");
        Assert.Null(output);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountNotFound()
    {
        var decorator = CreateRepository();
        var adjusted = CreateAccount(1);
        var upserted = await decorator.UpsertAccountByIdAsync("not-found", adjusted, "tenant");
        Assert.Null(upserted);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullAccount()
    {
        var decorator = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await decorator.UpsertAccountByIdAsync("id", null, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NumberGetsEncrypted()
    {
        var decorator = CreateRepository();
        var original = CreateAccount(1);
        var inserted = await decorator.UpsertAccountAsync(original, "tenant");
        var adjusted = CreateAccount(1);
        var upserted = await decorator.UpsertAccountByIdAsync(inserted.Id, adjusted, "tenant");
        var stored = await decorator.Decorated.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.NotSame(upserted, stored);
        Assert.NotEqual(upserted.Number, stored.Number);
        Assert.Equal(adjusted.Number, upserted.Number);
    }

    private static Account CreateAccount(int index)
    {
        return new Account
        {
            Number = $"an-{index}",
            Description = $"ad-{index}",
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn-a" },
                new AlternateIdentifier { Scheme = "Index", Id = index.ToString(CultureInfo.InvariantCulture) },
            },
            CurrencyCode = "USD",
        };
    }

    private static TokenizationDecorator CreateRepository(IDataRepository decorated = null)
    {
        var mapper = new MapperConfiguration(c => c.AddProfile<MappingProfile>()).CreateMapper();
        if (decorated == null)
        {
            var logger = Mock.Of<ILogger<MemoryRepository>>();
            decorated = new MemoryRepository(mapper, logger);
        }

        return new TokenizationDecorator(decorated, new Tokenizer(), mapper);
    }
}

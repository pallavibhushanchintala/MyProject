using System.Globalization;
using AutoMapper;
using Fiserv.Accounts.Service.Data;
using Fiserv.Accounts.Service.Repositories;
using Microsoft.Extensions.Logging;

namespace Fiserv.Accounts.Service.Test.Repositories;

public class MemoryRepositoryTests
{
    [Fact]
    public async Task AddBalanceAsync_AccountFound()
    {
        var repo = CreateRepository();
        var upsertedAccount = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var balance = CreateBalance(1, upsertedAccount.Id);
        var added = await repo.AddBalanceAsync(balance, "tenant");
        Assert.NotNull(added);
        Assert.NotNull(added.Id);
        Assert.Empty(added.Users);
        Assert.NotSame(balance, added);
    }

    [Fact]
    public async Task AddBalanceAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var balance = CreateBalance(1, "no-account-found");
        var added = await repo.AddBalanceAsync(balance, "tenant");
        Assert.Null(added);
    }

    [Fact]
    public async Task AddBalanceAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var balance = new Balance();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.AddBalanceAsync(balance, ""));
    }

    [Fact]
    public async Task AddBalanceAsync_NullBalance()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.AddBalanceAsync(null, "tenant"));
    }

    [Fact]
    public async Task AddBalanceAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var balance = new Balance();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.AddBalanceAsync(balance, null));
    }

    [Fact]
    public async Task AddBalanceAsync_UsersIgnoredIfProvided()
    {
        var repo = CreateRepository();
        var upsertedAccount = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        await repo.AddUserToAccountAsync("user-1", upsertedAccount.Id);
        var balance = CreateBalance(1, upsertedAccount.Id);
        balance.Users = new string[] { "user-2" };
        var added = await repo.AddBalanceAsync(balance, "tenant");
        Assert.Contains("user-1", added.Users);
        Assert.DoesNotContain("user-2", added.Users);
    }

    [Fact]
    public async Task AddTransactionAsync_AccountFound()
    {
        var repo = CreateRepository();
        var upsertedAccount = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var transaction = new Transaction
        {
            AccountId = upsertedAccount.Id,
            Amount = new Amount { CurrencyCode = "USD", Value = 5.49 },
        };
        var added = await repo.AddTransactionAsync(transaction, "tenant");
        Assert.NotNull(added);
        Assert.NotNull(added.Id);
        Assert.Empty(added.Users);
        Assert.NotSame(transaction, added);
    }

    [Fact]
    public async Task AddTransactionAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var transaction = new Transaction
        {
            AccountId = "account",
            Amount = new Amount { CurrencyCode = "USD", Value = 5.49 },
        };
        var added = await repo.AddTransactionAsync(transaction, "tenant");
        Assert.Null(added);
    }

    [Fact]
    public async Task AddTransactionAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var transaction = new Transaction();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.AddTransactionAsync(transaction, ""));
    }

    [Fact]
    public async Task AddTransactionAsync_NullTransaction()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.AddTransactionAsync(null, "tenant"));
    }

    [Fact]
    public async Task AddTransactionAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var transaction = new Transaction();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.AddTransactionAsync(transaction, null));
    }

    [Fact]
    public async Task AddTransactionAsync_UsersIgnoredIfProvided()
    {
        var repo = CreateRepository();
        var upsertedAccount = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        await repo.AddUserToAccountAsync("user-1", upsertedAccount.AccountId);
        var transaction = new Transaction
        {
            AccountId = upsertedAccount.Id,
            Amount = new Amount { CurrencyCode = "USD", Value = 5.49 },
            Users = new string[] { "user-2" },
        };
        var added = await repo.AddTransactionAsync(transaction, "tenant");
        Assert.Contains("user-1", added.Users);
        Assert.DoesNotContain("user-2", added.Users);
    }

    [Fact]
    public void Ctor_NullLogger()
    {
        Assert.Throws<ArgumentNullException>(() => new MemoryRepository(Mock.Of<IMapper>(), null));
    }

    [Fact]
    public void Ctor_NullMapper()
    {
        Assert.Throws<ArgumentNullException>(() => new MemoryRepository(null, Mock.Of<ILogger<MemoryRepository>>()));
    }

    [Fact]
    public async Task FindAccountAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var account = new Account();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.FindAccountAsync(account, "user", ""));
    }

    [Fact]
    public async Task FindAccountAsync_FiltersByAlternateIdentifiers()
    {
        var repo = CreateRepository();

        // Accounts differ by alternate identifiers only.
        await repo.UpsertAccountAsync(CreateAccount(1, rtn: "a"), "tenant");
        var expected = await repo.UpsertAccountAsync(CreateAccount(1, rtn: "b"), "tenant");

        // Will match only one.
        var find = CreateAccount(1, rtn: "b");
        var found = await repo.FindAccountAsync(find, null, "tenant");
        Assert.Collection(found, item => Assert.Equal(expected.Id, item.Id));
    }

    [Fact]
    public async Task FindAccountAsync_FiltersByUserId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var expected = await repo.UpsertAccountAsync(account, "tenant");
        await repo.AddUserToAccountAsync("user", expected.Id);

        // As an app it succeeds
        var found = await repo.FindAccountAsync(account, null, "tenant");
        Assert.Collection(found, item => Assert.Equal(expected.Id, item.Id));

        // As the exact user it succeeds
        found = await repo.FindAccountAsync(account, "user", "tenant");
        Assert.Collection(found, item => Assert.Equal(expected.Id, item.Id));

        // User without access doesn't get the result
        found = await repo.FindAccountAsync(account, "not-the-user", "tenant");
        Assert.Empty(found);
    }

    [Fact]
    public async Task FindAccountAsync_MultipleMatches()
    {
        var repo = CreateRepository();

        // Accounts differ by alternate identifiers only.
        await repo.UpsertAccountAsync(CreateAccount(1, rtn: "a"), "tenant");
        await repo.UpsertAccountAsync(CreateAccount(1, rtn: "b"), "tenant");

        // Will match multiple because there aren't alternate IDs.
        var multiMatch = new Account
        {
            Number = "an-1",
        };

        var found = await repo.FindAccountAsync(multiMatch, null, "tenant");
        Assert.Equal(2, found.Count());
    }

    [Fact]
    public async Task FindAccountAsync_NullAccount()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.FindAccountAsync(null, "user", "tenant"));
    }

    [Fact]
    public async Task FindAccountAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var account = new Account();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.FindAccountAsync(account, "user", null));
    }

    [Fact]
    public async Task FindAccountAsync_SingleMatch()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var expected = await repo.UpsertAccountAsync(account, "tenant");
        var found = await repo.FindAccountAsync(account, null, "tenant");
        Assert.Collection(found, item => Assert.Equal(expected.Id, item.Id));
    }

    [Fact]
    public async Task FindAccountAsync_TenantNotFound()
    {
        // The repo isn't multitenant-aware.
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var expected = await repo.UpsertAccountAsync(account, "other-tenant");
        var found = await repo.FindAccountAsync(account, null, "tenant");
        Assert.Collection(found, item => Assert.Equal(expected.Id, item.Id));
    }

    [Fact]
    public async Task GetAccountByIdAsync_AccountFound()
    {
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.Equal(upserted.Id, found.Id);
    }

    [Fact]
    public async Task GetAccountByIdAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var account = await repo.GetAccountByIdAsync("not-found", "tenant");
        Assert.Null(account);
    }

    [Fact]
    public async Task GetAccountByIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountByIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetAccountByIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountByIdAsync("account-1", ""));
    }

    [Fact]
    public async Task GetAccountByIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountByIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetAccountByIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountByIdAsync("account-1", null));
    }

    [Fact]
    public async Task GetAccountByIdAsync_Success()
    {
        var repo = CreateRepository();
        var toUpsert = CreateAccount(1);
        var upserted = await repo.UpsertAccountAsync(toUpsert, "tenant");
        var account = await repo.GetAccountByIdAsync(upserted.AccountId, "tenant");
        Assert.Equal(upserted.Id, account.Id);
    }

    [Fact]
    public async Task GetAccountByIdAsync_TenantNotFound()
    {
        // The repo isn't multitenant-aware.
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "other-tenant");
        var found = await repo.GetAccountByIdAsync(upserted.AccountId, "tenant");
        Assert.Equal(upserted.Id, found.Id);
    }

    [Fact]
    public async Task GetAccountsAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountsAsync("user", ""));
    }

    [Fact]
    public async Task GetAccountsAsync_EmptyUserId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountsAsync("", "tenant"));
    }

    [Fact]
    public async Task GetAccountsAsync_FiltersByUserId()
    {
        var repo = CreateRepository();
        var input = new Account[]
        {
            CreateAccount(1),
            CreateAccount(2),
            CreateAccount(3),
            CreateAccount(4),
        };
        var added = new List<Account>();
        foreach (var item in input)
        {
            added.Add(await repo.UpsertAccountAsync(item, "tenant"));
        }

        // user-1 gets 0, 2, 3
        // user-2 gets 1, 2
        await repo.AddUserToAccountAsync("user-1", added[0].Id);
        await repo.AddUserToAccountAsync("user-2", added[1].Id);
        await repo.AddUserToAccountAsync("user-1", added[2].Id);
        await repo.AddUserToAccountAsync("user-2", added[2].Id);
        await repo.AddUserToAccountAsync("user-1", added[3].Id);

        // Verify access and ensure the objects returned are clones, not the originals in the repo.
        var coll = await repo.GetAccountsAsync("user-1", "tenant");
        Assert.Equal(3, coll.Count());
        Assert.All(coll, item => Assert.DoesNotContain(item, input));

        coll = await repo.GetAccountsAsync("user-2", "tenant");
        Assert.Equal(2, coll.Count());
        Assert.All(coll, item => Assert.DoesNotContain(item, input));

        coll = await repo.GetAccountsAsync("user-3", "tenant");
        Assert.Empty(coll);
    }

    [Fact]
    public async Task GetAccountsAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountsAsync("user", null));
    }

    [Fact]
    public async Task GetAccountsAsync_NullUserId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountsAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetAccountsAsync_TenantNotFound()
    {
        // The repo isn't multitenant-aware.
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var upserted = await repo.UpsertAccountAsync(account, "other-tenant");
        await repo.AddUserToAccountAsync("user-1", upserted.Id);
        Assert.Single(await repo.GetAccountsAsync("user-1", "tenant"));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var upserted = await repo.UpsertAccountAsync(account, "tenant");
        await repo.AddBalanceAsync(new Balance { AccountId = upserted.AccountId, CurrencyCode = "USD", Data = new BalanceData[] { new BalanceData { Amount = 543, DateTime = DateTimeOffset.Now.AddMinutes(-20) }, new BalanceData { Amount = 1234.56, DateTime = DateTimeOffset.Now } }, BalanceType = "OPBD" }, "tenant");
        await repo.AddBalanceAsync(new Balance { AccountId = upserted.AccountId, CurrencyCode = "USD", Data = new BalanceData[] { new BalanceData { Amount = 654, DateTime = DateTimeOffset.Now.AddMinutes(-30) }, new BalanceData { Amount = 22.33, DateTime = DateTimeOffset.Now } }, BalanceType = "FWAV" }, "tenant");
        var data = await repo.GetBalancesByAccountIdAsync("not-found", "tenant");
        Assert.Null(data.Account);
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetBalancesByAccountIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetBalancesByAccountIdAsync("123", ""));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetBalancesByAccountIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetBalancesByAccountIdAsync("123", null));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_NoBalanceData()
    {
        // Rollback - if the rollback process leaves a balance object hanging
        // out that doesn't actually have any data (because rollback dropped the
        // last value) we need to account for that.
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var nullBalanceData = CreateBalance(1, upserted.Id);
        nullBalanceData.Data = null;
        await repo.AddBalanceAsync(nullBalanceData, "tenant");

        var emptyBalanceData = CreateBalance(2, upserted.Id);
        emptyBalanceData.Data = Array.Empty<BalanceData>();
        await repo.AddBalanceAsync(emptyBalanceData, "tenant");

        var data = await repo.GetBalancesByAccountIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Empty(data.Data);
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_Success()
    {
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        await repo.AddBalanceAsync(CreateBalance(1, upserted.Id), "tenant");
        await repo.AddBalanceAsync(CreateBalance(2, upserted.Id), "tenant");
        var data = await repo.GetBalancesByAccountIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Equal(2, data.Data.Count());
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_TenantNotFound()
    {
        // The repo isn't multitenant-aware.
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "other-tenant");
        await repo.AddBalanceAsync(CreateBalance(1, upserted.Id), "other-tenant");
        var data = await repo.GetBalancesByAccountIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Single(data.Data);
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var data = await repo.GetProductsByAccountIdAsync("not-found", "tenant");
        Assert.Null(data.Account);
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetProductsByAccountIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetProductsByAccountIdAsync("account-1", ""));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetProductsByAccountIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetProductsByAccountIdAsync("account-1", null));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_Success()
    {
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        await repo.UpdateProductsForAccountIdAsync(
            upserted.AccountId,
            new Product[]
            {
                new Product { Scheme = "host", Value = "L01" },
                new Product { Scheme = "host", Value = "CREDITCARD" },
            },
            "tenant");
        var data = await repo.GetProductsByAccountIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Equal(2, data.Data.Count());
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_TenantNotFound()
    {
        // The repo isn't multitenant-aware.
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "other-tenant");
        await repo.UpdateProductsForAccountIdAsync(
            upserted.Id,
            new Product[]
            {
                new Product { Scheme = "host", Value = "CREDITCARD" },
            },
            "other-tenant");
        var data = await repo.GetProductsByAccountIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Single(data.Data);
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var data = await repo.GetTransactionsByAccountIdAsync("not-found", "tenant");
        Assert.Null(data.Account);
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetTransactionsByAccountIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetTransactionsByAccountIdAsync("123", ""));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetTransactionsByAccountIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetTransactionsByAccountIdAsync("123", null));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_Success()
    {
        var repo = CreateRepository();
        var upsertedAccount = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var input = new Transaction[]
        {
            new Transaction
            {
                AccountId = upsertedAccount.Id,
                Amount = new Amount { CurrencyCode = "USD", Value = 5.49 },
            },
            new Transaction
            {
                AccountId = upsertedAccount.Id,
                Amount = new Amount { CurrencyCode = "USD", Value = 1500.44 },
            },
        };

        foreach (var item in input)
        {
            var inserted = await repo.AddTransactionAsync(item, "tenant");
            Assert.DoesNotContain(inserted, input);
        }

        var data = await repo.GetTransactionsByAccountIdAsync(upsertedAccount.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Equal(2, data.Data.Count());
        Assert.All(data.Data, item => Assert.DoesNotContain(item, input));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_TenantNotFound()
    {
        // The repo isn't multitenant-aware.
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "other-tenant");
        await repo.AddTransactionAsync(
            new Transaction
            {
                AccountId = upserted.Id,
                Amount = new Amount { CurrencyCode = "USD", Value = 5.49 },
            },
            "other-tenant");
        var data = await repo.GetTransactionsByAccountIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(data.Account);
        Assert.Single(data.Data);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var result = await repo.UpdateProductsForAccountIdAsync("does-not-exist", new List<Product>(), "tenant");
        Assert.Null(result);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_FirstInsertionForAccount()
    {
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var products = new Product[]
        {
            new Product { Scheme = "host", Value = "L01" },
            new Product { Scheme = "host", Value = "CREDITCARD" },
        };
        var insertedProducts = await repo.UpdateProductsForAccountIdAsync(upserted.AccountId, products, "tenant");
        Assert.Equal(2, insertedProducts.Count());
        Assert.All(insertedProducts, item => Assert.Equal(upserted.Id, item.AccountId));
        Assert.All(insertedProducts, item => Assert.Equal("host", item.Scheme));
        Assert.All(insertedProducts, item => Assert.Empty(item.Users));
        Assert.All(insertedProducts, item => Assert.DoesNotContain(item, products));
        Assert.NotSame(products, insertedProducts);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpdateProductsForAccountIdAsync("", Enumerable.Empty<Product>(), "tenant"));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpdateProductsForAccountIdAsync("account-1", Enumerable.Empty<Product>(), ""));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpdateProductsForAccountIdAsync(null, Enumerable.Empty<Product>(), "tenant"));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_NullProducts()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpdateProductsForAccountIdAsync("account-1", null, "tenant"));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpdateProductsForAccountIdAsync("account-1", Enumerable.Empty<Product>(), null));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_ReplacesExistingProducts()
    {
        var repo = CreateRepository();
        var upserted = await repo.UpsertAccountAsync(CreateAccount(1), "tenant");
        var products = new Product[]
        {
            new Product { Scheme = "host", Value = "L01" },
            new Product { Scheme = "host", Value = "CREDITCARD" },
        };
        await repo.UpdateProductsForAccountIdAsync(upserted.Id, products, "tenant");
        products = new Product[]
        {
            new Product { Scheme = "update", Value = "L01" },
            new Product { Scheme = "update", Value = "CREDITCARD" },
            new Product { Scheme = "update", Value = "VALUE" },
        };
        var insertedProducts = await repo.UpdateProductsForAccountIdAsync(upserted.Id, products, "tenant");
        Assert.Equal(3, insertedProducts.Count());
        Assert.All(insertedProducts, item => Assert.Equal(upserted.Id, item.AccountId));
        Assert.All(insertedProducts, item => Assert.Equal("update", item.Scheme));
        Assert.All(insertedProducts, item => Assert.Empty(item.Users));
        Assert.All(insertedProducts, item => Assert.DoesNotContain(item, products));
        Assert.NotSame(products, insertedProducts);
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountExists()
    {
        var repo = CreateRepository();
        var original = CreateAccount(1);
        original.Description = "original";
        var inserted = await repo.UpsertAccountAsync(original, "tenant");
        var adjusted = CreateAccount(1);
        adjusted.Description = "adjusted";
        var upserted = await repo.UpsertAccountAsync(adjusted, "tenant");
        var found = await repo.GetAccountByIdAsync(upserted.AccountId, "tenant");
        Assert.NotNull(inserted);
        Assert.NotNull(upserted);
        Assert.NotNull(found);
        Assert.NotSame(original, inserted);
        Assert.NotSame(adjusted, upserted);
        Assert.Equal(inserted.Id, upserted.Id);
        Assert.Equal(inserted.AccountId, upserted.AccountId);
        Assert.Equal(inserted.Id, found.Id);
        Assert.Equal(inserted.AccountId, found.AccountId);
        Assert.Equal("adjusted", found.Description);
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountIdSpecified()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = "account-1";
        toUpsert.AccountId = "account-1";
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountIsNew()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var upserted = await repo.UpsertAccountAsync(account, "tenant");
        var found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.NotNull(upserted);
        Assert.NotNull(found);
        Assert.NotSame(account, upserted);
        Assert.NotSame(upserted, found);
        Assert.NotNull(upserted.AccountId);
        Assert.NotNull(upserted.Id);
        Assert.Equal(upserted.Id, found.Id);
        Assert.Equal(upserted.AccountId, found.AccountId);
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = null;
        toUpsert.AccountId = null;
        toUpsert.Number = null;
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountTypeMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = null;
        toUpsert.AccountId = null;
        toUpsert.AccountType = null;
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(account, ""));
    }

    [Fact]
    public async Task UpsertAccountAsync_NullAccount()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountAsync(null, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountAsync(account, null));
    }

    [Fact]
    public async Task UpsertAccountAsync_RoutingTransitNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = null;
        toUpsert.AccountId = null;
        toUpsert.AlternateIdentifiers = null;
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_UsersIgnoredIfProvided()
    {
        var repo = CreateRepository();
        var original = CreateAccount(1);
        original.Users = new string[] { "a", "b" };

        // Initial upsert should ignore users. Since there is no user
        // assigned to the account yet, no users should be in the response.
        var upserted = await repo.UpsertAccountAsync(original, "tenant");
        Assert.Empty(upserted.Users);

        // Add a user to the account.
        await repo.AddUserToAccountAsync("user-1", upserted.Id);
        var found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.Single(found.Users);
        Assert.Contains("user-1", found.Users);

        // Try upserting again with the set of users. It should ignore the users
        // and keep the original set.
        upserted = await repo.UpsertAccountAsync(original, "tenant");
        found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.Single(found.Users);
        Assert.Contains("user-1", found.Users);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountFound()
    {
        var repo = CreateRepository();
        var original = CreateAccount(1);
        var inserted = await repo.UpsertAccountAsync(original, "tenant");
        var adjusted = CreateAccount(1);
        adjusted.CurrencyCode = "JPY";
        var upserted = await repo.UpsertAccountByIdAsync(inserted.Id, adjusted, "tenant");
        var found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.NotNull(inserted);
        Assert.NotNull(upserted);
        Assert.NotNull(found);
        Assert.NotSame(original, inserted);
        Assert.NotSame(adjusted, upserted);
        Assert.NotSame(upserted, found);
        Assert.Equal(inserted.Id, upserted.Id);
        Assert.Equal(inserted.AccountId, upserted.AccountId);
        Assert.Equal(inserted.Id, found.Id);
        Assert.Equal(inserted.AccountId, found.AccountId);
        Assert.Equal("JPY", found.CurrencyCode);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountNotFound()
    {
        var repo = CreateRepository();
        var found = await repo.UpsertAccountByIdAsync("id", CreateAccount(1), "tenant");
        Assert.Null(found);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Number = null;

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountTypeMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.AccountType = null;

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("", account, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("id", account, ""));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_IdMatch()
    {
        var repo = CreateRepository();
        var original = CreateAccount(1);
        var inserted = await repo.UpsertAccountAsync(original, "tenant");
        var adjusted = CreateAccount(1);
        adjusted.Id = inserted.Id;
        adjusted.AccountId = inserted.AccountId;
        adjusted.CurrencyCode = "JPY";
        var upserted = await repo.UpsertAccountByIdAsync(inserted.Id, adjusted, "tenant");
        var found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.Equal("JPY", found.CurrencyCode);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_IdMismatch()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = "not-the-real-id";
        toUpsert.Id = "not-the-real-id";

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullAccount()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountByIdAsync("id", null, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        account.Id = null;
        account.AccountId = null;
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountByIdAsync(null, account, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        account.Id = null;
        account.AccountId = null;
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountByIdAsync("id", account, null));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_RoutingTransitNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.AlternateIdentifiers = null;

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_TenantNotFound()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        var found = await repo.UpsertAccountByIdAsync("id", account, "tenant");
        Assert.Null(found);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_UsersIgnoredIfProvided()
    {
        var repo = CreateRepository();
        var original = CreateAccount(1);
        original.Users = new string[] { "a", "b" };

        // Initial upsert should ignore users. Since there is no user
        // assigned to the account yet, no users should be in the response.
        var upserted = await repo.UpsertAccountAsync(original, "tenant");
        Assert.Empty(upserted.Users);

        // Add a user to the account.
        await repo.AddUserToAccountAsync("user-1", upserted.Id);
        var found = await repo.GetAccountByIdAsync(upserted.Id, "tenant");
        Assert.Single(found.Users);
        Assert.Contains("user-1", found.Users);

        // Try upserting again with the set of users. It should ignore the users
        // and keep the original set.
        var id = upserted.Id;
        await repo.UpsertAccountByIdAsync(id, original, "tenant");
        found = await repo.GetAccountByIdAsync(id, "tenant");
        Assert.Single(found.Users);
        Assert.Contains("user-1", found.Users);
    }

    private static Account CreateAccount(int index, string rtn = "rtn-a")
    {
        return new Account
        {
            Number = $"an-{index}",
            Description = $"ad-{index}",
            AccountType = "CHECKING",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = rtn },
                new AlternateIdentifier { Scheme = "Index", Id = index.ToString(CultureInfo.InvariantCulture) },
            },
            CurrencyCode = "USD",
        };
    }

    private static Balance CreateBalance(int index, string accountId)
    {
        return new Balance
        {
            Id = $"balance-{index}",
            AccountId = accountId,
            BalanceType = $"bt-{index}",
            Data = new BalanceData[]
            {
                new BalanceData
                {
                    Amount = index,
                    DateTime = DateTimeOffset.Now,
                },
            },
        };
    }

    private static MemoryRepository CreateRepository()
    {
        var mapper = new MapperConfiguration(c => c.AddProfile<MappingProfile>()).CreateMapper();
        var logger = Mock.Of<ILogger<MemoryRepository>>();
        return new MemoryRepository(mapper, logger);
    }
}

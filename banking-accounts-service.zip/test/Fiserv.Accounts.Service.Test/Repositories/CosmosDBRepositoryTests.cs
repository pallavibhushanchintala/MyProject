﻿using System.Globalization;
using Fiserv.Accounts.Service.Data;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.Azure.Cosmos;
using Fiserv.Extensions.Logging;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging;

namespace Fiserv.Accounts.Service.Test.Repositories;

// This is mostly argument checks and validation. The actual tests for the Cosmos queries are integration tests.
public class CosmosDBRepositoryTests
{
    [Fact]
    public void Ctor_NullCosmosClient()
    {
        Assert.Throws<ArgumentNullException>(() => new CosmosDBRepository(null, Mock.Of<ICosmosLinqQuery>(), CreateAggregateLogger()));
    }

    [Fact]
    public void Ctor_NullCosmosLinqQuery()
    {
        Assert.Throws<ArgumentNullException>(() => new CosmosDBRepository(Mock.Of<CosmosClient>(), null, CreateAggregateLogger()));
    }

    [Fact]
    public void Ctor_NullLogger()
    {
        Assert.Throws<ArgumentNullException>(() => new CosmosDBRepository(Mock.Of<CosmosClient>(), Mock.Of<ICosmosLinqQuery>(), null));
    }

    [Fact]
    public async Task FindAccountAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var account = new Account();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.FindAccountAsync(account, "user", ""));
    }

    [Fact]
    public async Task FindAccountAsync_NullAccount()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.FindAccountAsync(null, "user", "tenant"));
    }

    [Fact]
    public async Task FindAccountAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var account = new Account();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.FindAccountAsync(account, "user", null));
    }

    [Fact]
    public async Task GetAccountByIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountByIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetAccountByIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountByIdAsync("account-1", ""));
    }

    [Fact]
    public async Task GetAccountByIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountByIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetAccountByIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountByIdAsync("account-1", null));
    }

    [Fact]
    public async Task GetAccountsAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountsAsync("user", ""));
    }

    [Fact]
    public async Task GetAccountsAsync_EmptyUserId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetAccountsAsync("", "tenant"));
    }

    [Fact]
    public async Task GetAccountsAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountsAsync("user", null));
    }

    [Fact]
    public async Task GetAccountsAsync_NullUserId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetAccountsAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetBalancesByAccountIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetBalancesByAccountIdAsync("123", ""));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetBalancesByAccountIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetBalancesByAccountIdAsync("123", null));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetProductsByAccountIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetProductsByAccountIdAsync("account-1", ""));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetProductsByAccountIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetProductsByAccountIdAsync("account-1", null));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetTransactionsByAccountIdAsync("", "tenant"));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.GetTransactionsByAccountIdAsync("123", ""));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetTransactionsByAccountIdAsync(null, "tenant"));
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.GetTransactionsByAccountIdAsync("123", null));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpdateProductsForAccountIdAsync("", Enumerable.Empty<Product>(), "tenant"));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpdateProductsForAccountIdAsync("account-1", Enumerable.Empty<Product>(), ""));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpdateProductsForAccountIdAsync(null, Enumerable.Empty<Product>(), "tenant"));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_NullProducts()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpdateProductsForAccountIdAsync("account-1", null, "tenant"));
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpdateProductsForAccountIdAsync("account-1", Enumerable.Empty<Product>(), null));
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountIdSpecified()
    {
        var toUpsert = CreateAccount(10);
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = null;
        toUpsert.AccountId = null;
        toUpsert.Number = null;
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountTypeMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = null;
        toUpsert.AccountId = null;
        toUpsert.AccountType = null;
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        account.Id = null;
        account.AccountId = null;
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(account, ""));
    }

    [Fact]
    public async Task UpsertAccountAsync_NullAccount()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountAsync(null, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        account.Id = null;
        account.AccountId = null;
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountAsync(account, null));
    }

    [Fact]
    public async Task UpsertAccountAsync_RoutingTransitNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.Id = null;
        toUpsert.AccountId = null;
        toUpsert.AlternateIdentifiers = null;
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountAsync(toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Number = null;

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountTypeMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.AccountType = null;

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_EmptyAccountId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("", account, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_EmptyTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("id", account, ""));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_IdMismatch()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = "not-the-real-id";
        toUpsert.Id = "not-the-real-id";

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullAccount()
    {
        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountByIdAsync("id", null, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullAccountId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        account.Id = null;
        account.AccountId = null;
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountByIdAsync(null, account, "tenant"));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_NullTenantId()
    {
        var repo = CreateRepository();
        var account = CreateAccount(1);
        account.Id = null;
        account.AccountId = null;
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await repo.UpsertAccountByIdAsync("id", account, null));
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_RoutingTransitNumberMissing()
    {
        var toUpsert = CreateAccount(10);
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.AlternateIdentifiers = null;

        var repo = CreateRepository();
        await Assert.ThrowsAsync<ArgumentException>(async () => await repo.UpsertAccountByIdAsync("account-1", toUpsert, "tenant"));
    }

    private static Account CreateAccount(int index, string type = "CHECKING", string rtn = "rtn-a", string user = "user-1")
    {
        return new Account
        {
            Id = $"account-{index}",
            AccountId = $"account-{index}",
            Number = $"an-{index}",
            Description = $"ad-{index}",
            AccountType = type,
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = rtn },
                new AlternateIdentifier { Scheme = "Index", Id = index.ToString(CultureInfo.InvariantCulture) },
            },

            // Users are added here because the repo is mocked - there's no other way to add users to an account.
            Users = new string[] { user },
        };
    }

    private static CosmosDBRepository CreateRepository()
    {
        return new CosmosDBRepository(Mock.Of<CosmosClient>(), Mock.Of<ICosmosLinqQuery>(), CreateAggregateLogger());
    }

    private static IAggregateLogger<CosmosDBRepository> CreateAggregateLogger()
    {
        var aggregateLogger = new Mock<IAggregateLogger<CosmosDBRepository>>();
        aggregateLogger.SetupGet(_ => _.DiagnosticLogger)
            .Returns(Mock.Of<ILogger<CosmosDBRepository>>());
        aggregateLogger.SetupGet(_ => _.AuditLogger)
            .Returns(Mock.Of<IAuditLogger<CosmosDBRepository>>());
        return aggregateLogger.Object;
    }
}

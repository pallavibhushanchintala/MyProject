using AutoMapper;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.Security.Tokenization.Development;
using Microsoft.Extensions.Logging;

namespace Fiserv.Accounts.Service.Test.Repositories;

public class StubDataPopulatorTests
{
    [Fact]
    public async Task Populate_AllowsDecoration()
    {
        var mapper = new MapperConfiguration(c => c.AddProfile<MappingProfile>()).CreateMapper();
        var logger = Mock.Of<ILogger<MemoryRepository>>();
        var repo = new TokenizationDecorator(new MemoryRepository(mapper, logger), new Tokenizer(), mapper);
        await StubDataPopulator.Populate(repo);

        var accounts = await repo.GetAccountsAsync(StubDataPopulator.UserId, StubDataPopulator.TenantId);
        Assert.Equal(3, accounts.Count());
    }

    [Fact]
    public async Task Populate_CreatesData()
    {
        var mapper = new MapperConfiguration(c => c.AddProfile<MappingProfile>()).CreateMapper();
        var logger = Mock.Of<ILogger<MemoryRepository>>();
        var repo = new MemoryRepository(mapper, logger);
        await StubDataPopulator.Populate(repo);
        var accounts = await repo.GetAccountsAsync(StubDataPopulator.UserId, StubDataPopulator.TenantId);
        Assert.Equal(3, accounts.Count());

        var checking = accounts.FirstOrDefault(a => a.AccountType == "CHECKING");
        Assert.NotNull(checking);
        var balances = await repo.GetBalancesByAccountIdAsync(checking.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(2, balances.Data.Count());
        var transactions = await repo.GetTransactionsByAccountIdAsync(checking.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(2, transactions.Data.Count());
        var products = await repo.GetProductsByAccountIdAsync(checking.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(3, products.Data.Count());

        var savings = accounts.FirstOrDefault(a => a.AccountType == "SAVINGS");
        Assert.NotNull(savings);
        balances = await repo.GetBalancesByAccountIdAsync(savings.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(2, balances.Data.Count());
        transactions = await repo.GetTransactionsByAccountIdAsync(savings.AccountId, StubDataPopulator.TenantId);
        Assert.Empty(transactions.Data);
        products = await repo.GetProductsByAccountIdAsync(savings.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(2, products.Data.Count());

        var credit = accounts.FirstOrDefault(a => a.AccountType == "CREDITLINE");
        Assert.NotNull(credit);
        balances = await repo.GetBalancesByAccountIdAsync(credit.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(2, balances.Data.Count());
        transactions = await repo.GetTransactionsByAccountIdAsync(credit.AccountId, StubDataPopulator.TenantId);
        Assert.Empty(transactions.Data);
        products = await repo.GetProductsByAccountIdAsync(credit.AccountId, StubDataPopulator.TenantId);
        Assert.Equal(2, products.Data.Count());
    }

    [Fact]
    public async Task Populate_NullRepository()
    {
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await StubDataPopulator.Populate(null));
    }
}

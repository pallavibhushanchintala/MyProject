// Don't run the integration collections in parallel or things get hung up,
// especially on the build server.
[assembly: CollectionBehavior(DisableTestParallelization = true)]

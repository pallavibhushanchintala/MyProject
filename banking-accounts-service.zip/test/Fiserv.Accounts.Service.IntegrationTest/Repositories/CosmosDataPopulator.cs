﻿using System.Globalization;
using System.Net;
using Fiserv.Accounts.Service.Data;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.Azure.Cosmos.Testing;
using Microsoft.Azure.Cosmos;
using Polly;
using Polly.Contrib.WaitAndRetry;
using Polly.Retry;

namespace Fiserv.Accounts.Service.IntegrationTest.Repositories;

/// <summary>
/// Data population to support the <see cref="CosmosDBRepositoryTests"/>.
/// </summary>
public class CosmosDataPopulator : ICosmosDataPopulator
{
    /// <summary>
    /// The tenant ID that will be populated into the database.
    /// </summary>
    public static readonly string TenantId = Guid.NewGuid().ToString();

    /// <summary>
    /// Number of times a Cosmos operation will be retried based on 408 ("request timeout") and 503 ("service unavailable") errors before we give up.
    /// </summary>
    private const int ClientErrorRetries = 20;

    private readonly AsyncRetryPolicy _clientErrorRetryPolicy;

    public CosmosDataPopulator()
    {
        this._clientErrorRetryPolicy = Policy.Handle<CosmosException>(x => x.StatusCode == HttpStatusCode.RequestTimeout || x.StatusCode == HttpStatusCode.ServiceUnavailable)
            .WaitAndRetryAsync(
                Backoff.DecorrelatedJitterBackoffV2(TimeSpan.FromSeconds(1), ClientErrorRetries));
    }

    public async Task PopulateData(CosmosClient client)
    {
        if (client == null)
        {
            throw new ArgumentNullException(nameof(client));
        }

        var database = await this.CreateDatabaseAsync(client);
        var accountsContainer = await this.CreateAccountsContainerAsync(database);
        await this.AddDataToAccountsContainerAsync(accountsContainer);
    }

    private static Account CreateAccount(int index, string type = "CHECKING", string rtn = "rtn-a", string user = "user-1")
    {
        return new Account
        {
            Id = $"account-{index}",
            AccountId = $"account-{index}",
            Number = $"an-{index}",
            Description = $"ad-{index}",
            AccountType = type,
            CurrencyCode = "USD",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = rtn },
                new AlternateIdentifier { Scheme = "Index", Id = index.ToString(CultureInfo.InvariantCulture) },
            },
            Users = new string[] { user },
        };
    }

    private static Balance CreateBalance(int index, int accountIndex, string user = "user-1")
    {
        return new Balance
        {
            Id = $"balance-{index}",
            AccountId = $"account-{accountIndex}",
            BalanceType = $"bt-{index}",
            CurrencyCode = "USD",
            Data = new BalanceData[]
            {
                new BalanceData
                {
                    Amount = index,
                    DateTime = DateTimeOffset.Now,
                },
            },
            Users = new string[] { user },
        };
    }

    private async Task AddDataToAccountsContainerAsync(Container container)
    {
        // ** TEST DATA FOR READ OPERATIONS **
        // Two accounts for `user-1`
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(CreateAccount(1)));
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(CreateAccount(2, rtn: "rtn-b")));

        // One account for `user-2`
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(CreateAccount(3, type: "CD", user: "user-2")));

        // Two balances for `account-1`
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(CreateBalance(1, 1)));
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(CreateBalance(2, 1)));

        // Balances that were rolled back for `account-1` - these should be
        // ignored. Ideally we won't end up with floating balances without
        // amounts, but if we do, we need to handle it.
        var rollback1 = CreateBalance(3, 1);
        rollback1.Data = null;
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(rollback1));

        var rollback2 = CreateBalance(4, 1);
        rollback2.Data = Array.Empty<BalanceData>();
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(rollback2));

        // One balance for `account-3`
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(CreateBalance(5, 3, "user-2")));

        // Two products for `account-1`
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(new Product { Id = "product-1", AccountId = "account-1", Scheme = "Host", Users = new string[] { "user-1" } }));
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(new Product { Id = "product-2", AccountId = "account-1", Scheme = "Detail", Users = new string[] { "user-1" } }));

        // One transaction for `account-1`
        await this._clientErrorRetryPolicy.ExecuteAsync(() => container.CreateItemAsync(new Transaction { Id = "transaction-1", AccountId = "account-1", CreditDebitIndicator = "credit", Users = new string[] { "user-1" } }));

        // ** END TEST DATA FOR READ OPERATIONS **
        // If you add data to support write operations, you can do that here.
        // Make sure it doesn't overlap the read data. Also, don't add CHECKING
        // accounts - we use CHECKING to test for finding multiple accounts by
        // type and adding more will change the number of expected accounts.
    }

    private async Task<Container> CreateAccountsContainerAsync(Database database)
    {
        var containerProperties = new ContainerProperties(CosmosContainerName.Accounts, "/accountId");
        var throughputProperties = ThroughputProperties.CreateAutoscaleThroughput(10000);
        var response = await this._clientErrorRetryPolicy.ExecuteAsync(() => database.CreateContainerIfNotExistsAsync(containerProperties, throughputProperties));
        return response.Container;
    }

    private async Task<Database> CreateDatabaseAsync(CosmosClient client)
    {
        var throughputProperties = ThroughputProperties.CreateAutoscaleThroughput(10000);
        var response = await this._clientErrorRetryPolicy.ExecuteAsync(() => client.CreateDatabaseIfNotExistsAsync(TenantId, throughputProperties));
        return response.Database;
    }
}

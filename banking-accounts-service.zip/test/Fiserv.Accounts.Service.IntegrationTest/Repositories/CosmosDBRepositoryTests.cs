﻿using Fiserv.Accounts.Service.Data;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.Azure.Cosmos;
using Fiserv.Azure.Cosmos.Testing;
using Fiserv.Extensions.Logging;
using Microsoft.Azure.Cosmos;
using Microsoft.Extensions.Logging.Abstractions;

namespace Fiserv.Accounts.Service.IntegrationTest.Repositories;

/*
 * Argument checks and things not requiring actual data are in the unit tests.
 *
 * Don't assume a particular run order for the tests.
 *
 * The tests for read operations assume the data from the data populator is
 * there and untouched. Don't modify that data.
 *
 * Don't add any CHECKING accounts during tests. We use CHECKING as a criteria
 * for testing search and adding new CHECKING accounts will break those tests.
 */
public class CosmosDBRepositoryTests : IClassFixture<CosmosEmulatorFixture<CosmosDataPopulator>>
{
    public CosmosDBRepositoryTests(CosmosEmulatorFixture<CosmosDataPopulator> fixture)
    {
        if (fixture == null)
        {
            throw new ArgumentNullException(nameof(fixture));
        }

        this.CosmosClient = fixture.CosmosClient;

        // The Cosmos DB emulator can be really slow on the build server, so we
        // increase the retries to allow the tests to execute. In production,
        // real Cosmos DB is more responsive and the default value is good for
        // general service timings.
        this.Repository = new CosmosDBRepository(this.CosmosClient, new CosmosLinqQuery(), CreateAggregateLogger(), clientErrorRetries: 20);
    }

    public CosmosClient CosmosClient { get; private set; }

    public CosmosDBRepository Repository { get; private set; }

    [Fact]
    public async Task FindAccountAsync_FiltersByAlternateIdentifiers()
    {
        var find = new Account { AlternateIdentifiers = new AlternateIdentifier[] { new AlternateIdentifier { Id = "2", Scheme = "Index" } } };
        var found = await this.Repository.FindAccountAsync(find, null, CosmosDataPopulator.TenantId);
        Assert.Collection(found, item => Assert.Equal("account-2", item.Id));
    }

    [Fact]
    public async Task FindAccountAsync_FiltersByUserId()
    {
        var account = new Account { Number = "an-1" };

        // As an app it succeeds
        var found = await this.Repository.FindAccountAsync(account, null, CosmosDataPopulator.TenantId);
        Assert.Collection(found, item => Assert.Equal("account-1", item.Id));

        // As the exact user it succeeds
        found = await this.Repository.FindAccountAsync(account, "user-1", CosmosDataPopulator.TenantId);
        Assert.Collection(found, item => Assert.Equal("account-1", item.Id));

        // User without access doesn't get the result
        found = await this.Repository.FindAccountAsync(account, "not-the-user", CosmosDataPopulator.TenantId);
        Assert.Empty(found);
    }

    [Fact]
    public async Task FindAccountAsync_MultipleMatches()
    {
        var multiMatch = new Account { AccountType = "CHECKING" };
        var found = await this.Repository.FindAccountAsync(multiMatch, null, CosmosDataPopulator.TenantId);
        Assert.Equal(2, found.Count());
    }

    [Fact]
    public async Task FindAccountAsync_SingleMatch()
    {
        var account = new Account { Number = "an-1" };
        var found = await this.Repository.FindAccountAsync(account, null, CosmosDataPopulator.TenantId);
        Assert.Collection(found, item => Assert.Equal("account-1", item.Id));
    }

    [Fact]
    public async Task GetAccountByIdAsync_AccountFound()
    {
        var found = await this.Repository.GetAccountByIdAsync("account-1", CosmosDataPopulator.TenantId);
        Assert.Equal("account-1", found.Id);
    }

    [Fact]
    public async Task GetAccountByIdAsync_AccountNotFound()
    {
        var account = await this.Repository.GetAccountByIdAsync("not-found", CosmosDataPopulator.TenantId);
        Assert.Null(account);
    }

    [Fact]
    public async Task GetAccountByIdAsync_Success()
    {
        var account = await this.Repository.GetAccountByIdAsync("account-1", CosmosDataPopulator.TenantId);
        Assert.Equal("account-1", account.Id);
    }

    [Fact]
    public async Task GetAccountsAsync_FiltersByUserId()
    {
        var coll = await this.Repository.GetAccountsAsync("user-1", CosmosDataPopulator.TenantId);
        Assert.Equal(2, coll.Count());
        coll = await this.Repository.GetAccountsAsync("user-2", CosmosDataPopulator.TenantId);
        Assert.Single(coll);
        coll = await this.Repository.GetAccountsAsync("does-not-exist", CosmosDataPopulator.TenantId);
        Assert.Empty(coll);
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_AccountNotFound()
    {
        var data = await this.Repository.GetBalancesByAccountIdAsync("not-found", CosmosDataPopulator.TenantId);
        Assert.Null(data.Account);
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_Success()
    {
        // This also tests the rollback scenario - the returned value should
        // ignore any balances that have no amount data.
        var data = await this.Repository.GetBalancesByAccountIdAsync("account-1", CosmosDataPopulator.TenantId);
        Assert.NotNull(data.Account);
        Assert.Equal(2, data.Data.Count());
    }

    [Fact]
    public async Task GetBalancesByAccountIdAsync_TimeToLiveNeverExpire()
    {
        var accountData = await this.Repository.GetBalancesByAccountIdAsync("account-1", CosmosDataPopulator.TenantId);
        Assert.NotNull(accountData);
        Assert.Contains(accountData.Data, d => d.TimeToLive == TimeToLiveValue.NeverExpire);
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_AccountNotFound()
    {
        var data = await this.Repository.GetProductsByAccountIdAsync("not-found", CosmosDataPopulator.TenantId);
        Assert.Null(data.Account);
    }

    [Fact]
    public async Task GetProductsByAccountIdAsync_Success()
    {
        var data = await this.Repository.GetProductsByAccountIdAsync("account-1", CosmosDataPopulator.TenantId);
        Assert.NotNull(data.Account);
        Assert.Equal(2, data.Data.Count());
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_AccountNotFound()
    {
        var data = await this.Repository.GetTransactionsByAccountIdAsync("not-found", CosmosDataPopulator.TenantId);
        Assert.Null(data.Account);
    }

    [Fact]
    public async Task GetTransactionsByAccountIdAsync_Success()
    {
        var data = await this.Repository.GetTransactionsByAccountIdAsync("account-1", CosmosDataPopulator.TenantId);
        Assert.NotNull(data.Account);
        Assert.Single(data.Data);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_AccountNotFound()
    {
        var result = await this.Repository.UpdateProductsForAccountIdAsync("does-not-exist", new List<Product>(), CosmosDataPopulator.TenantId);
        Assert.Null(result);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_ProductAccountIdMismatchGetsIgnored()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;

        var account = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(account);

        var productSet = new List<Product>
        {
            new Product { Id = $"product-{Guid.NewGuid()}", AccountId = $"other-account-{Guid.NewGuid()}", Scheme = "product", Value = "value" },
        };

        var productUpsert = await this.Repository.UpdateProductsForAccountIdAsync(account.Id, productSet, CosmosDataPopulator.TenantId);
        Assert.Single(productUpsert);

        var retrieved = await this.Repository.GetProductsByAccountIdAsync(account.Id, CosmosDataPopulator.TenantId);
        Assert.NotNull(retrieved.Account);
        Assert.Single(retrieved.Data);
        Assert.Contains(retrieved.Data, p => p.Scheme == "product" && p.Value == "value" && p.AccountId == account.Id);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_ReplacesExistingProducts()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;

        var account = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(account);

        var noProductsByDefault = await this.Repository.GetProductsByAccountIdAsync(account.AccountId, CosmosDataPopulator.TenantId);
        Assert.NotNull(noProductsByDefault.Account);
        Assert.Empty(noProductsByDefault.Data);

        var firstProductSet = new List<Product>
        {
            // Stay the same
            new Product { Scheme = "stay-same", Value = "$" },

            // Remove
            new Product { Scheme = "to-remove", Value = "1" },

            // Change
            new Product { Scheme = "to-change", Value = "a" },
        };
        var firstProductUpsert = await this.Repository.UpdateProductsForAccountIdAsync(account.Id, firstProductSet, CosmosDataPopulator.TenantId);
        Assert.Equal(3, firstProductUpsert.Count());
        Assert.Contains(firstProductUpsert, p => p.Scheme == "stay-same" && p.Value == "$" && p.AccountId == account.Id);
        Assert.Contains(firstProductUpsert, p => p.Scheme == "to-remove" && p.Value == "1" && p.AccountId == account.Id);
        Assert.Contains(firstProductUpsert, p => p.Scheme == "to-change" && p.Value == "a" && p.AccountId == account.Id);

        var secondProductSet = new List<Product>
        {
            // Stay the same
            new Product { Scheme = "stay-same", Value = "$" },

            // Change
            new Product { Scheme = "to-change", Value = "b" },

            // Add
            new Product { Scheme = "to-add", Value = "123" },
        };
        var secondProductUpsert = await this.Repository.UpdateProductsForAccountIdAsync(account.Id, secondProductSet, CosmosDataPopulator.TenantId);
        Assert.Equal(3, secondProductUpsert.Count());
        Assert.Contains(secondProductUpsert, p => p.Scheme == "stay-same" && p.Value == "$" && p.AccountId == account.Id);
        Assert.Contains(secondProductUpsert, p => p.Scheme == "to-change" && p.Value == "b" && p.AccountId == account.Id);
        Assert.Contains(secondProductUpsert, p => p.Scheme == "to-add" && p.Value == "123" && p.AccountId == account.Id);

        var retrieved = await this.Repository.GetProductsByAccountIdAsync(account.Id, CosmosDataPopulator.TenantId);
        Assert.NotNull(retrieved.Account);
        Assert.Equal(3, retrieved.Data.Count());
        Assert.Contains(retrieved.Data, p => p.Scheme == "stay-same" && p.Value == "$" && p.AccountId == account.Id);
        Assert.Contains(retrieved.Data, p => p.Scheme == "to-change" && p.Value == "b" && p.AccountId == account.Id);
        Assert.Contains(retrieved.Data, p => p.Scheme == "to-add" && p.Value == "123" && p.AccountId == account.Id);
    }

    [Fact]
    public async Task UpdateProductsForAccountIdAsync_TimeToLiveNeverExpire()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;

        var account = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(account);

        var noProductsByDefault = await this.Repository.GetProductsByAccountIdAsync(account.AccountId, CosmosDataPopulator.TenantId);
        Assert.NotNull(noProductsByDefault.Account);
        Assert.Empty(noProductsByDefault.Data);

        var products = new List<Product>
        {
            new Product { Scheme = "ProductCode", Value = "1" },
            new Product { Scheme = "ProductCode", Value = "2" },
        };
        var productUpsert = await this.Repository.UpdateProductsForAccountIdAsync(account.Id, products, CosmosDataPopulator.TenantId);
        Assert.Equal(2, productUpsert.Count());
        Assert.Contains(productUpsert, p => p.TimeToLive == TimeToLiveValue.NeverExpire);
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountExists()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;

        var initialInsert = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(initialInsert);
        Assert.Equal("USD", initialInsert.CurrencyCode);

        toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Number = initialInsert.Number;
        toUpsert.CurrencyCode = "ABC";
        var updated = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(updated);
        Assert.Equal("ABC", updated.CurrencyCode);

        Assert.Equal(initialInsert.Id, updated.Id);
        Assert.Equal(initialInsert.AccountId, updated.AccountId);
    }

    [Fact]
    public async Task UpsertAccountAsync_AccountIsNew()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;

        var result = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);

        Assert.NotNull(result.Id);
        Assert.NotNull(result.AccountId);
        Assert.Equal(result.Id, result.AccountId);
        Assert.Equal(toUpsert.Number, result.Number);
    }

    [Fact]
    public async Task UpsertAccountAsync_MultipleMatches()
    {
        // We need to hack the database to make this test work because, just
        // going through the repository API, we won't be able to get fully
        // duplicate accounts in place. In the real world, this can happen if
        // someone has poked data in the database or if the importer has
        // incorrectly matched an account and accidentally creates a dupe.
        var account = CreateAccount();
        account.Id = $"duplicate-{Guid.NewGuid()}";
        account.AccountId = account.Id;

        // Same number/type/RTN, different IDs.
        var duplicate = CreateAccount();
        duplicate.Id = $"duplicate-{Guid.NewGuid()}";
        duplicate.AccountId = account.Id;
        duplicate.Number = account.Number;
        duplicate.AccountType = account.AccountType;
        duplicate.AlternateIdentifiers.First(a => a.Scheme == AlternateIdentifierScheme.RoutingTransitNumber).Id = account.GetRoutingTransitNumber();

        var container = this.Repository.CosmosClient.GetDatabase(CosmosDataPopulator.TenantId).GetContainer(CosmosContainerName.Accounts);
        await container.CreateItemAsync(account);
        await container.CreateItemAsync(duplicate);

        // Now we have two accounts that both have the same magic trinity but
        // different IDs. This should cause a multiple item match and fail the
        // upsert.
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Number = account.Number;
        toUpsert.AccountType = account.AccountType;
        toUpsert.AlternateIdentifiers.First(a => a.Scheme == AlternateIdentifierScheme.RoutingTransitNumber).Id = account.GetRoutingTransitNumber();

        var result = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.Null(result);
    }

    [Fact]
    public async Task UpsertAccountAsync_UsersIgnoredIfProvided()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Users = new string[] { "new-user" };

        var result = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(result.AccountId);
        Assert.Empty(result.Users);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountFound()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        var initialInsert = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);

        toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Number = initialInsert.Number;
        toUpsert.CurrencyCode = "ABC";
        var updated = await this.Repository.UpsertAccountByIdAsync(initialInsert.Id, toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(updated);
        Assert.Equal("ABC", updated.CurrencyCode);

        Assert.Equal(initialInsert.Id, updated.Id);
        Assert.Equal(initialInsert.AccountId, updated.AccountId);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_AccountNotFound()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;

        var result = await this.Repository.UpsertAccountByIdAsync("account-not-found", toUpsert, CosmosDataPopulator.TenantId);
        Assert.Null(result);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_IdMatch()
    {
        // ID mismatch is tested by unit tests - it's an arg check.
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        var initialInsert = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);

        toUpsert = CreateAccount();
        toUpsert.AccountId = initialInsert.Id;
        toUpsert.Id = initialInsert.Id;
        toUpsert.Number = initialInsert.Number;
        toUpsert.CurrencyCode = "ABC";
        var updated = await this.Repository.UpsertAccountByIdAsync(initialInsert.Id, toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(updated);
        Assert.Equal("ABC", updated.CurrencyCode);

        Assert.Equal(initialInsert.Id, updated.Id);
        Assert.Equal(initialInsert.AccountId, updated.AccountId);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_UsersIgnoredIfProvided()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        var initialInsert = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);

        toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        toUpsert.Users = new string[] { "new-user" };
        var updated = await this.Repository.UpsertAccountByIdAsync(initialInsert.Id, toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(updated);
        Assert.Empty(updated.Users);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_TimeToLiveNeverExpire()
    {
        var toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        var initialInsert = await this.Repository.UpsertAccountAsync(toUpsert, CosmosDataPopulator.TenantId);

        toUpsert = CreateAccount();
        toUpsert.AccountId = null;
        toUpsert.Id = null;
        var updated = await this.Repository.UpsertAccountByIdAsync(initialInsert.Id, toUpsert, CosmosDataPopulator.TenantId);
        Assert.NotNull(updated);
        Assert.Equal(TimeToLiveValue.NeverExpire, updated.TimeToLive);
    }

    private static Account CreateAccount()
    {
        var index = Guid.NewGuid();
        return new Account
        {
            Id = $"account-{index}",
            AccountId = $"account-{index}",
            Number = $"an-{index}",
            Description = $"ad-{index}",
            AccountType = "CD",
            CurrencyCode = "USD",
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn-a" },
                new AlternateIdentifier { Scheme = "Index", Id = index.ToString() },
            },
        };
    }

    private static IAggregateLogger<CosmosDBRepository> CreateAggregateLogger()
    {
        return new AggregateLogger<CosmosDBRepository>(new NullLogger<CosmosDBRepository>(), new AuditLogger<CosmosDBRepository>(NullLoggerProvider.Instance));
    }
}

using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Fiserv.Accounts.Service.Models;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.AspNetCore.Mvc.Testing;
using Fiserv.Core.Encoding.UTF8;

namespace Fiserv.Accounts.Service.IntegrationTest.Controllers;

public class AccountsControllerTests : IClassFixture<TestEntryPointFixture<Startup>>
{
    /// <summary>
    /// Pre-encoded header that indicates the JWT is not signed.
    /// </summary>
    private const string JwtNoSignatureHeader = "eyJ0eXAiOiJKV1QiLCJhbGciOiJub25lIn0";

    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        Converters =
        {
            new JsonStringEnumConverter(),
        },
    };

    private readonly TestEntryPointFixture<Startup> _fixture;

    public AccountsControllerTests(TestEntryPointFixture<Startup> fixture)
    {
        this._fixture = fixture ?? throw new ArgumentNullException(nameof(fixture));
        this._fixture.Initialize(config =>
        {
            config.UseSetting("environment", "Development");
            config.UseSetting("managementPort", "4709");
        });
        this.HttpClient = this._fixture.HttpClient;
    }

    public HttpClient HttpClient
    {
        get;
    }

    [Fact]
    public async Task GetAccountByIdAsync_NoToken()
    {
        var id = await this.GetValidAccountIdForUserAsync();
        var ex = await Assert.ThrowsAsync<HttpRequestException>(async () => await this.HttpClient.GetStringAsync($"/consumer/banking/v1/accounts/{id}"));
        Assert.Equal(HttpStatusCode.Unauthorized, ex.StatusCode);
    }

    [Theory]
    [MemberData(nameof(TokenAndIdCombinations))]
    public async Task GetAccountByIdAsync_ValidatesAccess(string token, string specifiedUserId, HttpStatusCode expectedResponseCode)
    {
        var id = await this.GetValidAccountIdForUserAsync();
        var idParam = specifiedUserId == null ? null : $"?userId={specifiedUserId}";
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/consumer/banking/v1/accounts/{id}{idParam}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(expectedResponseCode, response.StatusCode);
    }

    [Theory]
    [MemberData(nameof(GetAccountsTokenCombinations))]
    public async Task GetAccountsAsync_ValidatesAccess(string token, string specifiedUserId, HttpStatusCode expectedResponseCode)
    {
        var idParam = specifiedUserId == null ? null : $"?userId={specifiedUserId}";
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/consumer/banking/v1/accounts{idParam}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(expectedResponseCode, response.StatusCode);
    }

    [Theory]
    [MemberData(nameof(TokenAndIdCombinations))]
    public async Task GetBalancesByAccountIdAsync_ValidatesAccess(string token, string specifiedUserId, HttpStatusCode expectedResponseCode)
    {
        var id = await this.GetValidAccountIdForUserAsync();
        var idParam = specifiedUserId == null ? null : $"?userId={specifiedUserId}";
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/consumer/banking/v1/accounts/{id}/balances{idParam}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(expectedResponseCode, response.StatusCode);
    }

    [Theory]
    [MemberData(nameof(TokenAndIdCombinations))]
    public async Task GetProductsByAccountIdAsync_ValidatesAccess(string token, string specifiedUserId, HttpStatusCode expectedResponseCode)
    {
        var id = await this.GetValidAccountIdForUserAsync();
        var idParam = specifiedUserId == null ? null : $"?userId={specifiedUserId}";
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/consumer/banking/v1/accounts/{id}/products{idParam}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(expectedResponseCode, response.StatusCode);
    }

    [Theory]
    [MemberData(nameof(TokenAndIdCombinations))]
    public async Task GetTransactionsByAccountIdAsync_ValidatesAccess(string token, string specifiedUserId, HttpStatusCode expectedResponseCode)
    {
        var id = await this.GetValidAccountIdForUserAsync();
        var idParam = specifiedUserId == null ? null : $"?userId={specifiedUserId}";
        using var request = new HttpRequestMessage(HttpMethod.Get, $"/consumer/banking/v1/accounts/{id}/transactions{idParam}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(expectedResponseCode, response.StatusCode);
    }

    [Fact]
    public async Task SearchForAccountAsync_FiltersByUserAccess()
    {
        // This relies on the stub data populator setting up a CHECKING account
        // that isn't attached to the user.
        using var request = new HttpRequestMessage(HttpMethod.Post, "/supplier/banking/v1/accounts/search");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", CreateToken());
        request.Content = new StringContent("{\"accountType\":\"CHECKING\"}", Encoding.UTF8, "application/json");
        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var accounts = await JsonSerializer.DeserializeAsync<IEnumerable<AccountResponse>>(await response.Content.ReadAsStreamAsync(), SerializerOptions);
        Assert.Single(accounts);
    }

    [Fact]
    public async Task UpdateProductsByAccountIdAsync_UserNotAllowed()
    {
        var id = await this.GetValidAccountIdForUserAsync();
        using var request = new HttpRequestMessage(HttpMethod.Put, $"/supplier/banking/v1/accounts/{id}/products");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", CreateToken());

        // Specify an empty set of products - shouldn't matter since it's not going to update.
        request.Content = new StringContent("[]", Encoding.UTF8, "application/json");

        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountAsync_UserNotAllowed()
    {
        using var request = new HttpRequestMessage(HttpMethod.Put, "/supplier/banking/v1/accounts");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", CreateToken());

        var putBody = CreateAccountPutRequest(1);
        request.Content = new StringContent(putBody, Encoding.UTF8, "application/json");

        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task UpsertAccountByIdAsync_UserNotAllowed()
    {
        var account = await this.GetValidAccountForUserAsync();
        using var request = new HttpRequestMessage(HttpMethod.Put, $"/supplier/banking/v1/accounts/{account.Id}");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", CreateToken());

        var putBody = CreateAccountPutRequest(account);
        Console.WriteLine(putBody);
        request.Content = new StringContent(putBody, Encoding.UTF8, "application/json");

        var response = await this.HttpClient.SendAsync(request);
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    private static string CreateAccountPutRequest(int index)
    {
        var account = new AccountResponse
        {
            Number = $"an-{index}",
            AccountType = AccountType.CHECKING,
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier { Scheme = AlternateIdentifierScheme.RoutingTransitNumber, Id = "rtn" },
            },
            Asset = true,
            Currency = "USD",
            Status = AccountStatus.Active,
        };

        return CreateAccountPutRequest(account);
    }

    private static string CreateAccountPutRequest(AccountResponse toUpdate)
    {
        var request = new AccountPutRequest
        {
            Number = toUpdate.Number,
            AccountType = toUpdate.AccountType,
            AlternateIdentifiers = new AlternateIdentifier[]
            {
                new AlternateIdentifier
                {
                    Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    Id = toUpdate.AlternateIdentifiers.First(x => x.Scheme == AlternateIdentifierScheme.RoutingTransitNumber).Id,
                },
            },
            Asset = toUpdate.Asset,
            Currency = toUpdate.Currency,
            Status = toUpdate.Status,
        };

        return JsonSerializer.Serialize(request, SerializerOptions);
    }

    private async Task<AccountResponse> GetValidAccountForUserAsync()
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, "/consumer/banking/v1/accounts");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", CreateToken());
        var response = await this.HttpClient.SendAsync(request);
        response.EnsureSuccessStatusCode();
        var allAccounts = await JsonSerializer.DeserializeAsync<IEnumerable<AccountResponse>>(await response.Content.ReadAsStreamAsync(), SerializerOptions);
        return allAccounts.First();
    }

    private async Task<string> GetValidAccountIdForUserAsync()
    {
        var account = await this.GetValidAccountForUserAsync();
        return account.Id;
    }

    /// <summary>
    /// Getting a list of accounts requires there to be an acting user ID. Based
    /// on the combination of application/user principal and specified user ID,
    /// we can expect different results.
    /// </summary>
    [SuppressMessage("CA1024", "CA1024", Justification = "This is a data provider method, not a property.")]
    [SuppressMessage("SA1202", "SA1202", Justification = "Data provider methods shouldn't take precedence over the tests.")]
    [SuppressMessage("SA1204", "SA1204", Justification = "Data provider methods shouldn't take precedence over the tests.")]
    public static IEnumerable<object[]> GetAccountsTokenCombinations()
    {
        // We don't need to test "no principal" or "unauthenticated" because the
        // [Authorize] attribute on the controller handles that.

        // Application acting as application isn't allowed - bad request
        yield return new object[]
        {
            CreateToken(null),
            null,
            HttpStatusCode.BadRequest,
        };

        // Application acting as a user with no accounts - that's OK even if the user doesn't exist
        yield return new object[]
        {
            CreateToken(null),
            "no-accounts",
            HttpStatusCode.OK,
        };

        // Application acting as user with accounts - OK
        yield return new object[]
        {
            CreateToken(null),
            StubDataPopulator.UserId,
            HttpStatusCode.OK,
        };

        // User that doesn't have any accounts - OK (they couldn't get a principal if they didn't have an identity)
        yield return new object[]
        {
            CreateToken("no-accounts"),
            null,
            HttpStatusCode.OK,
        };

        // User specifying someone else's ID - not allowed
        yield return new object[]
        {
            CreateToken(),
            "other-user",
            HttpStatusCode.Forbidden,
        };

        // User acting as themselves - OK
        yield return new object[]
        {
            CreateToken(),
            null,
            HttpStatusCode.OK,
        };

        // User specifying their own ID - weird, but OK
        yield return new object[]
        {
            CreateToken(),
            StubDataPopulator.UserId,
            HttpStatusCode.OK,
        };
    }

    /// <summary>
    /// Provides combinations of principal, specified user ID, and expected
    /// authentication-related response code when attempting to access one of
    /// the stub data user's accounts. Assumes applications are allowed to act
    /// as applications (no acting user ID is required).
    /// </summary>
    [SuppressMessage("SA1202", "SA1202", Justification = "Data provider methods shouldn't take precedence over the tests.")]
    [SuppressMessage("SA1204", "SA1204", Justification = "Data provider methods shouldn't take precedence over the tests.")]
    public static IEnumerable<object[]> TokenAndIdCombinations()
    {
        // We don't need to test "no principal" or "unauthenticated" because the
        // [Authorize] attribute on the controller handles that.

        // Application acting as application - OK
        yield return new object[]
        {
            CreateToken(null),
            null,
            HttpStatusCode.OK,
        };

        // Application acting as a user without access to the accounts - not allowed
        yield return new object[]
        {
            CreateToken(null),
            "no-access",
            HttpStatusCode.Forbidden,
        };

        // Application acting as the stub user - OK
        yield return new object[]
        {
            CreateToken(null),
            StubDataPopulator.UserId,
            HttpStatusCode.OK,
        };

        // User that doesn't have access to the stub user's accounts - not allowed
        yield return new object[]
        {
            CreateToken("no-access"),
            null,
            HttpStatusCode.Forbidden,
        };

        // User specifying someone else's ID - not allowed
        yield return new object[]
        {
            CreateToken(),
            "other-user",
            HttpStatusCode.Forbidden,
        };

        // User with access acting as themselves - OK
        yield return new object[]
        {
            CreateToken(),
            null,
            HttpStatusCode.OK,
        };

        // User with access specifying their own ID - weird, but OK
        yield return new object[]
        {
            CreateToken(),
            StubDataPopulator.UserId,
            HttpStatusCode.OK,
        };
    }

    private static string CreateToken(string subject = StubDataPopulator.UserId)
    {
        var subClaim = subject == null ? null : $",\"sub\":\"{subject}\"";
        var body = $"{{\"client_id\":\"client\",\"iat\":1516239022,\"tid\":\"{StubDataPopulator.TenantId}\"{subClaim}}}".ToBase64().TrimEnd('=');
        return $"{JwtNoSignatureHeader}.{body}.";
    }
}

# Banking: Accounts Service

This microservice in the `banking` bounded context provides bank account balances and related information for a user.

## Build and Test

### Local

The `default.proj` can run a full build and unit test cycle with coverage. It is recommended you run it with `dotnet msbuild` rather than native `msbuild` due to [an issue where native MSBuild incorrectly handles escape sequences and messes up coverage](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/MSBuildIntegration.md#note-for-linux-users).

```powershell
# Build, full test run, and package
dotnet msbuild ./default.proj

# Run all the tests including local integration tests
dotnet test ./Fiserv.Accounts.Service.sln

# Run only unit tests, no integration tests
dotnet test ./Fiserv.Accounts.Service.sln --filter FullyQualifiedName!~IntegrationTest

# Launch the service in a local development mode
dotnet run --project ./src/Fiserv.Accounts.Service --launch-profile Development

# Local build of the service container
docker build -t "accounts-local" ./artifacts/package/Fiserv.Accounts.Service

# Start up the container in local dev mode on port 4708
docker run `
  --rm `
  -p 4708:4708 `
  -p 4709:4709 `
  -d `
  -e ASPNETCORE_ENVIRONMENT='Development' `
  -e ASPNETCORE_MANAGEMENTPORT='4709' `
  -e ASPNETCORE_URLS='http://*:4708;http://*:4709' `
  accounts-local

# Run the development version of the integration tests against a service
# running on localhost (either also in a container or in a dev environment).
# Note `host.docker.internal` is the way to access the machine that is
# running Docker; `localhost` would actually be inside the Docker container.
#
# You can use an image from the ACR or a locally-built image.
# $image = "acrdsl1centralus.azurecr.io/digital-nexus/banking/accounts/functional-test:sha-hash-here"
$image = "accounts-service-integration"
docker run `
  --rm `
  $image `
  run banking-v1-accounts.postman_collection.json `
  -e banking-v1-accounts.Development.postman_environment.json `
  --env-var endpoint_accounts=http://host.docker.internal:4708
```

If you run the service with the environment set to `Development` it will provide more robust logging and will execute against stub services rather than calling out to a real data store. Integration tests in the `banking-accounts-tests` repo have a corresponding `Development` environment for Postman that should allow the tests to succeed.

By default, a `Development` configuration will use a simple development tokenizer for encryption that only wraps encrypted values in `[]` brackets. Voltage can be used in a `Development` configuration if you set a configuration value `voltage:enabled = true` and set the user secrets for Voltage as noted in the "Running in Integration" section, below. You do not need to set `voltage:enabled = true` in `Production` - it will _always only_ use Voltage.

### Running in Integration

Running the service with the environment set to `Production` will enable you to connect to a real running data store, which [includes the Azure Cosmos DB emulator](https://docs.microsoft.com/en-us/azure/cosmos-db/local-emulator) and Voltage. **Do not check in credentials. Do not add them to appsettings.json.** Instead, we use [user secrets](https://docs.microsoft.com/en-us/aspnet/core/security/app-secrets?view=aspnetcore-5.0&tabs=linux).

You'll need to get your connection details for Cosmos DB from the Azure Portal and a Voltage service account, then...

```powershell
dotnet user-secrets `
  set "cosmos:authorizationKey" "put-the-authorization-key-here" `
  --project "src/Fiserv.Accounts.Service"
dotnet user-secrets `
  set "cosmos:endpointUrl" "your-cosmos-uri" `
  --project "src/Fiserv.Accounts.Service"
dotnet user-secrets `
  set "voltage:username" "SVC-VOLT-UAID-FXXXX" `
  --project "src/Fiserv.Accounts.Service"
dotnet user-secrets `
  set "voltage:password" "your-voltage-account-password" `
  --project "src/Fiserv.Accounts.Service"
```

Now when you run the application, these will be available just like you'd put them in `appsettings.json` but you won't accidentally check them in. This also allows you to have your own instances of these services in Azure such that you won't stomp on "real data" or anyone else doing testing.

You can specify a Voltage endpoint by setting `voltage:environment` to `Development`, `Staging`, or `Production`. By default, the Voltage endpoint will match the ASP.NET environment.

﻿using System.Text.Json;
using System.Text.Json.Serialization;
using Autofac;
using AutoMapper;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.AspNetCore.Authentication;
using Fiserv.AspNetCore.Diagnostics.HealthChecks;
using Fiserv.AspNetCore.Http.Routing;
using Fiserv.AspNetCore.Mvc.ApiExplorer;
using Fiserv.AspNetCore.Mvc.Infrastructure;
using Fiserv.Azure.Cosmos;
using Hellang.Middleware.ProblemDetails;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.FileProviders.Physical;
using OpenTelemetry;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;
using Serilog;

namespace Fiserv.Accounts.Service;

/// <summary>
/// Startup logic for the microservice pipeline.
/// </summary>
[ExcludeFromCodeCoverage]
public class Startup
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Startup"/> class.
    /// </summary>
    /// <param name="configuration">
    /// The <see cref="IConfiguration"/> built by the host.
    /// </param>
    /// <param name="env">
    /// The <see cref="IWebHostEnvironment"/> containing execution environment information.
    /// </param>
    public Startup(IConfiguration configuration, IWebHostEnvironment env)
    {
        Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        HostEnvironment = env ?? throw new ArgumentNullException(nameof(env));
        BinFileProvider = new PhysicalFileProvider(Path.GetDirectoryName(new Uri(typeof(Startup).Assembly.Location).LocalPath), ExclusionFilters.None);

        var (uaid, application) = configuration.GetApplicationProperties();
        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .EnrichWithEnhancedLoggingData(uaid, application)
            .CreateLogger();
    }

    /// <summary>
    /// Gets or sets the file provider for the 'bin' folder.
    /// </summary>
    /// <value>
    /// An <see cref="IFileProvider"/> that can be used to access files and
    /// folders in the application 'bin' folder.
    /// </value>
    public static IFileProvider BinFileProvider { get; set; }

    /// <summary>
    /// Gets or sets the application configuration.
    /// </summary>
    /// <value>
    /// An <see cref="IConfiguration"/> containing application configuration.
    /// </value>
    public static IConfiguration Configuration { get; set; }

    /// <summary>
    /// Gets or sets the host environment.
    /// </summary>
    /// <value>
    /// An <see cref="IWebHostEnvironment"/> containing execution environment information.
    /// </value>
    public static IWebHostEnvironment HostEnvironment { get; set; }

    /// <summary>
    /// Called by the ASP.NET Core startup loader after all services are registered
    /// with dependency injection. Configures the application pipeline.
    /// </summary>
    /// <param name="app">
    /// The <see cref="IApplicationBuilder"/> used to create the application pipeline.
    /// </param>
    /// <param name="configuration">
    /// The <see cref="IConfiguration"/> with application configuration settings.
    /// </param>
    /// <param name="provider">
    /// The <see cref="IApiDescriptionProvider"/> that discovers registered API versions.
    /// </param>
    public static void Configure(IApplicationBuilder app, IConfiguration configuration, IApiVersionDescriptionProvider provider)
    {
        ArgumentNullException.ThrowIfNull(app);
        ArgumentNullException.ThrowIfNull(configuration);
        ArgumentNullException.ThrowIfNull(provider);

        var managementPort = configuration.GetManagementPort();
        var healthOptions = new HealthCheckOptions
        {
            AllowCachingResponses = true,
            ResponseWriter = HealthCheckResponseWriter.WriteReport,
        };

        app.UseContainerIpAddress()
            .UsePort(
                managementPort,
                management =>
                {
                    // Branch the pipeline and put all the management port things on it.
                    management.UseHealthChecks("/healthz", healthOptions);
                    management.UseOpenTelemetryPrometheusScrapingEndpoint();
                })
            .UseHeaderPropagation()
            .Use(async (context, next) =>
                {
                    // OWASP zaproxy scanner 10021
                    context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                    await next();
                })
            .UseProblemDetails()
            .UseFiservSwagger(provider)
            .UseRouting()
            .UseAuthentication()
            .UseAuthorization()
            .UseEndpoints(endpoints =>
                {
                    endpoints.MapControllers();
                });
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after <see cref="ConfigureServices(IServiceCollection)"/>
    /// to register services directly with Autofac. Items registered here may override
    /// things registered in <see cref="ConfigureServices(IServiceCollection)"/>.
    /// </summary>
    /// <param name="builder">
    /// The <see cref="Autofac.ContainerBuilder"/> used to register services with Autofac.
    /// </param>
    public static void ConfigureContainer(Autofac.ContainerBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        var (uaid, application) = Configuration.GetApplicationProperties();
        builder.RegisterFiservAuditLogger(Configuration, uaid, application);
        builder.RegisterFiservAggregateLogger();
        builder.RegisterDecorator<TokenizationDecorator, IDataRepository>();
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after <see cref="ConfigureServices(IServiceCollection)"/>
    /// to register services directly with Autofac. Items registered here may override
    /// things registered in <see cref="ConfigureServices(IServiceCollection)"/>.
    /// </summary>
    /// <param name="builder">
    /// The <see cref="Autofac.ContainerBuilder"/> used to register services with Autofac.
    /// </param>
    public static void ConfigureDevelopmentContainer(Autofac.ContainerBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        ConfigureContainer(builder);
        builder.RegisterType<CosmosLinqQuery>().As<ICosmosLinqQuery>();
        builder.RegisterType<MemoryRepository>().As<IDataRepository>().SingleInstance();
        builder.RegisterBuildCallback(scope =>
        {
            var repo = scope.Resolve<IDataRepository>();
            var task = StubDataPopulator.Populate(repo);
            task.Wait();
        });
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after <see cref="ConfigureServices(IServiceCollection)"/>
    /// to register services directly with Autofac. Items registered here may override
    /// things registered in <see cref="ConfigureServices(IServiceCollection)"/>.
    /// </summary>
    /// <param name="builder">
    /// The <see cref="Autofac.ContainerBuilder"/> used to register services with Autofac.
    /// </param>
    public static void ConfigureProductionContainer(Autofac.ContainerBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        ConfigureContainer(builder);
        builder.RegisterType<CosmosLinqQuery>().As<ICosmosLinqQuery>();
        builder.RegisterType<CosmosDBRepository>().As<IDataRepository>();
        builder.Register((s) =>
        {
            (var endpointUrl, var authorizationKey) = Configuration.GetCosmosDbCredentials();
            var clientBuilder = new CosmosClientBuilder(endpointUrl, authorizationKey)
            .WithSerializerOptions(new CosmosSerializationOptions
            {
                PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase,
            })
            .WithConnectionModeGateway();

            return clientBuilder.Build();
        }).SingleInstance();
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after startup begins to register services
    /// with the generic .NET Core dependency management system. Items registered here
    /// will end up in the Autofac container and may be overridden by
    /// <see cref="ConfigureProductionContainer(Autofac.ContainerBuilder)"/> or
    /// <see cref="ConfigureDevelopmentContainer(Autofac.ContainerBuilder)"/>.
    /// </summary>
    /// <param name="services">
    /// The <see cref="IServiceCollection"/> used to register services with .NET Core
    /// dependency management.
    /// </param>
    public static void ConfigureServices(IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);

        services.AddIstioAuthentication();
        services
            .AddTransient<IApiDescriptionProvider, ApiDescriptionProvider>()
            .AddSingleton<Microsoft.AspNetCore.Mvc.Infrastructure.ProblemDetailsFactory, CustomProblemDetailsFactory>()
            .AddSingleton<IHttpContextAccessor, HttpContextAccessor>()
            .AddTokenizer(Configuration, HostEnvironment, BinFileProvider)
            .AddAutoMapper(typeof(Startup))
            .AddFiservHeaderPropagation()
            .AddProblemDetails()
            .AddFiservSwagger("Fiserv.Accounts.Service")
            .AddApiVersioning(options =>
                {
                    options.ReportApiVersions = true;
                })
            .AddVersionedApiExplorer(options =>
                {
                    options.GroupNameFormat = "'v'V";
                    options.SubstituteApiVersionInUrl = true;
                })
            .AddControllers(opt =>
                {
                    opt.Conventions.Add(new RouteTokenTransformerConvention(new CamelCaseParameterTransformer()));
                })
            .AddJsonOptions(opt =>
                {
                    opt.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                    opt.JsonSerializerOptions.Converters.Add(new JsonStringEnumMemberConverter(JsonNamingPolicy.CamelCase));
                });

        services
            .AddHealthChecks()
            .WithStandardReportFormat();

        services
            .NormalizeAspNetCoreTracingDisplayNames()
            .NormalizeHttpClientTracingDisplayNames()
            .IncludeIdentityWithTrace()
            .IgnoreTelemetryFromPaths("/favicon.ico", "/healthz", "/metrics")
            .AddOpenTelemetry()
            .WithMetrics(builder =>
                builder
                    .SetResourceBuilder(Configuration)
                    .AddStandardAspNetCoreMetrics())
            .WithTracing(builder =>
                builder
                    .SetResourceBuilder(Configuration)
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .SetErrorStatusOnException()
                    .AddOtlpExporterIf(Configuration.IsOpenTelemetryTraceExporterEnabled)
                    .AddConsoleExporterIf(Configuration.IsConsoleTraceExporterEnabled))
            .StartWithHost();
    }
}

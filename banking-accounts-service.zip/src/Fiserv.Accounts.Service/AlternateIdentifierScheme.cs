namespace Fiserv.Accounts.Service;

/// <summary>
/// Constants with well-known alternate identifier schemes.
/// </summary>
public static class AlternateIdentifierScheme
{
    /// <summary>
    /// The value for the alternate identifier scheme that indicates a routing transit number (RTN).
    /// </summary>
    public const string RoutingTransitNumber = "RTN";
}

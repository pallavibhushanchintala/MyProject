﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Indicates the running balance for a transaction.
/// </summary>
[ExcludeFromCodeCoverage]
public class RunningBalance
{
    /// <summary>
    /// Gets or sets running balance amount.
    /// </summary>
    /// <value>
    /// An <see cref="Amount"/> indicating the amount of money (currency, quantity) associated with the balance.
    /// </value>
    [JsonProperty("amount")]
    public Amount Amount { get; set; }

    /// <summary>
    /// Gets or sets the credit/debit indicator for the balance.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating whether this balance value is a
    /// <c>credit</c> (e.g., net positive in an asset account) or <c>debit</c> (e.g.,
    /// net negative in an asset account). Credit and debit may be relative
    /// to the account type. If the balance has a zero <see cref="Amount"/>
    /// the balance is considered a credit.
    /// </value>
    [JsonProperty("creditDebitIndicator")]
    public string CreditDebitIndicator { get; set; }
}

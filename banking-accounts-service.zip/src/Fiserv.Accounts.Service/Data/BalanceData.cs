﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Data about an imported balance value for an account.
/// </summary>
public class BalanceData
{
    /// <summary>
    /// Gets or sets the ID of the batch for the balance.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that identifies the batch import that brought
    /// this balance data into the document.
    /// </value>
    [JsonProperty("batchId")]
    public string BatchId { get; set; }

    /// <summary>
    /// Gets or sets balance amount.
    /// </summary>
    /// <value>
    /// A <see cref="double"/> currency amount associated with the balance.
    /// The currency code for the balance is stored in the parent/owning
    /// balance document.
    /// </value>
    [JsonProperty("amount")]
    public double Amount { get; set; }

    /// <summary>
    /// Gets or sets effective balance date.
    /// </summary>
    /// <value>
    /// A <see cref="DateTimeOffset"/> when the balance was current; the 'as-of' date.
    /// </value>
    [JsonProperty("dateTime")]
    public DateTimeOffset DateTime { get; set; }
}

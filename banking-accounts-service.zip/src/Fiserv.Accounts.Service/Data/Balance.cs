﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Document that stores an account balance set in a document database.
/// </summary>
[ExcludeFromCodeCoverage]
public class Balance : Document
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Balance"/> class.
    /// </summary>
    public Balance()
    {
        this.Type = DocumentType.Balance;
        this.TimeToLive = TimeToLiveValue.NeverExpire;
    }

    /// <summary>
    /// Gets or sets the ISO 20022 balance type code.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the balance type as one of the standard four-character ISO 20022 type codes.
    /// </value>
    [JsonProperty("balanceType")]
    public string BalanceType { get; set; }

    /// <summary>
    /// Gets or sets the currency type associated with the balance.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the ISO 4217 currency code for the
    /// balance. Values in the <see cref="Data"/> are expressed in this
    /// currency type.
    /// </value>
    [JsonProperty("currencyCode")]
    public string CurrencyCode { get; set; }

    /// <summary>
    /// Gets or sets the list of balance values.
    /// </summary>
    /// <value>
    /// An <see cref="ICollection{T}"/> of values, each of which is the amount
    /// associated with the balance. One value gets added to this list for
    /// every batch import that occurs.
    /// </value>
    [JsonProperty("data")]
    public IEnumerable<BalanceData> Data { get; set; } = new List<BalanceData>();
}

﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Model for a financial transaction.
/// </summary>
[ExcludeFromCodeCoverage]
public class Transaction : Document
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Transaction"/> class.
    /// </summary>
    public Transaction()
    {
        this.Type = DocumentType.Transaction;
    }

    /// <summary>
    /// Gets or sets the ID of the batch for the transaction.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that identifies the batch import that brought
    /// this transaction data into the database.
    /// </value>
    [JsonProperty("batchId")]
    public string BatchId { get; set; }

    /// <summary>
    /// Gets or sets the amount of money in the transaction.
    /// </summary>
    /// <value>
    /// An <see cref="Amount"/> indicating the amount of money (currency, quantity) associated with the transaction.
    /// </value>
    [JsonProperty("amount")]
    public Amount Amount { get; set; }

    /// <summary>
    /// Gets or sets the running balance.
    /// </summary>
    /// <value>
    /// A <see cref="RunningBalance"/> containing the balance of the
    /// associated account after the transaction occurred. To be relevant,
    /// transactions need to be viewed in a sorted order (e.g., by
    /// <see cref="PostedDateTime"/>).
    /// </value>
    [JsonProperty("balance")]
    public RunningBalance Balance { get; set; }

    /// <summary>
    /// Gets or sets the credit/debit indicator for the transaction.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating whether this transaction is a
    /// <c>credit</c> (e.g., deposit in an asset account) or <c>debit</c> (e.g.,
    /// withdrawal from an asset account). Credit and debit may be relative
    /// to the account type. If the transaction has a zero <see cref="Amount"/>
    /// the transaction is considered a credit.
    /// </value>
    [JsonProperty("creditDebitIndicator")]
    public string CreditDebitIndicator { get; set; }

    /// <summary>
    /// Gets or sets the customer reference number (e.g., check number).
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that helps an individual customer identify
    /// the transaction. For check-based transactions, this will be the
    /// check number. Other contexts may warrant different reference
    /// numbers.
    /// </value>
    [JsonProperty("customerReferenceNumber")]
    public string CustomerReferenceNumber { get; set; }

    /// <summary>
    /// Gets or sets a description of the transaction in freeform text.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that describes the transaction, for example
    /// the location in which the transaction took place. This value may
    /// include sensitive information like phone numbers or account numbers
    /// in plaintext.
    /// </value>
    [JsonProperty("description")]
    public string Description { get; set; }

    /// <summary>
    /// Gets or sets the effective (arrival) time of the transaction.
    /// </summary>
    /// <value>
    /// A <see cref="DateTimeOffset"/> when the transaction entry came into the account servicer. Sometimes referred to as booking date/time.
    /// </value>
    [JsonProperty("effectiveDateTime")]
    public DateTimeOffset? EffectiveDateTime { get; set; }

    /// <summary>
    /// Gets or sets the posted (completed) time of the transaction.
    /// </summary>
    /// <value>
    /// A <see cref="DateTimeOffset"/> at which assets became available to
    /// the account owner in case of a credit entry, or cease to be
    /// available to the account owner in case of a debit transaction entry.
    /// Sometimes referred to as value date/time.
    /// </value>
    [JsonProperty("postedDateTime")]
    public DateTimeOffset PostedDateTime { get; set; }

    /// <summary>
    /// Gets or sets transaction status.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating the relative active status of a
    /// transaction. Options include <c>pending</c> for in-progress
    /// transactions and <c>posted</c> for complete transactions.
    /// </value>
    [JsonProperty("status")]
    public string Status { get; set; }

    /// <summary>
    /// Gets or sets ISO 20022 transaction code.
    /// </summary>
    /// <value>
    /// A <see cref="TransactionCode"/> with the normalized ISO 20022 code
    /// describing the transaction.
    /// </value>
    [JsonProperty("transactionCode")]
    public TransactionCode TransactionCode { get; set; }
}

﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// The amount of money associated with a balance or transaction.
/// </summary>
public class Amount
{
    /// <summary>
    /// Gets or sets the currency type associated with the data.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the ISO 4217 currency code for the data.
    /// For example, if the data is associated with a transaction, this is
    /// the currency in which the transaction occurred.
    /// </value>
    [JsonProperty("currencyCode")]
    public string CurrencyCode { get; set; }

    /// <summary>
    /// Gets or sets currency quantity.
    /// </summary>
    /// <value>
    /// A <see cref="double"/> of monetary units specified in an active
    /// currency where the unit of currency is explicit and compliant with
    /// ISO 4217.
    /// </value>
    [JsonProperty("value")]
    public double Value { get; set; }
}

﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Model for data being returned from the data store for an account.
/// </summary>
[ExcludeFromCodeCoverage]
public class Account : Document
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Account"/> class.
    /// </summary>
    public Account()
    {
        this.Type = DocumentType.Account;
        this.TimeToLive = TimeToLiveValue.NeverExpire;
    }

    /// <summary>
    /// Gets or sets the OFX account type.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with one of the normalized OFX account types describing this account.
    /// </value>
    [JsonProperty("accountType")]
    public string AccountType { get; set; }

    /// <summary>
    /// Gets or sets alternate/external IDs for the account.
    /// </summary>
    /// <value>
    /// An <see cref="IEnumerable{T}"/> of objects that serve as a means of
    /// identifying the account like IBAN, BBAN, or routing number (RTN).
    /// Not all of these uniquely identify this specific account; they may
    /// be secondary identifiers like the financial institution routing
    /// number.
    /// </value>
    [JsonProperty("alternateIdentifiers")]
    public IEnumerable<AlternateIdentifier> AlternateIdentifiers { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether account is an asset or liability.
    /// </summary>
    /// <value>
    /// <see langword="true"/> if the account is an asset (e.g., checking,
    /// savings); <see langword="false"/> if the account is a liability
    /// (e.g., loan).
    /// </value>
    /// <remarks>
    /// <para>
    /// While documents in the data store will always have the asset flag set,
    /// this object is also used as a method to query the data store for
    /// matching account properties and there needs to be a way to specify "we
    /// don't care about asset/liability" - so the property on the object is
    /// nullable.
    /// </para>
    /// </remarks>
    [JsonProperty("asset")]
    public bool? Asset { get; set; }

    /// <summary>
    /// Gets or sets the date on which the account closed.
    /// </summary>
    /// <value>
    /// The <see cref="DateTimeOffset"/> on which the account and related
    /// basic services effectively end for the account owner.
    /// </value>
    [JsonProperty("closeDateTime")]
    public DateTimeOffset? CloseDateTime { get; set; }

    /// <summary>
    /// Gets or sets the currency type held in this account.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the ISO 4217 currency code for the account.
    /// </value>
    [JsonProperty("currencyCode")]
    public string CurrencyCode { get; set; }

    /// <summary>
    /// Gets or sets a human-readable account description.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with a human-readable description of the
    /// account assigned by the account provider. This field is not
    /// localized.
    /// </value>
    [JsonProperty("description")]
    public string Description { get; set; }

    /// <summary>
    /// Gets or sets the account number. This value is generally tokenized.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> containing the unmasked account number. In
    /// storage and on the wire this is generally a tokenized value;
    /// decryption happens at the last possible moment.
    /// </value>
    [JsonProperty("number")]
    public string Number { get; set; }

    /// <summary>
    /// Gets or sets the date on which the account opened.
    /// </summary>
    /// <value>
    /// The <see cref="DateTimeOffset"/> on which the account and related
    /// basic services are effectively operational for the account owner.
    /// </value>
    [JsonProperty("openDateTime")]
    public DateTimeOffset? OpenDateTime { get; set; }

    /// <summary>
    /// Gets or sets the active status of the account.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the status of whether the account is <c>active</c> or <c>inactive</c>.
    /// </value>
    [JsonProperty("status")]
    public string Status { get; set; }
}

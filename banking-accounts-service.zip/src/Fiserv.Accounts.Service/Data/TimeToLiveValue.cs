namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Constants with the value used to set the TTL (time to live) in seconds for an item in a Cosmos container.
/// </summary>
public static class TimeToLiveValue
{
    /// <summary>
    /// If TTL is set to <c>-1</c> the item will never expire.
    /// </summary>
    public const int NeverExpire = -1;
}

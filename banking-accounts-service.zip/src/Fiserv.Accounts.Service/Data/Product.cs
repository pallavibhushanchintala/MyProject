﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Model describing a product code for an account.
/// </summary>
[ExcludeFromCodeCoverage]
public class Product : Document
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Product"/> class.
    /// </summary>
    public Product()
    {
        this.Type = DocumentType.Product;
        this.TimeToLive = TimeToLiveValue.NeverExpire;
    }

    /// <summary>
    /// Gets or sets the type of descriptor.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the type of descriptor.
    /// </value>
    /// <remarks>
    /// Examples: OFX, EFX, host, product, etc.
    /// </remarks>
    [JsonProperty("scheme")]
    public string Scheme { get; set; }

    /// <summary>
    /// Gets or sets the value for the descriptor/product.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the value for the descriptor/product.
    /// </value>
    /// <remarks>
    /// For classifications like OFX, this is the OFX type; for a host product, this is the host product code.
    /// </remarks>
    [JsonProperty("value")]
    public string Value { get; set; }
}

﻿namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Document types found in <see cref="Document.Type"/>.
/// </summary>
public static class DocumentType
{
    /// <summary>
    /// The document is a bank account.
    /// </summary>
    public const string Account = "account";

    /// <summary>
    /// The document is a bank account balance.
    /// </summary>
    public const string Balance = "balance";

    /// <summary>
    /// The document is a product related to an account.
    /// </summary>
    public const string Product = "product";

    /// <summary>
    /// The document is a bank account transaction.
    /// </summary>
    public const string Transaction = "transaction";
}

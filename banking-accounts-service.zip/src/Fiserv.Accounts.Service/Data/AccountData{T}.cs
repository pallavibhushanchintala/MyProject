namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Repository response for data related to an account.
/// </summary>
/// <typeparam name="T">
/// The type of data included in the response.
/// </typeparam>
/// <remarks>
/// <para>
/// When a user queries for data, we need to differentiate between three cases:
/// </para>
/// <list type="bullet">
/// <item><term>
/// The account doesn't exist (404).
/// </term></item>
/// <item><term>
/// The account exists but the user doesn't have access (403).
/// </term></item>
/// <item><term>
/// The account exists and there are zero or more results to report (200).
/// </term></item>
/// </list>
/// <para>
/// What this means is a query for a list of balances or transactions also needs
/// to get the account - because if the list of data is empty, you can't tell if
/// it's empty because there aren't any items or if the account itself doesn't
/// exist. Further, if you try to use <see langword="null"/> to indicate "the
/// account doesn't exist," you still get into a jam where the list of data may
/// be empty. This stops you from determining if the user has access to the
/// account to return the proper response code (403 Forbidden vs 200 OK with an
/// empty list of data).
/// </para>
/// <para>
/// This data object bridges that gap by returning the account and the related
/// data all in one package. If the <see cref="AccountData{T}.Account"/> is
/// <see langword="null"/> the account doesn't exist. If the
/// <see cref="AccountData{T}.Account"/> is not <see langword="null"/>, you can
/// use that data to determine whether your API response should be "there are no
/// results" (200) or "there are zero results, but you're still not allowed to
/// know that because you don't have access to the account" (403).
/// </para>
/// </remarks>
public class AccountData<T>
  where T : Document
{
    /// <summary>
    /// Gets or sets the account related to the result set.
    /// </summary>
    /// <value>
    /// The <see cref="Data.Account"/> if it exists; or <see langword="null"/>
    /// if the account does not exist.
    /// </value>
    public Account Account { get; set; }

    /// <summary>
    /// Gets or sets the result set data.
    /// </summary>
    /// <value>
    /// An <see cref="IEnumerable{T}"/> of <see cref="Document"/> based on the
    /// query. This will be <see langword="null"/> if the <see cref="Account"/>
    /// is <see langword="null"/>. If this is empty, you can determine whether
    /// you should return 200 with an empty result set or 403 based on the
    /// <see cref="Document.Users"/> in the <see cref="Account"/>.
    /// </value>
    public IEnumerable<T> Data { get; set; }
}

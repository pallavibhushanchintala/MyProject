﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Base properties for an account-related document stored in a document database.
/// </summary>
public class Document
{
    /// <summary>
    /// Gets or sets the ID of the account related to this document.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with an account ID to which this document
    /// relates. If this is an account document, the <see cref="Id"/> will
    /// be the same as this value.
    /// </value>
    [JsonProperty("accountId")]
    public string AccountId { get; set; }

    /// <summary>
    /// Gets or sets the entity tag.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that identifies the version of the document. Used for optimistic concurrency.
    /// </value>
    [JsonProperty("_etag")]
    public string ETag { get; set; }

    /// <summary>
    /// Gets or sets the database document ID.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that uniquely identifies the document inside the data backing store.
    /// </value>
    [JsonProperty("id")]
    public string Id { get; set; }

    /// <summary>
    /// Gets or sets the document type.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating the type of content held in this document. Primarily useful in serialization.
    /// </value>
    [JsonProperty("type")]
    public string Type { get; set; }

    /// <summary>
    /// Gets or sets the list of users with access to this entity.
    /// </summary>
    /// <value>
    /// A <see cref="List{T}"/> of user IDs, each of which has access to view this entity.
    /// </value>
    [JsonProperty("users")]
    public IEnumerable<string> Users { get; set; }

    /// <summary>
    /// Gets or sets the Cosmos DB Time to Live of the document.
    /// </summary>
    /// <value>
    /// A <see cref="int"/> with the time in seconds before the document expires in the Cosmos DB.
    /// By default the ttl property is omitted in the Cosmos DB documents.
    /// The ttl value cannot be set to 'null', ensure to provide a nonzero positive integer less than or
    /// equal to <c>'2147483647'</c>, or <c>'-1'</c> which means never expire.
    /// </value>
    [JsonProperty("ttl", NullValueHandling = NullValueHandling.Ignore)]
    public int? TimeToLive
    {
        get; set;
    }
}

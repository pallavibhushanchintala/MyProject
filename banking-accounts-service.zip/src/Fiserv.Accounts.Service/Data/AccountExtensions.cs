using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Extension methods for working with <see cref="Account"/> data.
/// </summary>
public static class AccountExtensions
{
    private static readonly SHA256 HashAlgorithm = SHA256.Create();

    /// <summary>
    /// Clones an account with only the primary identifiers so a search can be done agnostic of any other changes.
    /// </summary>
    /// <param name="account">
    /// The <see cref="Account"/> with the minimum set of primary identifiers.
    /// </param>
    /// <returns>
    /// A cloned <see cref="Account"/> with only the primary identifiers remaining.
    /// </returns>
    public static Account CloneForIdentitySearch(this Account account)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        return new Account
        {
            AlternateIdentifiers = account.AlternateIdentifiers?.Where(x => x.Scheme.Equals(AlternateIdentifierScheme.RoutingTransitNumber, StringComparison.OrdinalIgnoreCase)),
            AccountType = account.AccountType,
            Number = account.Number,
        };
    }

    /// <summary>
    /// Generates a predictable account number based on hashing primary account identifiers.
    /// </summary>
    /// <param name="account">
    /// The account for which the ID should be generated.
    /// </param>
    /// <returns>
    /// The value of the generated predictable ID. Does not update the input object.
    /// </returns>
    [SuppressMessage("CA1308", "CA1308", Justification = "Hashed account ID content has been agreed on as lowercase.")]
    public static string GenerateAccountId(this Account account)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        // As we increase the number of items on which we match, it may be that we need
        // to check for RTN or IBAN or BBAN and not just RTN.
        var rtn = account.GetRoutingTransitNumber();
        var magicId = $"{account.Number}{account.AccountType?.ToLowerInvariant()}{rtn}";
        var data = HashAlgorithm.ComputeHash(Encoding.UTF8.GetBytes(magicId));

        var sBuilder = new StringBuilder();
        for (var i = 0; i < data.Length; i++)
        {
            sBuilder.Append(data[i].ToString("x2", CultureInfo.InvariantCulture));
        }

        return sBuilder.ToString();
    }

    /// <summary>
    /// Gets the routing transit number (RTN) from an account, if present.
    /// </summary>
    /// <param name="account">
    /// The account for which the RTN should be retrieved.
    /// </param>
    /// <returns>
    /// The value of the RTN <see cref="AlternateIdentifier"/> if it exists; or
    /// <see langword="null"/> if not.
    /// </returns>
    public static string GetRoutingTransitNumber(this Account account)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        return account.AlternateIdentifiers?.FirstOrDefault(a => a.Scheme.Equals(AlternateIdentifierScheme.RoutingTransitNumber, StringComparison.OrdinalIgnoreCase))?.Id;
    }

    /// <summary>
    /// Validates that an account is not null and contains the minimum
    /// identifying characteristics for a unique account.
    /// </summary>
    /// <param name="account">
    /// The <see cref="Account"/> to validate.
    /// </param>
    public static void Validate(this Account account)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        if (string.IsNullOrEmpty(account.Number))
        {
            throw new ArgumentException("Account must have a number.", nameof(account));
        }

        if (string.IsNullOrEmpty(account.AccountType))
        {
            throw new ArgumentException("Account must have a type.", nameof(account));
        }

        // As we increase the number of items on which we match, it may be that we need
        // to check for RTN or IBAN or BBAN and not just RTN.
        if (string.IsNullOrEmpty(account.GetRoutingTransitNumber()))
        {
            throw new ArgumentException("Account must have a routing transit number alternate identifier.", nameof(account));
        }
    }
}

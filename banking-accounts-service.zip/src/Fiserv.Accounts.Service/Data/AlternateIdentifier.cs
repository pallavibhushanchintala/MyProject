﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// Alternate means of identifying an account like IBAN, BBAN, or routing
/// number (RTN).
/// </summary>
public class AlternateIdentifier
{
    /// <summary>
    /// Gets or sets the value of the alternate ID.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the value of the alternate identifier.
    /// This may be the routing number or alternate bank account number.
    /// </value>
    [JsonProperty("id")]
    public string Id { get; set; }

    /// <summary>
    /// Gets or sets the alternate ID type.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the type of identifier described by this
    /// entity. The list of well-known schemes should be published
    /// externally.
    /// </value>
    [JsonProperty("scheme")]
    public string Scheme { get; set; }
}

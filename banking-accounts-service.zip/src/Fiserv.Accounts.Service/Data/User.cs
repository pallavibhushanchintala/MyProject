﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Data;

/// <summary>
/// A data model with a subset of fields of the user document.
/// </summary>
public class User
{
    /// <summary>
    /// Gets or sets the accounts associated with the user resource.
    /// </summary>
    /// <value>
    /// An <see cref="IEnumerable{T}"/> containing the list of users with access
    /// to the account resource.
    /// </value>
    [JsonProperty("accounts")]
    public IEnumerable<string> Accounts { get; set; }

    /// <summary>
    /// Gets or sets a unique and immutable identifier used to identify the user resource.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the unique and immutable identifier used to identify the user resource.
    /// </value>
    [JsonProperty("id")]
    public string Id { get; set; }
}

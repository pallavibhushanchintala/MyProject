using Fiserv.Accounts.Service.Data;

namespace Fiserv.Accounts.Service.Controllers;

/// <summary>
/// Extensions for <see cref="Document"/> used in context of API controllers.
/// </summary>
public static class DocumentExtensions
{
    /// <summary>
    /// Checks a user ID against the set of users specified in the
    /// <see cref="Document"/> and determines if that user has access to that data.
    /// </summary>
    /// <param name="document">
    /// The document for which access should be checked. If the document is
    /// <see langword="null"/> access is summarily denied.
    /// </param>
    /// <param name="userId">
    /// The user attempting access to the document. If this value is
    /// <see langword="null"/> it's considered an application acting as an
    /// application, which generally grants access.
    /// </param>
    /// <returns>
    /// <see langword="true"/> if the specified user has access to the document;
    /// <see langword="false"/> if not.
    /// </returns>
    public static bool UserHasAccess(this Document document, string userId)
    {
        if (document == null)
        {
            // If there's no document at all, just deny access.
            return false;
        }

        if (userId == null)
        {
            // Applications can access all documents.
            return true;
        }

        if (document.Users == null)
        {
            // No users have access
            return false;
        }

        // IDs are case-sensitive.
        return document.Users.Contains(userId, StringComparer.Ordinal);
    }
}

﻿using System.ComponentModel.DataAnnotations;
using AutoMapper;
using Fiserv.Accounts.Service.Models;
using Fiserv.Accounts.Service.Repositories;
using Fiserv.AspNetCore.Authentication;
using Fiserv.Core.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace Fiserv.Accounts.Service.Controllers;

/// <summary>
/// API controller that provides account information.
/// </summary>
[ApiController]
[ApiVersion("1")]
[Authorize]
[Produces("application/json")]
public class AccountsController : ControllerBase
{
    /// <summary>
    /// Initializes a new instance of the <see cref="AccountsController"/> class.
    /// </summary>
    /// <param name="logger">
    /// The <see cref="ILogger{T}"/> that can be used for diagnostic logging.
    /// </param>
    /// <param name="dataService">
    /// The <see cref="IDataRepository"/> used for interacting with the data store.
    /// </param>
    /// <param name="mapper">
    /// The <see cref="IMapper"/> used for mapping objects.
    /// </param>
    public AccountsController(ILogger<AccountsController> logger, IDataRepository dataService, IMapper mapper)
    {
        this.Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        this.DataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
        this.Mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
    }

    /// <summary>
    /// Gets the data service.
    /// </summary>
    /// <value>
    /// An <see cref="IDataRepository"/> used for interacting with the data store.
    /// </value>
    public IDataRepository DataService
    {
        get;
    }

    /// <summary>
    /// Gets the logger.
    /// </summary>
    /// <value>
    /// An <see cref="ILogger"/> used for logging diagnostic messages.
    /// </value>
    public ILogger<AccountsController> Logger
    {
        get;
    }

    /// <summary>
    /// Gets the mapper.
    /// </summary>
    /// <value>
    /// An <see cref="IMapper"/> used for mapping objects.
    /// </value>
    public IMapper Mapper
    {
        get;
    }

    /// <summary>
    /// Gets a specific account by identifier.
    /// </summary>
    /// <param name="id">
    /// A <see cref="string"/> representing the identifier of the account to retrieve.
    /// </param>
    /// <param name="userId">
    /// A <see cref="string"/> representing the unique identifier of a user.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the user's accounts.
    /// </returns>
    /// <remarks>
    /// If <paramref name="userId"/> is <see langword="null" /> or an empty string, the operation will
    /// attempt to retrieve the account for the authenticated user.
    /// </remarks>
    [EvaluateActingUserId("userId")]
    [HttpGet("consumer/banking/v{version:apiVersion}/[controller]/{id}")]
    [HttpGet("banking/v{version:apiVersion}/[controller]/{id}")]
    [SwaggerResponse(200, "Successfully retrieved the account.", typeof(AccountResponse))]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(404, "The requested account was not found.")]
    public async Task<IActionResult> GetAccountByIdAsync([StringLength(128)] string id, [StringLength(40, MinimumLength = 1)] string userId)
    {
        var rawAccount = await this.DataService.GetAccountByIdAsync(id, this.User.GetTenantId());
        if (rawAccount == null)
        {
            return this.NotFound();
        }

        if (userId != null && !rawAccount.Users.Contains(userId))
        {
            return this.Forbid();
        }

        var account = this.Mapper.Map<AccountResponse>(rawAccount);
        return this.Ok(account);
    }

    /// <summary>
    /// Gets the list of accounts for a user.
    /// </summary>
    /// <param name="userId">
    /// A <see cref="string"/> representing the unique identifier of a user.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the user's accounts.
    /// </returns>
    /// <remarks>
    /// If <paramref name="userId"/> is <see langword="null" /> or an empty string, the operation will
    /// attempt to retrieve accounts for the authenticated user.
    /// </remarks>
    [EvaluateActingUserId("userId", Required = true)]
    [HttpGet("consumer/banking/v{version:apiVersion}/[controller]")]
    [HttpGet("banking/v{version:apiVersion}/[controller]")]
    [SwaggerResponse(200, "Successfully retrieved the list of accounts.", typeof(IEnumerable<AccountResponse>))]
    [SwaggerResponse(400, "When calling the operation as an application (i.e., not as an authenticated user), you must specify the user parameter. If you don't, the operation has no context and won't function. Check your parameters and retry.")]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    public async Task<IActionResult> GetAccountsAsync([StringLength(40, MinimumLength = 1)] string userId)
    {
        // You can't get all accounts as an application - that'd be listing every account for the tenant.
        var rawAccounts = await this.DataService.GetAccountsAsync(userId, this.User.GetTenantId());
        var accounts = this.Mapper.Map<IEnumerable<AccountResponse>>(rawAccounts);
        return this.Ok(accounts);
    }

    /// <summary>
    /// Gets the balances associated with a specific account.
    /// </summary>
    /// <param name="id">
    /// A <see cref="string"/> representing the identifier of the account to retrieve.
    /// </param>
    /// <param name="userId">
    /// A <see cref="string"/> representing the unique identifier of a user.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the balances for the requested account.
    /// </returns>
    /// <remarks>
    /// If <paramref name="userId"/> is <see langword="null" /> or an empty string, the operation will
    /// attempt to retrieve the balances for the authenticated user.
    /// </remarks>
    [EvaluateActingUserId("userId")]
    [HttpGet("consumer/banking/v{version:apiVersion}/[controller]/{id}/balances")]
    [HttpGet("banking/v{version:apiVersion}/[controller]/{id}/balances")]
    [SwaggerResponse(200, "Successfully retrieved the balances for the account.", typeof(IEnumerable<Balance>))]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(404, "The requested account was not found.")]
    public async Task<IActionResult> GetBalancesByAccountIdAsync([StringLength(128)] string id, [StringLength(40, MinimumLength = 1)] string userId)
    {
        var data = await this.DataService.GetBalancesByAccountIdAsync(id, this.User.GetTenantId());
        if (data.Account == null)
        {
            return this.NotFound();
        }

        if (!data.Account.UserHasAccess(userId))
        {
            return this.Forbid();
        }

        // User may have been denied access to a particular balance.
        var balances = data.Data.Where(b => b.UserHasAccess(userId));
        return this.Ok(this.Mapper.Map<IEnumerable<Balance>>(balances));
    }

    /// <summary>
    /// Gets the products associated with a specific account.
    /// </summary>
    /// <param name="id">
    /// A <see cref="string"/> representing the identifier of the account to retrieve.
    /// </param>
    /// <param name="userId">
    /// A <see cref="string"/> representing the unique identifier of a user.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the products for the requested account.
    /// </returns>
    /// <remarks>
    /// If <paramref name="userId"/> is <see langword="null" /> or an empty string, the operation will
    /// attempt to retrieve the products for the authenticated user.
    /// </remarks>
    [EvaluateActingUserId("userId")]
    [HttpGet("consumer/banking/v{version:apiVersion}/[controller]/{id}/products")]
    [HttpGet("banking/v{version:apiVersion}/[controller]/{id}/products")]
    [SwaggerResponse(200, "Successfully retrieved the products for the account.", typeof(IEnumerable<ProductResponse>))]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(404, "The requested account was not found.")]
    public async Task<IActionResult> GetProductsByAccountIdAsync([StringLength(128)] string id, [StringLength(40, MinimumLength = 1)] string userId)
    {
        var data = await this.DataService.GetProductsByAccountIdAsync(id, this.User.GetTenantId());
        if (data.Account == null)
        {
            return this.NotFound();
        }

        if (!data.Account.UserHasAccess(userId))
        {
            return this.Forbid();
        }

        // User may have been denied access to a particular product.
        var products = data.Data.Where(b => b.UserHasAccess(userId));
        return this.Ok(this.Mapper.Map<IEnumerable<ProductResponse>>(products));
    }

    /// <summary>
    /// Gets the transactions associated with a specific account.
    /// </summary>
    /// <param name="id">
    /// A <see cref="string"/> representing the identifier of the account to retrieve.
    /// </param>
    /// <param name="userId">
    /// A <see cref="string"/> representing the unique identifier of a user.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the transactions for the requested account.
    /// </returns>
    /// <remarks>
    /// If <paramref name="userId"/> is <see langword="null" /> or an empty string, the operation will
    /// attempt to retrieve transactions for the authenticated user.
    /// </remarks>
    [EvaluateActingUserId("userId")]
    [HttpGet("consumer/banking/v{version:apiVersion}/[controller]/{id}/transactions")]
    [HttpGet("banking/v{version:apiVersion}/[controller]/{id}/transactions")]
    [SwaggerResponse(200, "Successfully retrieved the transactions for the account.", typeof(IEnumerable<Transaction>))]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(404, "The requested account was not found.")]
    public async Task<IActionResult> GetTransactionsByAccountIdAsync([StringLength(128)] string id, [StringLength(40, MinimumLength = 1)] string userId)
    {
        var data = await this.DataService.GetTransactionsByAccountIdAsync(id, this.User.GetTenantId());
        if (data.Account == null)
        {
            return this.NotFound();
        }

        if (!data.Account.UserHasAccess(userId))
        {
            return this.Forbid();
        }

        // User may have been denied access to a particular transaction.
        var transactions = data.Data.Where(b => b.UserHasAccess(userId));
        return this.Ok(this.Mapper.Map<IEnumerable<Transaction>>(transactions));
    }

    /// <summary>
    /// Searches for accounts based on alternate identifiers and attributes.
    /// </summary>
    /// <param name="accountSearch">
    /// An <see cref="AccountBase"/> representing the account to be located.
    /// </param>
    /// <param name="userId">
    /// A <see cref="string"/> representing the unique identifier of a user.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the products for the requested account.
    /// </returns>
    /// <remarks>
    /// If <paramref name="userId"/> is <see langword="null" /> or an empty string, the operation will
    /// attempt the search using the authenticated user.
    /// </remarks>
    [EvaluateActingUserId("userId")]
    [HttpPost("supplier/banking/v{version:apiVersion}/[controller]/search")]
    [HttpPost("banking/v{version:apiVersion}/[controller]/search")]
    [SwaggerResponse(200, "Successfully completed the search operation.", typeof(IEnumerable<AccountResponse>))]
    [SwaggerResponse(400, "The request could not be understood by the server due to malformed syntax. Check your parameters and retry.")]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    public async Task<IActionResult> SearchForAccountAsync([Required][FromBody] AccountBase accountSearch, [StringLength(40, MinimumLength = 1)] string userId)
    {
        // We don't have a use case right now for users not being allowed to
        // search for accounts, so you won't see any 403. However, it seems
        // reasonable that as authorization constructs grow there may be a case
        // where a limited token/app can only get accounts and not search.
        var rawAccounts = await this.DataService.FindAccountAsync(this.Mapper.Map<Data.Account>(accountSearch), userId, this.User.GetTenantId());
        var accounts = this.Mapper.Map<IEnumerable<AccountResponse>>(rawAccounts);
        return this.Ok(accounts);
    }

    /// <summary>
    /// Updates the products associated with a specific account.
    /// </summary>
    /// <param name="id">
    /// The identifier of the account for which products should be updated.
    /// </param>
    /// <param name="products">
    /// The list of products to set for the account.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the products for the account.
    /// </returns>
    [RequireApplicationToken]
    [HttpPut("supplier/banking/v{version:apiVersion}/[controller]/{id}/products")]
    [HttpPut("banking/v{version:apiVersion}/[controller]/{id}/products")]
    [SwaggerResponse(200, "Successfully updated the products for the account.", typeof(IEnumerable<ProductResponse>))]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(404, "The requested account was not found.")]
    public async Task<IActionResult> UpdateProductsByAccountIdAsync([StringLength(128)] string id, [Required][FromBody] IEnumerable<ProductBase> products)
    {
        // Right now we don't have administrative users that can upsert data so we require an application token.
        var rawResult = await this.DataService.UpdateProductsForAccountIdAsync(id, this.Mapper.Map<IEnumerable<Data.Product>>(products), this.User.GetTenantId());
        if (rawResult == null)
        {
            return this.NotFound();
        }

        var result = this.Mapper.Map<IEnumerable<ProductResponse>>(rawResult);
        return this.Ok(result);
    }

    /// <summary>
    /// Upserts an account in the system. Establishes a link between account data in an external client
    /// and account data in the service.
    /// </summary>
    /// <param name="account">
    /// An <see cref="AccountPutRequest"/> representing the account with all available data from the client to which
    /// a relationship should be established.
    /// </param>
    /// <returns>
    /// An <see cref="AccountResponse"/> with the details of the account upserted.
    /// </returns>
    [RequireApplicationToken]
    [HttpPut("supplier/banking/v{version:apiVersion}/[controller]")]
    [HttpPut("banking/v{version:apiVersion}/[controller]")]
    [SwaggerResponse(200, "Successfully created/updated the account.", typeof(AccountResponse))]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(422, "The account provided in the request didn't have enough information to uniquely identify it.")]
    [SuppressMessage("Design", "CA1062:Validate arguments of public methods", Justification = "The 'account' parameter is validated not to be null by the 'Required' attribute of DataAnnotations.")]
    public async Task<IActionResult> UpsertAccountAsync([Required][FromBody] AccountPutRequest account)
    {
        // Right now we don't have administrative users that can upsert data so we require an application token.
        if (account.AlternateIdentifiers == null || !account.AlternateIdentifiers.Any())
        {
            return this.AccountMissingIdentifierData();
        }

        Data.Account rawResult;
        try
        {
            rawResult = await this.DataService.UpsertAccountAsync(this.Mapper.Map<Data.Account>(account), this.User.GetTenantId());
        }
        catch (ArgumentException)
        {
            // This will happen due to account validation in the repo.
            return this.AccountMissingIdentifierData();
        }

        if (rawResult == null)
        {
            // This will happen if the repo found it to be an ambiguous match.
            // We can test this by setting up some complex mocks, but it's
            // probably not worth the effort just to get the coverage.
            return this.AccountMissingIdentifierData();
        }

        var result = this.Mapper.Map<AccountResponse>(rawResult);
        return this.Ok(result);
    }

    /// <summary>
    /// Upserts an account in the system. Establishes a link between account data in an external client
    /// and account data in the service.
    /// </summary>
    /// <param name="id">
    /// A <see cref="string"/> representing the identifier of the account to be updated.
    /// </param>
    /// <param name="account">
    /// An <see cref="AccountPutRequest"/> representing the account with all available data from the client to which
    /// a relationship should be established.
    /// </param>
    /// <returns>
    /// An <see cref="AccountResponse"/> with the details of the account upserted.
    /// </returns>
    [RequireApplicationToken]
    [HttpPut("supplier/banking/v{version:apiVersion}/[controller]/{id}")]
    [HttpPut("banking/v{version:apiVersion}/[controller]/{id}")]
    [SwaggerResponse(200, "Successfully updated the account.", typeof(AccountResponse))]
    [SwaggerResponse(400, "The request could not be understood by the server due to malformed syntax. Check your parameters and retry..")]
    [SwaggerResponse(401, "The client has not authenticated to perform the operation.")]
    [SwaggerResponse(403, "The authenticated client is not authorized to perform the operation.")]
    [SwaggerResponse(422, "The account provided in the request didn't have enough information to uniquely identify it.")]
    [SuppressMessage("Design", "CA1062:Validate arguments of public methods", Justification = "The 'account' parameter is validated not to be null by the 'Required' attribute of DataAnnotations.")]
    public async Task<IActionResult> UpsertAccountByIdAsync([StringLength(128)] string id, [Required][FromBody] AccountPutRequest account)
    {
        // Right now we don't have administrative users that can upsert data so we require an application token.
        if (account.AlternateIdentifiers == null || !account.AlternateIdentifiers.Any())
        {
            return this.AccountMissingIdentifierData();
        }

        Data.Account rawResult;
        try
        {
            rawResult = await this.DataService.UpsertAccountByIdAsync(id, this.Mapper.Map<Data.Account>(account), this.User.GetTenantId());
        }
        catch (ArgumentException)
        {
            // This will happen due to account validation in the repo.
            return this.AccountMissingIdentifierData();
        }

        if (rawResult == null)
        {
            return this.Problem(statusCode: 404, detail: "The specified account ID does not exist.");
        }

        var result = this.Mapper.Map<AccountResponse>(rawResult);
        return this.Ok(result);
    }

    private IActionResult AccountMissingIdentifierData()
    {
        return this.Problem(statusCode: 422, detail: "The account provided in the request didn't have enough information to uniquely identify it. For example, accounts generally need account type, account number, and a third piece like RTN. Requests must include enough information to uniquely identify the account before a mapping can be established.");
    }
}

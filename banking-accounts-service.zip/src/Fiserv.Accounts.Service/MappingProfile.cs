﻿using AutoMapper;

namespace Fiserv.Accounts.Service;

/// <summary>
/// Profile for creating <c>AutoMapper</c> mappings.
/// </summary>
[ExcludeFromCodeCoverage]
public class MappingProfile : Profile
{
    /// <summary>
    /// Initializes a new instance of the <see cref="MappingProfile"/> class.
    /// </summary>
    public MappingProfile()
    {
        this.CreateMap<Data.Account, Models.AccountResponse>()
            .ForMember(dest => dest.Currency, opt => opt.MapFrom(src => src.CurrencyCode));
        this.CreateMap<Data.AlternateIdentifier, Models.AlternateIdentifier>();
        this.CreateMap<Data.Amount, Models.Amount>()
            .ForMember(dest => dest.Currency, opt => opt.MapFrom(src => src.CurrencyCode));
        this.CreateMap<Data.Balance, Models.Balance>()
            .ForMember(dest => dest.Amount, opt => opt.MapFrom(src => new Models.Amount { Currency = src.CurrencyCode, Value = src.Data.OrderByDescending(x => x.DateTime).First().Amount }))
            .ForMember(dest => dest.Type, opt => opt.MapFrom(src => src.BalanceType))
            .ForMember(dest => dest.DateTime, opt => opt.MapFrom(src => src.Data.OrderByDescending(x => x.DateTime).First().DateTime));
        this.CreateMap<Data.Product, Models.ProductResponse>();
        this.CreateMap<Data.RunningBalance, Models.RunningBalance>();
        this.CreateMap<Data.Transaction, Models.Transaction>()
            .ForMember(dest => dest.EffectiveDateTime, opt => opt.MapFrom(src => src.EffectiveDateTime ?? src.PostedDateTime));
        this.CreateMap<Data.TransactionCode, Models.TransactionCode>();

        this.CreateMap<Models.AccountBase, Data.Account>()
            .ForMember(dest => dest.Users, opt => opt.MapFrom(src => new List<string>()))
            .ForMember(dest => dest.CurrencyCode, opt => opt.MapFrom(src => src.Currency));
        this.CreateMap<Models.AlternateIdentifier, Data.AlternateIdentifier>();
        this.CreateMap<Models.Amount, Data.Amount>()
            .ForMember(dest => dest.CurrencyCode, opt => opt.MapFrom(src => src.Currency));
        this.CreateMap<Models.Balance, Data.Balance>();
        this.CreateMap<Models.ProductBase, Data.Product>()
            .ForMember(dest => dest.Users, opt => opt.MapFrom(src => new List<string>()));

        // Cloning for data storage/tokenization.
        this.CreateMap<Data.Account, Data.Account>();
        this.CreateMap<Data.AlternateIdentifier, Data.AlternateIdentifier>();
        this.CreateMap<Data.Amount, Data.Amount>();
        this.CreateMap<Data.Balance, Data.Balance>();
        this.CreateMap<Data.BalanceData, Data.BalanceData>();
        this.CreateMap<Data.Product, Data.Product>();
        this.CreateMap<Data.RunningBalance, Data.RunningBalance>();
        this.CreateMap<Data.Transaction, Data.Transaction>();
        this.CreateMap<Data.TransactionCode, Data.TransactionCode>();
        this.CreateMap<Data.User, Data.User>();
    }
}

using Fiserv.Security.Tokenization;
using Microsoft.Extensions.FileProviders;

namespace Fiserv.Accounts.Service;

/// <summary>
/// Extension methods for registering services with dependency injection.
/// </summary>
public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers the appropriate tokenization/encryption service based on
    /// the current hosting environment and configuration.
    /// </summary>
    /// <param name="services">
    /// The <see cref="IServiceCollection"/> into which services should be
    /// registered.
    /// </param>
    /// <param name="configuration">
    /// The <see cref="IConfiguration"/> containing Voltage configuration.
    /// </param>
    /// <param name="environment">
    /// The <see cref="IWebHostEnvironment"/> with information about the
    /// current hosting environment.
    /// </param>
    /// <param name="fileProvider">
    /// The <see cref="IFileProvider"/> that can be used to access files and
    /// folders in the application 'bin' folder. Used for the Voltage trust
    /// store.
    /// </param>
    /// <returns>
    /// The <paramref name="services"/> for continued configuration.
    /// </returns>
    /// <remarks>
    /// <para>
    /// In a development environment you can use either the development
    /// tokenizer
    /// <see cref="Fiserv.Security.Tokenization.Development.Tokenizer"/>
    /// or you can use the Voltage tokenizer
    /// <see cref="Fiserv.Security.Tokenization.Voltage.Tokenizer"/>.
    /// By default you'll get the development tokenizer unless Voltage
    /// configuration is explicitly provided. If you want to use Voltage in
    /// development you'll have to set the <c>voltage:enabled</c>
    /// configuration value to <c>true</c>. This allows you to keep Voltage
    /// settings in user secrets without having to add/remove them to
    /// switch.
    /// </para>
    /// <para>
    /// In a non-development environment (anything where the
    /// <see cref="Microsoft.Extensions.Hosting.IHostingEnvironment.EnvironmentName"/> is not
    /// <c>Development</c>), you must use the Voltage tokenizer and an
    /// exception will be thrown if any configuration is missing.
    /// </para>
    /// </remarks>
    public static IServiceCollection AddTokenizer(this IServiceCollection services, IConfiguration configuration, IWebHostEnvironment environment, IFileProvider fileProvider)
    {
        if (services == null)
        {
            throw new ArgumentNullException(nameof(services));
        }

        if (configuration == null)
        {
            throw new ArgumentNullException(nameof(configuration));
        }

        if (environment == null)
        {
            throw new ArgumentNullException(nameof(environment));
        }

        if (fileProvider == null)
        {
            throw new ArgumentNullException(nameof(fileProvider));
        }

        if (environment.IsDevelopment())
        {
            if (configuration.GetSection("voltage").Exists() && configuration.GetSection("voltage:enabled").Get<bool>())
            {
                RegisterVoltage(services, configuration, environment, fileProvider);
            }
            else
            {
                services.AddSingleton<ITokenizer, Fiserv.Security.Tokenization.Development.Tokenizer>();
            }
        }
        else
        {
            RegisterVoltage(services, configuration, environment, fileProvider);
        }

        return services;
    }

    private static void RegisterVoltage(this IServiceCollection services, IConfiguration configuration, IWebHostEnvironment environment, IFileProvider fileProvider)
    {
        // Using a separate provider here instead of
        // environment.ContentRootFileProvider because we don't want these
        // certificates to be considered web content.
        //
        // There's a bug where GetFileInfo doesn't support directories
        // https://github.com/dotnet/runtime/issues/36575
        // but GetDirectoryContents also doesn't know its path
        // https://github.com/dotnet/runtime/issues/36496
        // so you have to do both.
        var trustStoreContents = fileProvider.GetDirectoryContents("trustStore");
        var trustStore = fileProvider.GetFileInfo("trustStore");
        if (!trustStoreContents.Exists)
        {
            throw new DirectoryNotFoundException($"The Voltage trust store (certificate) location '{trustStore.PhysicalPath}' was not found.");
        }

        var voltageUser = configuration.GetRequiredValue<string>("voltage:username", "Voltage username");
        var voltagePassword = configuration.GetRequiredValue<string>("voltage:password", "Voltage password");
        var voltageEnvironment = configuration["voltage:environment"] ?? environment.EnvironmentName;
        services
            .AddVoltage()
            .ForHostEnvironment(environment)
            .ForEnvironment(voltageEnvironment)
            .TrustStoreAt(trustStore.PhysicalPath)
            .WithApplicationCredentials(voltageUser, voltagePassword);
    }
}

﻿using Autofac.Extensions.DependencyInjection;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Serilog;

namespace Fiserv.Accounts.Service;

/// <summary>
/// Main entry point for the microservice.
/// </summary>
[ExcludeFromCodeCoverage]
public static class Program
{
    /// <summary>
    /// Creates the basic host builder that will become the microservice host.
    /// </summary>
    /// <param name="args">
    /// The command line arguments to provide to the host.
    /// </param>
    /// <returns>
    /// An <see cref="IHostBuilder"/> for continued configuration and execution.
    /// </returns>
    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .UseServiceProviderFactory(new AutofacServiceProviderFactory())
            .UseSerilog()
            .ConfigureAppConfiguration((hostContext, config) =>
            {
                var configuration = config.Build();
                var keyVault = configuration["keyVault:endpointUrl"];
                if (!string.IsNullOrEmpty(keyVault))
                {
                    var keyVaultUri = new Uri(keyVault);
                    var secretClient = new SecretClient(keyVaultUri, new DefaultAzureCredential(), new SecretClientOptions());
                    config.AddAzureKeyVault(secretClient, new KeyVaultSecretManager());
                }

                config.AddUserSecrets(typeof(Program).Assembly, true);
            })
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            });

    /// <summary>
    /// Main entry point for execution of the microservice host.
    /// </summary>
    /// <param name="args">
    /// The command line arguments to provide to the host.
    /// </param>
    /// <returns>
    /// A <see cref="Task"/> to await completion of the program.
    /// </returns>
    public static async Task Main(string[] args)
    {
        await CreateHostBuilder(args).Build().RunAsync();
    }
}

﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model describing details of a balance.
/// </summary>
public class Balance
{
    /// <summary>
    /// Gets or sets a unique and immutable identifier used to identify the account resource.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the unique and immutable identifier used to identify the account resource.
    /// </value>
    public string AccountId { get; set; }

    /// <summary>
    /// Gets or sets the amount of money in this balance type.
    /// </summary>
    /// <value>
    /// A <see cref="Amount"/> containing the amount of money in this balance type.
    /// </value>
    public Amount Amount { get; set; }

    /// <summary>
    /// Gets or sets the date and time when the balance was current.
    /// </summary>
    /// <value>
    /// A <see cref="DateTimeOffset"/> indicating when the balance was current.
    /// </value>
    public DateTimeOffset DateTime { get; set; }

    /// <summary>
    /// Gets or sets the type of balance contained in this descriptor.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the type of balance contained in this descriptor.
    /// </value>
    public string Type { get; set; }
}

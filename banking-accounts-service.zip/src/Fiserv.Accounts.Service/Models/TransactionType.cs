﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// An enumeration of possible transaction types.
/// </summary>
public enum TransactionType
{
    /// <summary>
    /// The transaction was a credit (funds were added).
    /// </summary>
    Credit,

    /// <summary>
    /// The transaction was a debit (funds were removed).
    /// </summary>
    Debit,
}

﻿using System.ComponentModel.DataAnnotations;

namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model describing a product code for an account.
/// </summary>
public class ProductBase
{
    /// <summary>
    /// Gets or sets the type of descriptor.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the type of descriptor.
    /// </value>
    /// <remarks>
    /// Examples: OFX, EFX, host, product, etc.
    /// </remarks>
    [Required]
    [MaxLength(50)]
    public string Scheme { get; set; }

    /// <summary>
    /// Gets or sets the value for the descriptor/product.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the value for the descriptor/product.
    /// </value>
    /// <remarks>
    /// For classifications like OFX, this is the OFX type; for a host product, this is the host product code.
    /// </remarks>
    [Required]
    [MaxLength(256)]
    public string Value { get; set; }
}

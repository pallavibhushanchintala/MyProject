﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model describing details of a balance.
/// </summary>
public class RunningBalance
{
    /// <summary>
    /// Gets or sets the amount of money in this balance type.
    /// </summary>
    /// <value>
    /// A <see cref="Amount"/> containing the amount of money in this balance type.
    /// </value>
    public Amount Amount { get; set; }

    /// <summary>
    /// Gets or sets whether the running balance is a credit or a debit.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating whether the running balance is a credit
    /// or a debit.
    /// </value>
    public TransactionType CreditDebitIndicator { get; set; }
}

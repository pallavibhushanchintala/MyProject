﻿using System.Runtime.Serialization;

namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// An enumeration of possible account types.
/// </summary>
public enum AccountType
{
    /// <summary>
    /// The certificate of deposit account type.
    /// </summary>
    [EnumMember(Value = "CD")]
    CD,

    /// <summary>
    /// The checking account type.
    /// </summary>
    [EnumMember(Value = "CHECKING")]
    CHECKING,

    /// <summary>
    /// The line of credit account type.
    /// </summary>
    [EnumMember(Value = "CREDITLINE")]
    CREDITLINE,

    /// <summary>
    /// The money market account type.
    /// </summary>
    [EnumMember(Value = "MONEYMRKT")]
    MONEYMRKT,

    /// <summary>
    /// The savings account type.
    /// </summary>
    [EnumMember(Value = "SAVINGS")]
    SAVINGS,
}

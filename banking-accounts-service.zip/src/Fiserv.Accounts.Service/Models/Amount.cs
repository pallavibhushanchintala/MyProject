﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model describing an amount of money.
/// </summary>
public class Amount
{
    /// <summary>
    /// Gets or sets the ISO4217 currency code.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating the ISO4217 currency code.
    /// </value>
    public string Currency { get; set; }

    /// <summary>
    /// Gets or sets the value of the amount.
    /// </summary>
    /// <value>
    /// A <see cref="double"/> indicating a number of monetary units specified in an active
    /// currency where the unit of currency is explicit and compliant with ISO 4217.
    /// </value>
    public double Value { get; set; }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// A model for alternate means of identifying an account.
/// </summary>
public class AlternateIdentifier
{
    /// <summary>
    /// Gets or sets the value of the alternate identifier.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the value of the alternate identifier.
    /// </value>
    [Required]
    [StringLength(100, MinimumLength = 1)]
    public string Id { get; set; }

    /// <summary>
    /// Gets or sets the type of identifier described by this entity.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the type of identifier described by this entity.
    /// </value>
    [Required]
    [StringLength(50, MinimumLength = 1)]
    public string Scheme { get; set; }
}

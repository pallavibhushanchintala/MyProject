﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model describing a product code for an account.
/// </summary>
public class ProductResponse : ProductBase
{
    /// <summary>
    /// Gets or sets a unique and immutable identifier used to identify the account resource.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the unique and immutable identifier used to identify the account resource.
    /// </value>
    public string AccountId { get; set; }
}

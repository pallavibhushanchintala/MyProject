﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// An enumeration of possible account statuses.
/// </summary>
public enum AccountStatus
{
    /// <summary>
    /// The active status.
    /// </summary>
    Active,

    /// <summary>
    /// The inactive status.
    /// </summary>
    Inactive,
}

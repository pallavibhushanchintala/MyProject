﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model for a financial transaction.
/// </summary>
public class Transaction
{
    /// <summary>
    /// Gets or sets a unique and immutable identifier used to identify the account resource.
    /// </summary>
    public string AccountId { get; set; }

    /// <summary>
    /// Gets or sets the amount of money associated with a balance or transaction.
    /// </summary>
    public Amount Amount { get; set; }

    /// <summary>
    /// Gets or sets details of a balance associated with an account.
    /// </summary>
    public RunningBalance Balance { get; set; }

    /// <summary>
    /// Gets or sets whether a monetary value (balance, transaction) is a credit or a debit.
    /// </summary>
    public TransactionType CreditDebitIndicator { get; set; }

    /// <summary>
    /// Gets or sets a customer reference number for the transaction.
    /// </summary>
    public string CustomerReferenceNumber { get; set; }

    /// <summary>
    /// Gets or sets the description of the transaction.
    /// </summary>
    public string Description { get; set; }

    /// <summary>
    /// Gets or sets the date and time when a transaction entry is comes into the account servicer.
    /// </summary>
    public DateTimeOffset EffectiveDateTime { get; set; }

    /// <summary>
    /// Gets or sets a unique and immutable identifier used to identify the transaction resource.
    /// </summary>
    public string Id { get; set; }

    /// <summary>
    /// Gets or sets the date and time at which assets become available to the account owner in case
    /// of a credit entry, or cease to be available to the account owner in case of a debit transaction
    /// entry.
    /// </summary>
    public DateTimeOffset PostedDateTime { get; set; }

    /// <summary>
    /// Gets or sets the status of a transaction entry with the account servicer.
    /// </summary>
    public TransactionStatus Status { get; set; }

    /// <summary>
    /// Gets or sets the ISO 20022 transaction type code.
    /// </summary>
    public TransactionCode TransactionCode { get; set; }
}

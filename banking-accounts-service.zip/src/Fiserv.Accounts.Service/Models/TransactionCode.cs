﻿using Newtonsoft.Json;

namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// ISO 20022 transaction code.
/// </summary>
/// <remarks>
/// <para>
/// ISO 20022 separates transactions into a domain / code / sub-code
/// three-part hierarchy. The specification changes reasonably often so
/// there is no validation on allowed values.
/// </para>
/// </remarks>
public class TransactionCode
{
    /// <summary>
    /// Gets or sets ISO 20022 transaction family.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with one of the four-character primary
    /// transaction families under the <see cref="Domain"/>.
    /// </value>
    [JsonProperty("code")]
    public string Code { get; set; }

    /// <summary>
    /// Gets or sets ISO 20022 transaction domain.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with one of the four-character top-level
    /// transaction domains from ISO 20022.
    /// </value>
    [JsonProperty("domain")]
    public string Domain { get; set; }

    /// <summary>
    /// Gets or sets ISO 20022 transaction sub-product.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with one of the four-character sub-products
    /// falling under the primary <see cref="Code"/>.
    /// </value>
    [JsonProperty("subCode")]
    public string SubCode { get; set; }
}

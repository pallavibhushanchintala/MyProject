﻿using System.ComponentModel.DataAnnotations;
using Fiserv.Core.DataAnnotations;

namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model for an account. Minimal validation on this model; derived models may override to add validation.
/// </summary>
public class AccountBase
{
    /// <summary>
    /// Gets or sets the type of account.
    /// </summary>
    /// <value>
    /// A <see cref="Models.AccountType"/> representing the type of account.
    /// </value>
    public virtual AccountType? AccountType { get; set; }

    /// <summary>
    /// Gets or sets alternate means of identifying the account.
    /// </summary>
    /// <value>
    /// A <see cref="IEnumerable{T}"/> of <see cref="AlternateIdentifier"/> indicating alternate means
    /// of identifying an account.
    /// </value>
    [CollectionItemsCannotBeNull(ErrorMessage = "Items must not be null.")]
    public virtual IEnumerable<AlternateIdentifier> AlternateIdentifiers { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether this account is considered an asset.
    /// </summary>
    /// <value>
    /// <see langword="true"/> if this is an asset account; otherwise, <see langword="false"/>.
    /// </value>
    public virtual bool? Asset { get; set; }

    /// <summary>
    /// Gets or sets the date on which the account and related basic services effectively end for the account owner.
    /// </summary>
    /// <value>
    /// A <see cref="DateTime"/> representing the date on which the account and related basic services effectively end
    /// for the account owner.
    /// </value>
    public virtual DateTimeOffset? CloseDateTime { get; set; }

    /// <summary>
    /// Gets or sets the ISO4217 currency code.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating the ISO4217 currency code.
    /// </value>
    public virtual string Currency { get; set; }

    /// <summary>
    /// Gets or sets a human-readable description of the account assigned by the account provider.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the account description.
    /// </value>
    [StringLength(50, MinimumLength = 1)]
    public virtual string Description { get; set; }

    /// <summary>
    /// Gets or sets the masked account number.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the masked account number.
    /// </value>
    [StringLength(64, MinimumLength = 1)]
    public virtual string Number { get; set; }

    /// <summary>
    /// Gets or sets the date on which the account and related basic services are effectively operational for the account owner.
    /// </summary>
    /// <value>
    /// A <see cref="DateTime"/> representing the date on which the account and related basic services are effectively operational
    /// for the account owner.
    /// </value>
    public virtual DateTimeOffset? OpenDateTime { get; set; }

    /// <summary>
    /// Gets or sets the status of the account resource.
    /// </summary>
    /// <value>
    /// A <see cref="AccountStatus"/> representing the status of the account resource.
    /// </value>
    public virtual AccountStatus? Status { get; set; }
}

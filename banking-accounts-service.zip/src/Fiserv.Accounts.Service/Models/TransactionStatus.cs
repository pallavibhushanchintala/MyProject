﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// An enumeration of possible transaction statuses.
/// </summary>
public enum TransactionStatus
{
    /// <summary>
    /// The pending status.
    /// </summary>
    Pending,

    /// <summary>
    /// The posted status.
    /// </summary>
    Posted,
}

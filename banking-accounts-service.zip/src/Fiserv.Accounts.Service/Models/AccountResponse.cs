﻿namespace Fiserv.Accounts.Service.Models;

/// <summary>
/// Model for an account including a unique identifier.
/// </summary>
public class AccountResponse : AccountBase
{
    /// <summary>
    /// Gets or sets a unique and immutable identifier used to identify the account resource.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> representing the unique and immutable identifier used to identify the account resource.
    /// </value>
    public string Id { get; set; }
}

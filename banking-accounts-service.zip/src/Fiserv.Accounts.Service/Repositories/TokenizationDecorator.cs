using AutoMapper;
using Fiserv.Accounts.Service.Data;
using Fiserv.Security.Tokenization;

namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// Repository decorator that adds tokenization support for sensitive data.
/// </summary>
/// <remarks>
/// <para>
/// Account numbers going into the data store are encrypted using the
/// <see cref="TextDataFormat.Text"/> format. Account numbers coming back out are
/// decrypted so returned information is plaintext. This is done because
/// clients of the service need access to the raw account numbers for
/// synchronization with other systems.
/// </para>
/// </remarks>
public class TokenizationDecorator : IDataRepository, IDataRepositoryDecorator
{
    /// <summary>
    /// Initializes a new instance of the <see cref="TokenizationDecorator"/> class.
    /// </summary>
    /// <param name="decorated">An <see cref="IDataRepository"/> that handles the storage and retrieval of data.</param>
    /// <param name="tokenizer">An <see cref="ITokenizer"/> that can be used to encrypt and decrypt sensitive data.</param>
    /// <param name="mapper">An <see cref="IMapper"/> that can be used to create deep copies of data transfer objects.</param>
    public TokenizationDecorator(IDataRepository decorated, ITokenizer tokenizer, IMapper mapper)
    {
        this.Decorated = decorated ?? throw new ArgumentNullException(nameof(decorated));
        this.Tokenizer = tokenizer ?? throw new ArgumentNullException(nameof(tokenizer));
        this.Mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
    }

    /// <summary>
    /// Gets the decorated data repository.
    /// </summary>
    /// <value>
    /// An <see cref="IDataRepository"/> that handles the storage and retrieval of data.
    /// </value>
    public IDataRepository Decorated { get; private set; }

    /// <summary>
    /// Gets a mapper for object cloning.
    /// </summary>
    /// <value>
    /// An <see cref="IMapper"/> that can be used to create deep copies of data transfer objects.
    /// </value>
    public IMapper Mapper { get; }

    /// <summary>
    /// Gets the tokenizer used for encryption.
    /// </summary>
    /// <value>
    /// An <see cref="ITokenizer"/> that can be used to encrypt and decrypt sensitive data.
    /// </value>
    public ITokenizer Tokenizer { get; private set; }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<Balance> AddBalanceAsync(Balance balance, string tenantId)
    {
        // Nothing to encrypt/decrypt.
        return this.Decorated.AddBalanceAsync(balance, tenantId);
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<Transaction> AddTransactionAsync(Transaction transaction, string tenantId)
    {
        // Nothing to encrypt/decrypt.
        return this.Decorated.AddTransactionAsync(transaction, tenantId);
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<Account>> FindAccountAsync(Account account, string userId, string tenantId)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        var search = this.Encrypt(account);
        var output = new List<Account>();
        var found = await this.Decorated.FindAccountAsync(search, userId, tenantId);
        foreach (var item in found)
        {
            var decrypted = this.Decrypt(item);
            output.Add(decrypted);
        }

        return output;
    }

    /// <inheritdoc/>
    public async Task<Account> GetAccountByIdAsync(string accountId, string tenantId)
    {
        var found = await this.Decorated.GetAccountByIdAsync(accountId, tenantId);
        var output = this.Decrypt(found);
        return output;
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<Account>> GetAccountsAsync(string userId, string tenantId)
    {
        var output = new List<Account>();
        var found = await this.Decorated.GetAccountsAsync(userId, tenantId);
        foreach (var account in found)
        {
            var decrypted = this.Decrypt(account);
            output.Add(decrypted);
        }

        return output;
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<AccountData<Balance>> GetBalancesByAccountIdAsync(string accountId, string tenantId)
    {
        // Nothing to encrypt/decrypt - the account object in the data is more
        // about determining presence/access, not something being returned to
        // the client.
        return this.Decorated.GetBalancesByAccountIdAsync(accountId, tenantId);
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<AccountData<Product>> GetProductsByAccountIdAsync(string accountId, string tenantId)
    {
        // Nothing to encrypt/decrypt - the account object in the data is more
        // about determining presence/access, not something being returned to
        // the client.
        return this.Decorated.GetProductsByAccountIdAsync(accountId, tenantId);
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<AccountData<Transaction>> GetTransactionsByAccountIdAsync(string accountId, string tenantId)
    {
        // Nothing to encrypt/decrypt - the account object in the data is more
        // about determining presence/access, not something being returned to
        // the client.
        return this.Decorated.GetTransactionsByAccountIdAsync(accountId, tenantId);
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<IEnumerable<Product>> UpdateProductsForAccountIdAsync(string accountId, IEnumerable<Product> products, string tenantId)
    {
        // Nothing to encrypt/decrypt.
        return this.Decorated.UpdateProductsForAccountIdAsync(accountId, products, tenantId);
    }

    /// <inheritdoc/>
    public async Task<Account> UpsertAccountAsync(Account account, string tenantId)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var input = this.Encrypt(account);
        var upserted = await this.Decorated.UpsertAccountAsync(input, tenantId);
        if (upserted == null)
        {
            return null;
        }

        var output = this.Mapper.Map<Account>(upserted);
        output.Number = account.Number;
        return output;
    }

    /// <inheritdoc/>
    public async Task<Account> UpsertAccountByIdAsync(string accountId, Account account, string tenantId)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var input = this.Encrypt(account);
        var upserted = await this.Decorated.UpsertAccountByIdAsync(accountId, input, tenantId);
        if (upserted == null)
        {
            return null;
        }

        var output = this.Mapper.Map<Account>(upserted);
        output.Number = account.Number;
        return output;
    }

    private Account Decrypt(Account encrypted)
    {
        if (encrypted == null)
        {
            return null;
        }

        var plaintext = this.Mapper.Map<Account>(encrypted);
        if (!string.IsNullOrEmpty(encrypted.Number))
        {
            plaintext.Number = this.Tokenizer.Decrypt(encrypted.Number, TextDataFormat.Text);
        }

        return plaintext;
    }

    private Account Encrypt(Account plaintext)
    {
        var encrypted = this.Mapper.Map<Account>(plaintext);
        if (!string.IsNullOrEmpty(plaintext.Number))
        {
            encrypted.Number = this.Tokenizer.Encrypt(plaintext.Number, TextDataFormat.Text);
        }

        return encrypted;
    }
}

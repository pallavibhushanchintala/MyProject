using System.Net;

namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// Logging extension for <see cref="IDataRepository"/> implementations.
/// </summary>
internal static class RepositoryLoggingExtensions
{
    private static readonly Action<ILogger, string, Exception> LogAccountMissingDataUpdateSkippedDelegate = LoggerMessage.Define<string>(LogLevel.Information, new EventId(0), "No account found with ID '{AccountId}' - did not update data.");

    private static readonly Action<ILogger, Exception> LogAmbiguousAccountMatchDelegate = LoggerMessage.Define(LogLevel.Error, new EventId(0), "Ambiguous match during account search - no account update will occur.");

    private static readonly Action<ILogger, string, string, Exception> LogBalanceAddedDelegate = LoggerMessage.Define<string, string>(LogLevel.Debug, new EventId(0), "Added balance '{BalanceId}' for account '{AccountId}'.");

    private static readonly Action<ILogger, HttpStatusCode, TimeSpan, int, int, Exception> LogClientErrorDelegate = LoggerMessage.Define<HttpStatusCode, TimeSpan, int, int>(LogLevel.Debug, new EventId(0), "Cosmos exception {StatusCode} encountered. Retrying in {SleepDuration}. {AttemptNumber} / {MaximumConfiguredRetries}");

    private static readonly Action<ILogger, string, Exception> LogCreatingNewAccountDelegate = LoggerMessage.Define<string>(LogLevel.Debug, new EventId(0), "Creating new account '{AccountId}'.");

    private static readonly Action<ILogger, string, Exception> LogReplacingAccountProductsDelegate = LoggerMessage.Define<string>(LogLevel.Debug, new EventId(0), "Replacing products for account '{AccountId}'.");

    private static readonly Action<ILogger, string, string, Exception> LogTransactionAddedDelegate = LoggerMessage.Define<string, string>(LogLevel.Debug, new EventId(0), "Added transaction '{TransactionId}' for account '{AccountId}'.");

    private static readonly Action<ILogger, string, Exception> LogUpdatingExistingAccountDelegate = LoggerMessage.Define<string>(LogLevel.Debug, new EventId(0), "Updating existing account '{AccountId}'.");

    /// <summary>
    /// Logs that an account wasn't found so it wasn't updated.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="accountId">The ID of the account that wasn't found.</param>
    public static void LogAccountMissingDataUpdateSkipped(this ILogger logger, string accountId)
    {
        LogAccountMissingDataUpdateSkippedDelegate(logger, accountId, null);
    }

    /// <summary>
    /// Logs that more than one account matched a search criteria.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    public static void LogAmbiguousAccountMatch(this ILogger logger)
    {
        LogAmbiguousAccountMatchDelegate(logger, null);
    }

    /// <summary>
    /// Logs that a balance was added to an account.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="accountId">The ID of the account that got a balance added.</param>
    /// <param name="balanceId">The ID of the balance that was added to the account.</param>
    public static void LogBalanceAdded(this ILogger logger, string accountId, string balanceId)
    {
        LogBalanceAddedDelegate(logger, balanceId, accountId, null);
    }

    /// <summary>
    /// Logs that a Cosmos DB client error occurred and will be retried.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="statusCode">The status code from the error.</param>
    /// <param name="sleepDuration">The amount of time before retry occurs.</param>
    /// <param name="attemptNumber">The number of times the operation has been tried.</param>
    /// <param name="maxRetries">The maximum number of times the operation will be retried.</param>
    public static void LogClientError(this ILogger logger, HttpStatusCode statusCode, TimeSpan sleepDuration, int attemptNumber, int maxRetries)
    {
        LogClientErrorDelegate(logger, statusCode, sleepDuration, attemptNumber, maxRetries, null);
    }

    /// <summary>
    /// Logs that a new account is being created.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="accountId">The ID of the account being created.</param>
    public static void LogCreatingNewAccount(this ILogger logger, string accountId)
    {
        LogCreatingNewAccountDelegate(logger, accountId, null);
    }

    /// <summary>
    /// Logs that the products on an account are being replaced.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="accountId">The ID of the account being updated.</param>
    public static void LogReplacingAccountProducts(this ILogger logger, string accountId)
    {
        LogReplacingAccountProductsDelegate(logger, accountId, null);
    }

    /// <summary>
    /// Logs that a transaction is being added to an account.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="accountId">The ID of the account being updated.</param>
    /// <param name="transactionId">The ID of the transaction being added to the account.</param>
    public static void LogTransactionAdded(this ILogger logger, string accountId, string transactionId)
    {
        LogTransactionAddedDelegate(logger, transactionId, accountId, null);
    }

    /// <summary>
    /// Logs that an existing account is being updated.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="accountId">The ID of the account being updated.</param>
    public static void LogUpdatingExistingAccount(this ILogger logger, string accountId)
    {
        LogUpdatingExistingAccountDelegate(logger, accountId, null);
    }
}

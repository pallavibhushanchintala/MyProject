namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// Data repository implementation that decorates an inner repository. Allows
/// traversal of the decoration hierarchy.
/// </summary>
public interface IDataRepositoryDecorator
{
    /// <summary>
    /// Gets the decorated data repository.
    /// </summary>
    /// <value>
    /// An <see cref="IDataRepository"/> that handles the storage and retrieval of data.
    /// </value>
    IDataRepository Decorated { get; }
}

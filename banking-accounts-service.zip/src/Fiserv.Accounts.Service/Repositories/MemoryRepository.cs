﻿using AutoMapper;
using Fiserv.Accounts.Service.Data;
using Fiserv.Azure.Cosmos;

namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// An <see cref="IDataRepository"/> where the data is stored in memory. This store is not multitenant-aware.
/// </summary>
/// <remarks>
/// <para>
/// When you run integration tests on a dev machine having a fixed tenant ID
/// is fine and it works... but when you run those same integration tests
/// against the stub back end and you have a "real token" with a real tenant
/// ID (like we have in Kubernetes), having the backing store understand
/// tenancy means there's no test data for that test tenant and all the
/// tests fail. That's why this isn't multitenant.
/// </para>
/// <para>
/// If we wanted to have a more realistic memory data store, we'd also need
/// the ability to set up data in memory from the outside (e.g., via API,
/// not import).
/// </para>
/// </remarks>
public class MemoryRepository : IDataRepository
{
    private readonly List<Account> _accounts = new();
    private readonly List<Balance> _balances = new();
    private readonly List<Product> _products = new();
    private readonly List<Transaction> _transactions = new();

    /// <summary>
    /// Initializes a new instance of the <see cref="MemoryRepository"/> class.
    /// </summary>
    /// <param name="mapper">
    /// An <see cref="IMapper"/> that can be used to create deep copies of data transfer objects.
    /// </param>
    /// <param name="logger">
    /// An <see cref="ILogger{T}"/> for diagnostic logging messages.
    /// </param>
    public MemoryRepository(IMapper mapper, ILogger<MemoryRepository> logger)
    {
        this.Mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        this.Logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Gets a mapper for object cloning.
    /// </summary>
    /// <value>
    /// An <see cref="IMapper"/> that can be used to create deep copies of data transfer objects.
    /// </value>
    public IMapper Mapper { get; }

    /// <summary>
    /// Gets the logger.
    /// </summary>
    /// <value>
    /// An <see cref="ILogger{T}"/> for diagnostic logging messages.
    /// </value>
    public ILogger<MemoryRepository> Logger { get; }

    /// <inheritdoc/>
    public Task<Balance> AddBalanceAsync(Balance balance, string tenantId)
    {
        if (balance == null)
        {
            throw new ArgumentNullException(nameof(balance));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        var account = this._accounts.FirstOrDefault(x => HasAccountId(x, balance.AccountId));
        if (account == null)
        {
            this.Logger.LogAccountMissingDataUpdateSkipped(balance.AccountId);
            return Task.FromResult((Balance)null);
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var store = this.Mapper.Map<Balance>(balance);
        store.Id = Guid.NewGuid().ToString();
        store.Users = Array.Empty<string>();
        this._balances.Add(store);
        this.RectifyPermissions(account);
        var output = this.Mapper.Map<Balance>(store);
        this.Logger.LogBalanceAdded(output.AccountId, output.Id);
        return Task.FromResult(output);
    }

    /// <inheritdoc/>
    public Task<Transaction> AddTransactionAsync(Transaction transaction, string tenantId)
    {
        if (transaction == null)
        {
            throw new ArgumentNullException(nameof(transaction));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        var account = this._accounts.FirstOrDefault(x => HasAccountId(x, transaction.AccountId));
        if (account == null)
        {
            this.Logger.LogAccountMissingDataUpdateSkipped(transaction.AccountId);
            return Task.FromResult((Transaction)null);
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var store = this.Mapper.Map<Transaction>(transaction);
        store.Id = Guid.NewGuid().ToString();
        store.Users = Array.Empty<string>();
        this._transactions.Add(store);
        this.RectifyPermissions(account);
        var output = this.Mapper.Map<Transaction>(store);
        this.Logger.LogTransactionAdded(output.AccountId, output.Id);
        return Task.FromResult(output);
    }

    /// <summary>
    /// Enables access to an account in-memory for a user.
    /// </summary>
    /// <param name="userId">The ID of the user to grant access.</param>
    /// <param name="accountId">The ID of the account to which the user gets access.</param>
    /// <returns>
    /// A <see cref="Task"/> to await completion.
    /// </returns>
    /// <remarks>
    /// <para>
    /// When using the in-memory repository, there's no correlation with the set
    /// of users and there's no API call that can be used to grant access to an
    /// account. In a real system, granting access to an account can't be done
    /// by updating the set of users on an account - it should be done by
    /// modifying the user, not the account. This method bridges this gap,
    /// allowing a way to update account permissions without having a user
    /// repository/API.
    /// </para>
    /// </remarks>
    public Task AddUserToAccountAsync(string userId, string accountId)
    {
        if (userId == null)
        {
            throw new ArgumentNullException(nameof(userId));
        }

        if (userId.Length == 0)
        {
            throw new ArgumentException("User ID may not be empty.", nameof(userId));
        }

        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        var existingAccount = this._accounts.SingleOrDefault(x => x.Id.Equals(accountId, StringComparison.Ordinal));
        if (existingAccount == null)
        {
            return Task.CompletedTask;
        }

        var users = existingAccount.Users?.ToList() ?? new List<string>();
        if (!users.Contains(userId))
        {
            // Modify the in-memory instance of the account.
            users.Add(userId);
            existingAccount.Users = users;
            this.RectifyPermissions(existingAccount);
        }

        return Task.CompletedTask;
    }

    /// <inheritdoc/>
    public Task<IEnumerable<Account>> FindAccountAsync(Account account, string userId, string tenantId)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        var query = this._accounts.AsQueryable()
            .Where(x => x.Type == DocumentType.Account)
            .WhereIf(account.Asset != null, x => x.Asset == account.Asset.Value)
            .WhereNotNullOrEmpty(x => x.AccountType == account.AccountType)
            .WhereIf(account.CloseDateTime != null, x => x.CloseDateTime == account.CloseDateTime.Value)
            .WhereNotNullOrEmpty(x => x.CurrencyCode == account.CurrencyCode)
            .WhereNotNullOrEmpty(x => x.Description == account.Description)
            .WhereIf(account.OpenDateTime != null, x => x.OpenDateTime == account.OpenDateTime.Value)
            .WhereNotNullOrEmpty(x => x.Number == account.Number)
            .WhereNotNullOrEmpty(x => x.Users.Contains(userId));

        if (account.AlternateIdentifiers != null)
        {
            foreach (var alternateIdentifier in account.AlternateIdentifiers)
            {
                query = query.Where(x => x.AlternateIdentifiers.Any(y => y.Id == alternateIdentifier.Id && y.Scheme.Equals(alternateIdentifier.Scheme, StringComparison.OrdinalIgnoreCase)));
            }
        }

        // Clone the output so the consumer can't modify it and change
        // what's stored.
        var existingAccounts = query.ToList();
        var toReturn = this.Mapper.Map<IEnumerable<Account>>(existingAccounts);
        return Task.FromResult(toReturn);
    }

    /// <inheritdoc/>
    public Task<Account> GetAccountByIdAsync(string accountId, string tenantId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        var found = this._accounts.Where(x => x.Id.Equals(accountId, StringComparison.Ordinal));

        // Clone the output so the consumer can't modify it and change
        // what's stored.
        var toReturn = this.Mapper.Map<Account>(found.SingleOrDefault());
        return Task.FromResult(toReturn);
    }

    /// <inheritdoc/>
    public Task<IEnumerable<Account>> GetAccountsAsync(string userId, string tenantId)
    {
        if (userId == null)
        {
            throw new ArgumentNullException(nameof(userId));
        }

        if (userId.Length == 0)
        {
            throw new ArgumentException("User ID may not be empty.", nameof(userId));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        // Clone the output so the consumer can't modify it and change
        // what's stored.
        var toReturn = this.Mapper.Map<IEnumerable<Account>>(this._accounts.Where(x => HasUser(x, userId)));
        return Task.FromResult(toReturn);
    }

    /// <inheritdoc/>
    public Task<AccountData<Balance>> GetBalancesByAccountIdAsync(string accountId, string tenantId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        // Clone the output so the consumer can't modify it and change
        // what's stored.
        var account = this.Mapper.Map<Account>(this._accounts.FirstOrDefault(a => a.Id == accountId));
        if (account == null)
        {
            return Task.FromResult(new AccountData<Balance>());
        }

        var balances = this.Mapper.Map<IEnumerable<Balance>>(this._balances.Where(x => HasAccountId(x, accountId) && x.Data != null && x.Data.Any()));
        var toReturn = new AccountData<Balance> { Account = account, Data = balances };
        return Task.FromResult(toReturn);
    }

    /// <inheritdoc/>
    public Task<AccountData<Product>> GetProductsByAccountIdAsync(string accountId, string tenantId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        // Clone the output so the consumer can't modify it and change
        // what's stored.
        var account = this.Mapper.Map<Account>(this._accounts.FirstOrDefault(a => a.Id == accountId));
        if (account == null)
        {
            return Task.FromResult(new AccountData<Product>());
        }

        var products = this.Mapper.Map<IEnumerable<Product>>(this._products.Where(x => HasAccountId(x, accountId)));
        var toReturn = new AccountData<Product> { Account = account, Data = products };
        return Task.FromResult(toReturn);
    }

    /// <inheritdoc/>
    public Task<AccountData<Transaction>> GetTransactionsByAccountIdAsync(string accountId, string tenantId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        // Clone the output so the consumer can't modify it and change
        // what's stored.
        var account = this.Mapper.Map<Account>(this._accounts.FirstOrDefault(a => a.Id == accountId));
        if (account == null)
        {
            return Task.FromResult(new AccountData<Transaction>());
        }

        var transactions = this.Mapper.Map<IEnumerable<Transaction>>(this._transactions.Where(x => HasAccountId(x, accountId)));
        var toReturn = new AccountData<Transaction> { Account = account, Data = transactions };
        return Task.FromResult(toReturn);
    }

    /// <summary>
    /// Removes access from an account in-memory for a user.
    /// </summary>
    /// <param name="userId">The ID of the user to revoke access.</param>
    /// <param name="accountId">The ID of the account for which the user gets access revoked.</param>
    /// <returns>
    /// A <see cref="Task"/> to await completion.
    /// </returns>
    /// <remarks>
    /// <para>
    /// When using the in-memory repository, there's no correlation with the set
    /// of users and there's no API call that can be used to grant access to an
    /// account. In a real system, granting access to an account can't be done
    /// by updating the set of users on an account - it should be done by
    /// modifying the user, not the account. This method bridges this gap,
    /// allowing a way to update account permissions without having a user
    /// repository/API.
    /// </para>
    /// </remarks>
    public Task RemoveUserFromAccountAsync(string userId, string accountId)
    {
        if (userId == null)
        {
            throw new ArgumentNullException(nameof(userId));
        }

        if (userId.Length == 0)
        {
            throw new ArgumentException("User ID may not be empty.", nameof(userId));
        }

        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        var existingAccount = this._accounts.SingleOrDefault(x => x.Id.Equals(accountId, StringComparison.Ordinal));
        if (existingAccount == null)
        {
            return Task.CompletedTask;
        }

        var users = existingAccount.Users?.ToList() ?? new List<string>();
        if (users.Contains(userId))
        {
            // Modify the in-memory instance of the account.
            users.Remove(userId);
            existingAccount.Users = users;
            this.RectifyPermissions(existingAccount);
        }

        return Task.CompletedTask;
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<Product>> UpdateProductsForAccountIdAsync(string accountId, IEnumerable<Product> products, string tenantId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        if (products == null)
        {
            throw new ArgumentNullException(nameof(products));
        }

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        var account = await this.GetAccountByIdAsync(accountId, tenantId);
        if (account == null)
        {
            this.Logger.LogAccountMissingDataUpdateSkipped(accountId);
            return null;
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var toInsert = this.Mapper.Map<IEnumerable<Product>>(products);
        foreach (var product in toInsert)
        {
            product.AccountId = accountId;
        }

        this.Logger.LogReplacingAccountProducts(accountId);
        var old = this._products.Where(x => x.AccountId.Equals(accountId, StringComparison.Ordinal)).ToArray();
        foreach (var toRemove in old)
        {
            this._products.Remove(toRemove);
        }

        foreach (var product in toInsert)
        {
            this._products.Add(product);
        }

        this.RectifyPermissions(account);

        var toReturn = this.Mapper.Map<IEnumerable<Product>>(toInsert);
        return toReturn;
    }

    /// <inheritdoc/>
    public async Task<Account> UpsertAccountAsync(Account account, string tenantId)
    {
        account.Validate();
        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        if (account.Id != null)
        {
            throw new ArgumentException($"You must not specify an account ID when upserting by account type match. Either specify the ID as null or use the {nameof(this.UpsertAccountAsync)} overload that takes an ID.");
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var accountSearch = account.CloneForIdentitySearch();
        var existingAccounts = await this.FindAccountAsync(accountSearch, null, tenantId);
        if (existingAccounts.Count() > 1)
        {
            // More than one match - it should be just the one, but you never know.
            this.Logger.LogAmbiguousAccountMatch();
            return null;
        }

        var toInsert = this.Mapper.Map<Account>(account);
        var existingAccount = existingAccounts.FirstOrDefault();
        if (existingAccount == null)
        {
            toInsert.Id = toInsert.GenerateAccountId();
            toInsert.Users = Array.Empty<string>();
            this.Logger.LogCreatingNewAccount(toInsert.Id);
        }
        else
        {
            // existingAccount is a clone, so remove it by ID
            var toRemove = this._accounts.Where(x => HasAccountId(x, existingAccount.Id)).First();
            this._accounts.Remove(toRemove);
            toInsert.Id = existingAccount.Id;
            toInsert.Users = existingAccount.Users;
            this.Logger.LogUpdatingExistingAccount(toInsert.Id);
        }

        toInsert.AccountId = toInsert.Id;
        this._accounts.Add(toInsert);
        this.RectifyPermissions(toInsert);

        var toReturn = this.Mapper.Map<Account>(toInsert);
        return toReturn;
    }

    /// <inheritdoc/>
    public Task<Account> UpsertAccountByIdAsync(string accountId, Account account, string tenantId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID may not be empty.", nameof(accountId));
        }

        account.Validate();

        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID may not be empty.", nameof(tenantId));
        }

        if (account.Id != null && !account.Id.Equals(accountId, StringComparison.Ordinal))
        {
            throw new ArgumentException($"Account ID to update '{accountId}' does not match the ID in the account object '{account.Id}'. Either the account object ID must be null or it must be the exact ID of the account being updated.");
        }

        var existingAccount = this._accounts.SingleOrDefault(x => x.Id.Equals(accountId, StringComparison.Ordinal));
        if (existingAccount == null)
        {
            this.Logger.LogAccountMissingDataUpdateSkipped(accountId);
            return Task.FromResult((Account)null);
        }

        // Clone the input and output so the consumer can't modify those
        // objects and change what's stored.
        var toInsert = this.Mapper.Map<Account>(account);
        toInsert.AccountId = existingAccount.AccountId;
        toInsert.Id = existingAccount.Id;
        toInsert.Users = existingAccount.Users;

        this._accounts.Remove(existingAccount);
        this._accounts.Add(toInsert);
        this.RectifyPermissions(toInsert);
        var toReturn = this.Mapper.Map<Account>(toInsert);
        return Task.FromResult(toReturn);
    }

    private static bool HasAccountId(Document entity, string accountId)
    {
        return entity.AccountId.Equals(accountId, StringComparison.Ordinal);
    }

    private static bool HasUser(Document entity, string userId)
    {
        return entity.Users.Contains(userId, StringComparer.Ordinal);
    }

    private static void RectifyPermissions<T>(List<T> source, Account account)
        where T : Document
    {
        var affected = source.Where(x => HasAccountId(x, account.AccountId)).ToArray();
        foreach (var item in affected)
        {
            item.Users = account.Users.ToArray();
        }
    }

    private void RectifyPermissions(Account account)
    {
        RectifyPermissions(this._balances, account);
        RectifyPermissions(this._transactions, account);
        RectifyPermissions(this._products, account);
    }
}

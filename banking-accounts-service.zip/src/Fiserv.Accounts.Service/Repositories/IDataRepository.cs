﻿using Fiserv.Accounts.Service.Data;

namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// An interface defining interactions with a data store.
/// </summary>
public interface IDataRepository
{
    /// <summary>
    /// Adds a balance to the system.
    /// </summary>
    /// <param name="balance">
    /// The <see cref="Balance"/> to add, which should have the associated
    /// <see cref="Document.AccountId"/> set.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the account.
    /// </param>
    /// <returns>
    /// The <paramref name="balance"/> with the <see cref="Document.Id"/>
    /// updated. The <see cref="Document.Users"/> may not yet be updated
    /// as that relates more to the account than the balance.
    /// </returns>
    Task<Balance> AddBalanceAsync(Balance balance, string tenantId);

    /// <summary>
    /// Adds a transaction to the system.
    /// </summary>
    /// <param name="transaction">
    /// The <see cref="Transaction"/> to add, which should have the associated
    /// <see cref="Document.AccountId"/> set.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the account.
    /// </param>
    /// <returns>
    /// The <paramref name="transaction"/> with the
    /// <see cref="Document.Id"/> updated. The
    /// <see cref="Document.Users"/> may not yet be updated as that
    /// relates more to the account than the transaction.
    /// </returns>
    Task<Transaction> AddTransactionAsync(Transaction transaction, string tenantId);

    /// <summary>
    /// Finds an account based on alternate identifiers and attributes.
    /// </summary>
    /// <param name="account">
    /// An <see cref="Account"/> representing search parameters. Each populated
    /// parameter will be matched during the search.
    /// </param>
    /// <param name="userId">
    /// A <see cref="string"/> with the ID of the user retrieving accounts. If
    /// the value is <see langword="null"/> then all results will be returned;
    /// if the value is populated, the results will be filtered by user access.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the user and account.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> of <see cref="Account"/>. This will be
    /// empty if there are no matching accounts.
    /// </returns>
    Task<IEnumerable<Account>> FindAccountAsync(Account account, string userId, string tenantId);

    /// <summary>
    /// Retrieves accounts from the data store.
    /// </summary>
    /// <param name="userId">
    /// A <see cref="string"/> with the ID of the user retrieving accounts. This
    /// value is required; it is not allowed to get all accounts for a tenant.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the user and
    /// accounts.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> of <see cref="Account"/> accessible to
    /// the specified user.
    /// </returns>
    Task<IEnumerable<Account>> GetAccountsAsync(string userId, string tenantId);

    /// <summary>
    /// Retrieves a specific account from the data store.
    /// </summary>
    /// <param name="accountId">
    /// A <see cref="string"/> representing the unique identifier of the
    /// account.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the user and
    /// account.
    /// </param>
    /// <returns>
    /// The <see cref="Account"/> with the specified ID. This will be
    /// <see langword="null"/> if the account is not found.
    /// </returns>
    Task<Account> GetAccountByIdAsync(string accountId, string tenantId);

    /// <summary>
    /// Retrieves all the balances associated with a single account. Filters out
    /// any balances that don't actually have any balance amount data.
    /// </summary>
    /// <param name="accountId">
    /// A <see cref="string"/> representing the unique identifier of the
    /// account.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the user and
    /// account.
    /// </param>
    /// <returns>
    /// An <see cref="AccountData{T}"/> with the set of <see cref="Balance"/>
    /// for the specified account.
    /// </returns>
    Task<AccountData<Balance>> GetBalancesByAccountIdAsync(string accountId, string tenantId);

    /// <summary>
    /// Retrieves all the products associated with a single account.
    /// </summary>
    /// <param name="accountId">
    /// A <see cref="string"/> representing the unique identifier of the
    /// account.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the user and
    /// account.
    /// </param>
    /// <returns>
    /// An <see cref="AccountData{T}"/> with the <see cref="Product"/> for the
    /// specified account.
    /// </returns>
    Task<AccountData<Product>> GetProductsByAccountIdAsync(string accountId, string tenantId);

    /// <summary>
    /// Retrieves all the transactions associated with a single account.
    /// </summary>
    /// <param name="accountId">
    /// A <see cref="string"/> representing the unique identifier of the
    /// account.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the user and
    /// account.
    /// </param>
    /// <returns>
    /// An <see cref="AccountData{T}"/> with the <see cref="Transaction"/> for
    /// the specified account.
    /// </returns>
    Task<AccountData<Transaction>> GetTransactionsByAccountIdAsync(string accountId, string tenantId);

    /// <summary>
    /// Updates the products associated with a specific account.
    /// </summary>
    /// <param name="accountId">
    /// The identifier of the account for which products should be updated.
    /// </param>
    /// <param name="products">
    /// The list of products to set for the account.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the account.
    /// </param>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with the list of the products for the
    /// account after updating.
    /// </returns>
    Task<IEnumerable<Product>> UpdateProductsForAccountIdAsync(string accountId, IEnumerable<Product> products, string tenantId);

    /// <summary>
    /// Upserts an account into the system.
    /// </summary>
    /// <param name="account">
    /// The <see cref="Account"/> being added to the system.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the account.
    /// </param>
    /// <returns>
    /// An <see cref="Account"/> containing details of the upserted account.
    /// </returns>
    Task<Account> UpsertAccountAsync(Account account, string tenantId);

    /// <summary>
    /// Upserts an account into the system by identifier.
    /// </summary>
    /// <param name="accountId">
    /// A <see cref="string"/> indicating the unique identifier of the account
    /// to be upserted.
    /// </param>
    /// <param name="account">
    /// The <see cref="Account"/> being added to the system.
    /// </param>
    /// <param name="tenantId">
    /// A <see cref="string"/> with the ID of the tenant that owns the account.
    /// </param>
    /// <returns>
    /// An <see cref="Account"/> containing details of the upserted account.
    /// </returns>
    Task<Account> UpsertAccountByIdAsync(string accountId, Account account, string tenantId);
}

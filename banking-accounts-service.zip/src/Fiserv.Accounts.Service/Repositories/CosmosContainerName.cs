namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// Constants with the names of containers within tenant databases.
/// </summary>
public static class CosmosContainerName
{
    /// <summary>
    /// The name of the container that holds accounts, balances, transactions, and products.
    /// </summary>
    public const string Accounts = "accounts";
}

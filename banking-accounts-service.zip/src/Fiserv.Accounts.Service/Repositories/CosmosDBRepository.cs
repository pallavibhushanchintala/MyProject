﻿using System.Net;
using Fiserv.Accounts.Service.Data;
using Fiserv.Azure.Cosmos;
using Fiserv.Extensions.Logging;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Polly;
using Polly.Contrib.WaitAndRetry;
using Polly.Retry;

namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// An implementation of <see cref="IDataRepository"/> that uses CosmosDB.
/// </summary>
public class CosmosDBRepository : IDataRepository
{
    /// <summary>
    /// Default number of times a Cosmos operation will be retried based on 429 ("too many requests") and 408 ("request timeout") errors before we give up.
    /// </summary>
    private const int ClientErrorRetriesDefault = 3;

    private readonly AsyncRetryPolicy _clientErrorRetryPolicy;

    /// <summary>
    /// Initializes a new instance of the <see cref="CosmosDBRepository"/> class.
    /// </summary>
    /// <param name="cosmosClient">A <see cref="CosmosClient"/> for communicating with CosmosDB.</param>
    /// <param name="cosmosLinqQuery">
    /// An <see cref="ICosmosLinqQuery"/> used to create a CosmosDB feed iterator.
    /// </param>
    /// <param name="aggregateLogger">
    /// An <see cref="IAggregateLogger{T}"/> used for diagnostic and audit log messages.
    /// </param>
    /// <param name="clientErrorRetries">
    /// The number of times the repository should retry an operation due to a
    /// Cosmos DB client error like HTTP 429 (too many requests) or HTTP 408
    /// (request timeout). This is primarily useful in testing, where the Cosmos
    /// DB emulator can be slow on the build server and cause more delays than a
    /// real Cosmos DB instance. In production, the default is acceptable.
    /// </param>
    public CosmosDBRepository(CosmosClient cosmosClient, ICosmosLinqQuery cosmosLinqQuery, IAggregateLogger<CosmosDBRepository> aggregateLogger, int clientErrorRetries = ClientErrorRetriesDefault)
    {
        this.CosmosClient = cosmosClient ?? throw new ArgumentNullException(nameof(cosmosClient));
        this.CosmosLinqQuery = cosmosLinqQuery ?? throw new ArgumentNullException(nameof(cosmosLinqQuery));
        this.AggregateLogger = aggregateLogger ?? throw new ArgumentNullException(nameof(aggregateLogger));
        this._clientErrorRetryPolicy = Policy.Handle<CosmosException>(x => x.StatusCode == HttpStatusCode.TooManyRequests || x.StatusCode == HttpStatusCode.RequestTimeout)
            .WaitAndRetryAsync(
                Backoff.DecorrelatedJitterBackoffV2(TimeSpan.FromSeconds(1), clientErrorRetries),
                onRetry: (exception, sleepDuration, attemptNumber, context) =>
                {
                    this.AggregateLogger.DiagnosticLogger.LogClientError((exception as CosmosException).StatusCode, sleepDuration, attemptNumber, clientErrorRetries);
                });
    }

    /// <summary>
    /// Gets the CosmosDB client.
    /// </summary>
    public CosmosClient CosmosClient
    {
        get;
    }

    /// <summary>
    /// Gets an <see cref="ICosmosLinqQuery"/> used to create a CosmosDB feed iterator.
    /// </summary>
    public ICosmosLinqQuery CosmosLinqQuery
    {
        get;
    }

    /// <summary>
    /// Gets the <see cref="IAggregateLogger{T}"/>.
    /// </summary>
    public IAggregateLogger<CosmosDBRepository> AggregateLogger
    {
        get;
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<Balance> AddBalanceAsync(Balance balance, string tenantId)
    {
        throw new NotSupportedException("Cosmos DB does not currently support adding a balance through this interface.");
    }

    /// <inheritdoc/>
    [ExcludeFromCodeCoverage]
    public Task<Transaction> AddTransactionAsync(Transaction transaction, string tenantId)
    {
        throw new NotSupportedException("Cosmos DB does not currently support adding a transaction through this interface.");
    }

    /// <inheritdoc/>
    [SuppressMessage("CA1304", "CA1304", Justification = "Cosmos DB doesn't support CultureInfo.")]
    public async Task<IEnumerable<Account>> FindAccountAsync(Account account, string userId, string tenantId)
    {
        if (account == null)
        {
            throw new ArgumentNullException(nameof(account));
        }

        ValidateTenantId(tenantId);

        var queryable = this.GetAccountsQueryable(tenantId);

        var query = queryable
            .Where(x => x.Type == DocumentType.Account)
            .WhereIf(account.Asset != null, x => x.Asset == account.Asset.Value)
            .WhereNotNullOrEmpty(x => x.AccountType == account.AccountType)
            .WhereIf(account.CloseDateTime != null, x => x.CloseDateTime == account.CloseDateTime.Value)
            .WhereNotNullOrEmpty(x => x.CurrencyCode == account.CurrencyCode)
            .WhereNotNullOrEmpty(x => x.Description == account.Description)
            .WhereIf(account.OpenDateTime != null, x => x.OpenDateTime == account.OpenDateTime.Value)
            .WhereNotNullOrEmpty(x => x.Number == account.Number)
            .WhereNotNullOrEmpty(x => x.Users.Contains(userId));

        if (account.AlternateIdentifiers != null)
        {
            foreach (var alternateIdentifier in account.AlternateIdentifiers)
            {
                query = query.Where(x => x.AlternateIdentifiers.Any(y => y.Id == alternateIdentifier.Id && y.Scheme.ToLower() == alternateIdentifier.Scheme.ToLower()));
            }
        }

        return await this.ProcessFeedIterator(query);
    }

    /// <inheritdoc/>
    public async Task<Account> GetAccountByIdAsync(string accountId, string tenantId)
    {
        ValidateAccountId(accountId);
        ValidateTenantId(tenantId);

        // Use Id (exact ID) instead of AccountId (partition key) when getting
        // an account by ID because it's cheaper in request units.
        var queryable = this.GetAccountsQueryable(tenantId);
        var query = queryable
            .Where(x => x.Type == DocumentType.Account)
            .Where(x => x.Id == accountId);

        var accounts = await this.ProcessFeedIterator(query);
        return accounts.FirstOrDefault();
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<Account>> GetAccountsAsync(string userId, string tenantId)
    {
        ValidateUserId(userId);
        ValidateTenantId(tenantId);

        var queryable = this.GetAccountsQueryable(tenantId);
        var query = queryable
            .Where(x => x.Type == DocumentType.Account)
            .Where(x => x.Users.Contains(userId));

        return await this.ProcessFeedIterator(query);
    }

    /// <inheritdoc/>
    public async Task<AccountData<Balance>> GetBalancesByAccountIdAsync(string accountId, string tenantId)
    {
        ValidateAccountId(accountId);
        ValidateTenantId(tenantId);
        var balances = await this.GetAccountDataAsync<Balance>(tenantId, DocumentType.Balance, accountId);
        balances.Data = balances.Data.Where(d => d.Data != null && d.Data.Any());
        return balances;
    }

    /// <inheritdoc/>
    public Task<AccountData<Product>> GetProductsByAccountIdAsync(string accountId, string tenantId)
    {
        ValidateAccountId(accountId);
        ValidateTenantId(tenantId);
        return this.GetAccountDataAsync<Product>(tenantId, DocumentType.Product, accountId);
    }

    /// <inheritdoc/>
    public Task<AccountData<Transaction>> GetTransactionsByAccountIdAsync(string accountId, string tenantId)
    {
        ValidateAccountId(accountId);
        ValidateTenantId(tenantId);
        return this.GetAccountDataAsync<Transaction>(tenantId, DocumentType.Transaction, accountId);
    }

    /// <inheritdoc/>
    public async Task<IEnumerable<Product>> UpdateProductsForAccountIdAsync(string accountId, IEnumerable<Product> products, string tenantId)
    {
        ValidateAccountId(accountId);
        ValidateTenantId(tenantId);

        if (products == null)
        {
            throw new ArgumentNullException(nameof(products));
        }

        using var audit = this.AggregateLogger.AuditLogger.BeginAudit();
        audit.Activity = ActivityType.Update;
        audit.Message = "Update products for account.";
        audit.ObjectTarget = accountId;
        audit.ObjectType = AuditObjectType.Account;
        audit.Signature = SignatureType.User_Audit;
        audit.Action = ActionType.Fail;

        var existingProducts = await this.GetProductsByAccountIdAsync(accountId, tenantId);
        if (existingProducts.Account == null)
        {
            this.AggregateLogger.DiagnosticLogger.LogAccountMissingDataUpdateSkipped(accountId);
            return null;
        }

        var container = this.AccountsContainerForTenant(tenantId);
        var tasks = new List<Task<ItemResponse<Product>>>();

        if (existingProducts.Data != null)
        {
            foreach (var product in existingProducts.Data)
            {
                tasks.Add(this._clientErrorRetryPolicy.ExecuteAsync(() => container.DeleteItemAsync<Product>(product.Id, new PartitionKey(accountId))));
            }
        }

        foreach (var newProduct in products)
        {
            newProduct.AccountId = accountId;
            newProduct.Id = Guid.NewGuid().ToString();
            newProduct.Users = existingProducts.Account.Users;
            tasks.Add(this._clientErrorRetryPolicy.ExecuteAsync(() => container.UpsertItemAsync(newProduct, new PartitionKey(accountId))));
        }

        await Task.WhenAll(tasks);
        audit.Action = ActionType.Success;
        return products;
    }

    /// <inheritdoc/>
    public async Task<Account> UpsertAccountAsync(Account account, string tenantId)
    {
        account.Validate();
        ValidateTenantId(tenantId);
        if (account.Id != null)
        {
            throw new ArgumentException($"You must not specify an account ID when upserting by account type match. Either specify the ID as null or use the {nameof(this.UpsertAccountAsync)} overload that takes an ID.");
        }

        string id = null;

        // Search for a matching account only by the account's routing number (rtn), account type and number,
        // as other fields may have changed.
        var accountSearch = account.CloneForIdentitySearch();

        using var audit = this.AggregateLogger.AuditLogger.BeginAudit();
        audit.Activity = ActivityType.Update;
        audit.Message = "Update account data.";
        audit.ObjectType = AuditObjectType.Account;
        audit.Signature = SignatureType.User_Audit;
        audit.Action = ActionType.Fail;
        var existingAccounts = await this.FindAccountAsync(accountSearch, null, tenantId);
        if (existingAccounts.Any())
        {
            if (existingAccounts.Count() > 1)
            {
                this.AggregateLogger.DiagnosticLogger.LogAmbiguousAccountMatch();
                return null;
            }

            id = existingAccounts.First().Id;
            account.Users = existingAccounts.First().Users;
        }
        else
        {
            // Ignore any users that were submitted - grant access to accounts by adding them to the user, not adding users to accounts.
            id = account.GenerateAccountId();
            account.Users = Array.Empty<string>();
        }

        account.Id = account.AccountId = audit.ObjectTarget = id;

        var upserted = await this.ExecuteUpsertAsync(account, account.AccountId, tenantId);
        audit.Action = ActionType.Success;
        return upserted;
    }

    /// <inheritdoc/>
    public async Task<Account> UpsertAccountByIdAsync(string accountId, Account account, string tenantId)
    {
        ValidateAccountId(accountId);
        account.Validate();
        ValidateTenantId(tenantId);
        if (account.Id != null && !account.Id.Equals(accountId, StringComparison.Ordinal))
        {
            throw new ArgumentException($"Account ID to update '{accountId}' does not match the ID in the account object '{account.Id}'. Either the account object ID must be null or it must be the exact ID of the account being updated.");
        }

        using var audit = this.AggregateLogger.AuditLogger.BeginAudit();
        audit.Activity = ActivityType.Update;
        audit.Message = "Update account data.";
        audit.ObjectType = AuditObjectType.Account;
        audit.ObjectTarget = accountId;
        audit.Signature = SignatureType.User_Audit;
        audit.Action = ActionType.Fail;
        var existingAccount = await this.GetAccountByIdAsync(accountId, tenantId);
        if (existingAccount == null)
        {
            this.AggregateLogger.DiagnosticLogger.LogAccountMissingDataUpdateSkipped(accountId);
            return null;
        }

        account.Id = existingAccount.Id;
        account.AccountId = existingAccount.Id;

        // Ignore any users that were submitted - grant access to accounts by adding them to the user, not adding users to accounts.
        account.Users = existingAccount.Users;

        var upserted = await this.ExecuteUpsertAsync(account, accountId, tenantId);
        audit.Action = ActionType.Success;
        return upserted;
    }

    private static void ValidateAccountId(string accountId)
    {
        if (accountId == null)
        {
            throw new ArgumentNullException(nameof(accountId));
        }

        if (accountId.Length == 0)
        {
            throw new ArgumentException("Account ID must not be an empty string.", nameof(accountId));
        }
    }

    private static void ValidateTenantId(string tenantId)
    {
        if (tenantId == null)
        {
            throw new ArgumentNullException(nameof(tenantId));
        }

        if (tenantId.Length == 0)
        {
            throw new ArgumentException("Tenant ID must not be an empty string.", nameof(tenantId));
        }
    }

    private static void ValidateUserId(string userId)
    {
        if (userId == null)
        {
            throw new ArgumentNullException(nameof(userId));
        }

        if (userId.Length == 0)
        {
            throw new ArgumentException("User ID must not be an empty string.", nameof(userId));
        }
    }

    /// <summary>
    /// Gets the accounts container for a specific tenant by ID.
    /// </summary>
    /// <param name="tenantId">
    /// The tenant ID for which the accounts container should be retrieved.
    /// </param>
    /// <returns>
    /// The tenant's accounts container for query or update.
    /// </returns>
    private Container AccountsContainerForTenant(string tenantId)
    {
        return this.CosmosClient.GetContainer(tenantId, CosmosContainerName.Accounts);
    }

    /// <summary>
    /// Execute an upsert against a CosmosDB container.
    /// </summary>
    /// <typeparam name="T">The type of item being upserted.</typeparam>
    /// <param name="item">The item to be upserted.</param>
    /// <param name="key">A <see cref="string"/> representing the partition key to be used for the upsert.</param>
    /// <param name="tenantId">
    /// The tenant ID (which is also the Cosmos database ID) for which the upsert is occurring.
    /// </param>
    /// <returns>The <typeparamref name="T"/> specified in the request.</returns>
    private async Task<T> ExecuteUpsertAsync<T>(T item, string key, string tenantId)
    {
        var container = this.AccountsContainerForTenant(tenantId);
        var response = await this._clientErrorRetryPolicy.ExecuteAsync(() => container.UpsertItemAsync(item, new PartitionKey(key)));
        return response.Resource;
    }

    /// <summary>
    /// Reads the <see cref="Account"/> and one related document type from the database.
    /// </summary>
    /// <param name="tenantId">The tenant ID (which is also the Cosmos database ID) for which data should be retrieved.</param>
    /// <param name="documentType">The <see cref="string"/> constant with the document type differentiator. This should come from <see cref="DocumentType"/> and should correspond to <typeparamref name="T"/>.</param>
    /// <param name="accountId">The <see cref="string"/> with the ID of the <see cref="Account"/> to retrieve.</param>
    /// <typeparam name="T">The second/related type of document to get with the <see cref="Account"/>.</typeparam>
    /// <returns>An <see cref="AccountData{T}"/> with the <see cref="Account"/> and related data.</returns>
    private async Task<AccountData<T>> GetAccountDataAsync<T>(string tenantId, string documentType, string accountId)
        where T : Document
    {
        var data = new List<T>();
        var results = new AccountData<T> { Data = data };
        var query = new QueryDefinition($"SELECT * FROM c WHERE (c.type = '{DocumentType.Account}' OR c.type = '{documentType}') AND c.accountId = @id")
            .WithParameter("@id", accountId);
        var container = this.AccountsContainerForTenant(tenantId);
        using var iterator = container.GetItemQueryStreamIterator(query);
        while (iterator.HasMoreResults)
        {
            using var response = await this._clientErrorRetryPolicy.ExecuteAsync(() => iterator.ReadNextAsync());
            using var sr = new StreamReader(response.Content);
            using var jtr = new JsonTextReader(sr);
            var responseObject = await JToken.ReadFromAsync(jtr);
            foreach (var document in responseObject["Documents"])
            {
                // `type` is our document discriminator and Newtonsoft.Json
                // doesn't let us override the way they handle type
                // discriminators so we need to detect/deserialize
                // ourselves.
                if (DocumentType.Account.Equals((string)document["type"], StringComparison.Ordinal))
                {
                    results.Account = document.ToObject<Account>();
                }
                else if (documentType.Equals((string)document["type"], StringComparison.Ordinal))
                {
                    data.Add(document.ToObject<T>());
                }
            }
        }

        return results;
    }

    /// <summary>
    /// Gets a queryable view over the accounts container.
    /// </summary>
    /// <param name="tenantId">The tenant ID (which is also the Cosmos database ID) for which accounts will be queried.</param>
    /// <returns>An <see cref="IOrderedQueryable{T}"/> to use for creating data queries.</returns>
    private IOrderedQueryable<Account> GetAccountsQueryable(string tenantId)
    {
        return this.AccountsContainerForTenant(tenantId).GetItemLinqQueryable<Account>();
    }

    /// <summary>
    /// Processes a <see cref="FeedIterator{T}"/> to read results from Cosmos DB.
    /// </summary>
    /// <typeparam name="T">The type of document being queried.</typeparam>
    /// <param name="query">An <see cref="IQueryable{T}"/> containing the query to be executed..</param>
    /// <returns>A <see cref="List{T}"/> containing the results of the query iterator.</returns>
    private async Task<List<T>> ProcessFeedIterator<T>(IQueryable<T> query)
    {
        var collection = new List<T>();
        var iterator = this.CosmosLinqQuery.GetFeedIterator(query);
        while (iterator.HasMoreResults)
        {
            foreach (var document in await this._clientErrorRetryPolicy.ExecuteAsync(() => iterator.ReadNextAsync()))
            {
                collection.Add(document);
            }
        }

        return collection;
    }
}

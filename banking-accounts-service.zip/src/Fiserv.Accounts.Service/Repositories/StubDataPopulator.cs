using Fiserv.Accounts.Service.Data;

namespace Fiserv.Accounts.Service.Repositories;

/// <summary>
/// Factory that populates stub data for testing and local development.
/// Generally used in conjunction with the <see cref="MemoryRepository"/>.
/// </summary>
/// <remarks>
/// <para>
/// When stub data is populated, the tenant ID is <c>local-test-tenant</c>
/// and the only user is user <c>local-test-user</c>.
/// </para>
/// <para>
/// A data populator is used instead of having the
/// <see cref="MemoryRepository"/> or a similar in-memory solution self-populate
/// due to the need to support and verify tokenization. The
/// <see cref="TokenizationDecorator"/> needs a chance to intercept the data both
/// inbound and outbound such that the "stored data" is properly encrypted
/// and can, thus, also be decrypted.
/// </para>
/// </remarks>
public static class StubDataPopulator
{
    /// <summary>
    /// The default test tenant ID = <c>local-test-tenant</c>. This value
    /// can be used in test suites when running against stub data.
    /// </summary>
    public const string TenantId = "local-test-tenant";

    /// <summary>
    /// The default test user ID = <c>local-test-user</c>. This value
    /// can be used in test suites when running against stub data.
    /// </summary>
    public const string UserId = "local-test-user";

    /// <summary>
    /// Populates a known set of stub data into a data repository.
    /// </summary>
    /// <param name="repository">The repository into which the data should be populated.</param>
    /// <returns>
    /// A <see cref="Task"/> to await completion.
    /// </returns>
    public static async Task Populate(IDataRepository repository)
    {
        if (repository == null)
        {
            throw new ArgumentNullException(nameof(repository));
        }

        (var checking, var savings, var credit) = await PopulateAccounts(repository);
        await PopulateProducts(repository, checking, savings, credit);
        await PopulateBalances(repository, checking, savings, credit);
        await PopulateTransactions(repository, checking);
    }

    private static async Task<(Account Checking, Account Savings, Account Credit)> PopulateAccounts(IDataRepository repository)
    {
        var checking = await repository.UpsertAccountAsync(
            new Account
            {
                AccountType = "CHECKING",
                AlternateIdentifiers = new List<AlternateIdentifier>
                {
                    new AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Asset = true,
                CloseDateTime = DateTimeOffset.MinValue,
                CurrencyCode = "USD",
                Description = "my checking",
                Number = "11122",
                OpenDateTime = DateTimeOffset.MinValue,
                Status = "active",
            },
            TenantId);

        var savings = await repository.UpsertAccountAsync(
            new Account
            {
                AccountType = "SAVINGS",
                AlternateIdentifiers = new List<AlternateIdentifier>
                {
                    new AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Asset = true,
                CloseDateTime = DateTimeOffset.MinValue,
                CurrencyCode = "USD",
                Description = "my savings",
                Number = "11133",
                OpenDateTime = DateTimeOffset.MinValue,
                Status = "inactive",
            },
            TenantId);

        var credit = await repository.UpsertAccountAsync(
            new Account
            {
                AccountType = "CREDITLINE",
                AlternateIdentifiers = new List<AlternateIdentifier>
                {
                    new AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Asset = false,
                CloseDateTime = DateTimeOffset.MinValue,
                CurrencyCode = "USD",
                Description = "credit line",
                Number = "11144",
                OpenDateTime = DateTimeOffset.MinValue,
                Status = "active",
            },
            TenantId);

        // Unattached account - no user will be connected to this one.
        await repository.UpsertAccountAsync(
            new Account
            {
                AccountType = "CHECKING",
                AlternateIdentifiers = new List<AlternateIdentifier>
                {
                    new AlternateIdentifier
                    {
                        Id = "123456",
                        Scheme = AlternateIdentifierScheme.RoutingTransitNumber,
                    },
                },
                Asset = true,
                CloseDateTime = DateTimeOffset.MinValue,
                CurrencyCode = "USD",
                Description = "unlinked checking",
                Number = "11155",
                OpenDateTime = DateTimeOffset.MinValue,
                Status = "active",
            },
            TenantId);

        // Special case for memory repository since there's no user store. If it
        // turns out we need to have other stub repo types that support user
        // management stubbing, we'll need a new interface so we can check for
        // something other than just MemoryRepository.
        var innerRepo = repository;
        while (innerRepo is IDataRepositoryDecorator decorator)
        {
            innerRepo = decorator.Decorated;
        }

        if (innerRepo is MemoryRepository memoryRepository)
        {
            // We specifically don't add the user to the last checking account
            // added. This allows us to search for accounts and ensure user
            // filtering works.
            await memoryRepository.AddUserToAccountAsync(UserId, checking.Id);
            await memoryRepository.AddUserToAccountAsync(UserId, savings.Id);
            await memoryRepository.AddUserToAccountAsync(UserId, credit.Id);
        }

        return (checking, savings, credit);
    }

    private static async Task PopulateBalances(IDataRepository repository, Account checking, Account savings, Account credit)
    {
        var balances = new Balance[]
        {
            new Balance { AccountId = checking.AccountId, CurrencyCode = "USD", Data = new List<BalanceData> { new BalanceData { Amount = 543, DateTime = DateTimeOffset.Now.AddMinutes(-20) }, new BalanceData { Amount = 1234.56, DateTime = DateTimeOffset.Now } }, BalanceType = "OPBD" },
            new Balance { AccountId = checking.AccountId, CurrencyCode = "USD", Data = new List<BalanceData> { new BalanceData { Amount = 234.56, DateTime = DateTimeOffset.Now } }, BalanceType = "OPAV" },
            new Balance { AccountId = savings.AccountId, CurrencyCode = "USD", Data = new List<BalanceData> { new BalanceData { Amount = 4567.89, DateTime = DateTimeOffset.Now } }, BalanceType = "OPBD" },
            new Balance { AccountId = savings.AccountId, CurrencyCode = "USD", Data = new List<BalanceData> { new BalanceData { Amount = 3456.78, DateTime = DateTimeOffset.Now } }, BalanceType = "OPAV" },
            new Balance { AccountId = credit.AccountId, CurrencyCode = "USD", Data = new List<BalanceData> { new BalanceData { Amount = 11122.33, DateTime = DateTimeOffset.Now } }, BalanceType = "OPBD" },
            new Balance { AccountId = credit.AccountId, CurrencyCode = "USD", Data = new List<BalanceData> { new BalanceData { Amount = 2222.33, DateTime = DateTimeOffset.Now } }, BalanceType = "OPAV" },
        };

        foreach (var balance in balances)
        {
            await repository.AddBalanceAsync(balance, TenantId);
        }
    }

    private static async Task PopulateProducts(IDataRepository repository, Account checking, Account savings, Account credit)
    {
        await repository.UpdateProductsForAccountIdAsync(
            checking.AccountId,
            new Product[]
            {
                new Product { Scheme = "host", Value = "C01" },
                new Product { Scheme = "OFX", Value = "CHECKING" },
                new Product { Scheme = "product", Value = "Foo" },
            },
            TenantId);

        await repository.UpdateProductsForAccountIdAsync(
            savings.AccountId,
            new Product[]
            {
                new Product { Scheme = "host", Value = "S01" },
                new Product { Scheme = "OFX", Value = "SAVINGS" },
            },
            TenantId);

        await repository.UpdateProductsForAccountIdAsync(
            credit.AccountId,
            new Product[]
            {
                new Product { Scheme = "host", Value = "L01" },
                new Product { Scheme = "host", Value = "CREDITCARD" },
            },
            TenantId);
    }

    private static async Task PopulateTransactions(IDataRepository repository, Account checking)
    {
        var transactions = new Transaction[]
        {
            new Transaction
            {
                AccountId = checking.AccountId,
                Amount = new Amount { CurrencyCode = "USD", Value = 5.49 },
                Balance = new RunningBalance { Amount = new Amount { CurrencyCode = "USD", Value = 1234.56 }, CreditDebitIndicator = "credit" },
                CreditDebitIndicator = "debit",
                CustomerReferenceNumber = "1111",
                Description = "Burger King",
                EffectiveDateTime = DateTimeOffset.Now,
                PostedDateTime = DateTimeOffset.Now,
                Status = "posted",
                TransactionCode = new TransactionCode { Code = "RCHQ", Domain = "PMNT", SubCode = "CCHQ" },
            },
            new Transaction
            {
                AccountId = checking.AccountId,
                Amount = new Amount { CurrencyCode = "USD", Value = 1500.44 },
                Balance = new RunningBalance { Amount = new Amount { CurrencyCode = "USD", Value = 2375.00 }, CreditDebitIndicator = "credit" },
                CreditDebitIndicator = "credit",
                CustomerReferenceNumber = "1111",
                Description = "Burger King Salary",
                EffectiveDateTime = DateTimeOffset.Now.AddMinutes(1),
                PostedDateTime = DateTimeOffset.Now.AddMinutes(1),
                Status = "posted",
                TransactionCode = new TransactionCode { Code = "RCHQ", Domain = "PMNT", SubCode = "CCHQ" },
            },
        };

        foreach (var transaction in transactions)
        {
            await repository.AddTransactionAsync(transaction, TenantId);
        }
    }
}

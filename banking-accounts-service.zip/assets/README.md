# Assets

This folder contains auxiliary data that is helpful at runtime but isn't actually compiled. It's sort of like `lib` but not for compiled code.

The `trustStore` folder is an unzipped version of the Voltage trust store certificates that get copied into the service container. You can get the latest `trustStore.tar.gz` [from the Voltage team's SharePoint site.](https://fiservcorp.sharepoint.com/sites/voltage/SimpleAPI%20Information/Forms/AllItems.aspx?csf=1&web=1&e=aVBkKj%2F&FolderCTID=0x012000E6998DFDE175EF4C8319A5693820ED1E&viewid=6a210a10%2Daafe%2D4458%2Db07a%2De5ac050de0c6&id=%2Fsites%2Fvoltage%2FSimpleAPI%20Information%2FFiservProtector%2FConfiguration%20files)

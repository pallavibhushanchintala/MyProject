﻿<#
.SYNOPSIS
    Given the set of changes, ensures the required kubectl contexts are
    present so those changes can be executed.
.PARAMETER Kubectl
    The location of the kubectl CLI.
.PARAMETER UpdateGroups
    The set of updates from Get-ClusterChange that has all the changes that
    need to be executed.
#>
Function Confirm-RequiredContexts {
    Param(
        [string]
        $Kubectl,

        [Hashtable]
        $ChangeGroups
    )

    $allContexts = & "$Kubectl" config get-contexts -o name
    Write-Verbose "Kubectl contexts present:"
    $allContexts | ForEach-Object { Write-Verbose "- $_" }

    # Unwind the hashtable of grouped records so we can check for the required kubectl contexts.
    $allChanges = $ChangeGroups.Values | ForEach-Object { $_ }

    # We could just check for unique context presence, but we need all the
    # data from the changes so we can generate the az CLI for getting the
    # context (for help in the error message) and checking presence of
    # something in an array is pretty fast, so rather than complicating the
    # code by slimming things down to unique values, we just allow redundant
    # checks to happen.
    Write-Verbose "Kubectl contexts required:"
    $allChanges | Select-Object -ExpandProperty "KubeContext" -Unique | ForEach-Object { Write-Verbose "- $_" }
    $allChanges | ForEach-Object {
        $required = $_
        If ($allContexts -notcontains $required.KubeContext) {
            # The -admin suffix is AUTOMATICALLY added to the context, so the az CLI needs to specify WITHOUT the -admin suffix.
            # https://github.com/Azure/azure-cli/blob/579b75d721d9781fdd183484d84800b90d687320/src/azure-cli/azure/cli/command_modules/acs/custom.py#L2263
            $trimmedContext = $required.KubeContext
            If ($trimmedContext.EndsWith("-admin")) {
                $trimmedContext = $trimmedContext.Substring(0, $trimmedContext.Length - 6)
            }
            throw "Missing kubectl context '$($required.KubeContext)'. Make sure you have a kubectl context for all clusters before running the upgrade. az CLI appends '-admin' automatically on admin context names. RUN: az aks get-credentials --subscription `"$($required.Subscription)`" -g `"$($required.ResourceGroup)`" -n `"$($required.ClusterName)`" --context `"$trimmedContext`" --admin --overwrite-existing"
        }
    }
}

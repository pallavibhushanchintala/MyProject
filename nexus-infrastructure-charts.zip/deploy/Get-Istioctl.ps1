﻿<#
.SYNOPSIS
    Gets a specific version of istioctl.
.DESCRIPTION
    The istioctl command is fairly version-specific when it comes to deploying Istio. It's usually best to use the
    version of istioctl that matches the version being deployed. This function will try to find the version
    of istioctl on the current system if it exists. If it doesn't, it'll be downloaded to a temporary location.
.PARAMETER Version
    The version of istioctl to download.
#>
Function Get-Istioctl {
    [CmdletBinding(SupportsShouldProcess = $True)]
    [OutputType([string])]
    Param(
        [Parameter(Mandatory = $True, ParameterSetName = "VersionSpecified")]
        [string]
        [ValidateNotNullOrEmpty()]
        $Version,

        [Parameter(ParameterSetName = "Latest")]
        [switch]
        $Latest
    )

    # Latest version has to be grabbed from the list of releases.
    If ($Latest) {
        $Version = Invoke-RestMethod https://api.github.com/repos/istio/istio/releases |
        ForEach-Object { $_.tag_name } |
        Where-Object { $_ -match "^\d+\.\d+\.\d+$" } |
        ForEach-Object { New-Object -TypeName 'System.Version' -ArgumentList $_ } |
        Sort-Object -Descending |
        ForEach-Object { $_.ToString() } |
        Select-Object -First 1
    }

    # First try a local version of istioctl.
    If ($null -ne (Get-Command "istioctl" -ErrorAction Ignore)) {
        Write-Verbose "Found installed version of istioctl. Checking version."
        $installed = ((& istioctl version -o json --remote=false 2> $null) | ConvertFrom-Json).clientVersion.version
        If ($Version -eq $installed) {
            Write-Verbose "Installed version is $installed. Using existing installed istioctl."
            return "istioctl"
        }

        Write-Verbose "Installed istioctl is $installed. Need $Version. Skipping installed version."
    }

    # Installed version is the wrong version. Download the right version.
    $TempFolder = Join-Path -Path ([System.IO.Path]::GetTempPath()) -ChildPath "istioctl-$Version"

    If ($IsLinux) {
        $Filename = "istioctl-$Version-linux-amd64.tar.gz"
        $ExeFile = Join-Path $TempFolder -ChildPath "istioctl"
    }
    ElseIf ($IsMacOS) {
        $Filename = "istioctl-$Version-osx.tar.gz"
        $ExeFile = Join-Path $TempFolder -ChildPath "istioctl"
    }
    ElseIf ($IsWindows) {
        $Filename = "istioctl-$Version-win.zip"
        $SubFolder = Join-Path $TempFolder -ChildPath "istioctl-$Version-win"
        $ExeFile = Join-Path $SubFolder -ChildPath "istioctl.exe"
    }
    Else {
        Throw "Unable to determine OS for downloading istioctl."
    }

    If (Test-Path $ExeFile) {
        Write-Verbose "Skipping re-download of istioctl. Using $ExeFile"
        return $ExeFile
    }

    $DownloadUrl = "https://github.com/istio/istio/releases/download/$Version/$Filename"
    $ZipFile = Join-Path -Path $TempFolder -ChildPath $Filename
    Write-Verbose "Downloading istioctl from $DownloadUrl into $TempFolder"
    If ($PSCmdlet.ShouldProcess($TempFolder, "Create")) {
        If (Test-Path $TempFolder) {
            # In the event this ran before and failed or something got messed up
            # we'll nuke the folder and re-download rather than trying to recover.
            Write-Verbose "Cleaning up temp folder from previous execution."
            Remove-Item $TempFolder -Force -Recurse
        }

        New-Item $TempFolder -ItemType Directory -Force | Out-Null
    }

    If ($PSCmdlet.ShouldProcess($DownloadUrl, "Download")) {
        Invoke-WebRequest -Uri $DownloadUrl -Method Get -OutFile $ZipFile
    }

    If ($PSCmdlet.ShouldProcess($ZipFile, "Expand archive")) {
        Push-Location $TempFolder
        If ($IsLinux -Or $IsMacOS) {
            Write-Verbose "Expanding $ZipFile using tar -xzf."
            &tar -xzf "$ZipFile"
            chmod +x $ExeFile
        }
        ElseIf ($IsWindows) {
            Write-Verbose "Expanding $ZipFile using Expand-Archive."
            Expand-Archive -Path "$ZipFile"
        }

        Pop-Location
    }

    If ($PSCmdlet.ShouldProcess($ZipFile, "Remove")) {
        Remove-Item $ZipFile
    }

    return $ExeFile
}

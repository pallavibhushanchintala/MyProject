﻿<#
.SYNOPSIS
    Uses Git to collect/summarize the set of changes between a given commit
    and the master branch. Groups them into a hashtable based on the type of
    change detected.
.PARAMETER Git
    The location of the Git CLI.
.PARAMETER TargetCommit
    The target commit hash against which master should be compared for
    detecting changes.
.PARAMETER FullRefresh
    Force a full update of Istio and Helm in all clusters regardless of whether
    a change is detected. Useful if someone has been manually modifying things
    in a cluster and you want to force a deploy of the existing setup.
#>
Function Get-ClusterChange {
    [OutputType([Hashtable])]
    Param(
        [string]
        $Git,

        [string]
        $TargetCommit,

        [bool]
        $FullRefresh
    )

    $basePath = [System.IO.Path]::GetDirectoryName($PSCmdlet.MyInvocation.MyCommand.Source)
    If ($FullRefresh) {
        Write-Verbose "Executing a full refresh. All files will be considered changed."
        $files = Get-ChildItem $basePath -Recurse | Select-Object -ExpandProperty FullName | ForEach-Object { [System.IO.Path]::GetRelativePath($basePath, $_) }
    }
    Else {
        # rev-parse will convert a branch name to a hash. If it's already a
        # hash, it's left alone.
        $resolvedCommit = & "$Git" rev-parse $TargetCommit
        Write-Verbose "Commit $resolvedCommit will be used as the destination for change detection."
        $files = & "$Git" diff --name-only master..$resolvedCommit --
    }

    $pathSeparator = [System.IO.Path]::DirectorySeparatorChar

    # Assume a path convention:
    # subscription/resource-group/cluster-name/file-name
    # like:
    # 35abf82e-a23b-49c4-8bae-88baead6f7d3/nexus-westus2-infra/digital-nexus/cluster.toml
    # Anything not matching doesn't require a deployment.
    $updates = $files |
    Where-Object { $_ -match "^(?<subscription>[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\$pathSeparator(?<resource_group>[^\$pathSeparator]+)\$pathSeparator(?<cluster_name>[^\$pathSeparator]+)\$pathSeparator(?<file_name>.+)" } |
    ForEach-Object {
        # We can't do anything if the files don't exist anymore. This is usually
        # when a whole cluster gets renamed or deleted anyway, so there'd be no
        # action to take.
        $matched = $_
        $folder = [System.IO.Path]::GetDirectoryName((Join-Path $basePath $matched))
        If (Test-Path $folder) {
            Write-Verbose "Change detected: $matched"
            $data = [ClusterChange]::new()
            $data.Subscription = $Matches["subscription"]
            $data.ResourceGroup = $Matches["resource_group"]
            $data.ClusterName = $Matches["cluster_name"]
            $data.BasePath = $folder
            $data.Update = "Helm"
            $fileName = $Matches["file_name"]

            # Updates should run as cluster admin. Using az aks get-credentials
            # --admin will automatically and forcibly add "-admin" as a suffix to
            # the context name.
            # https://github.com/Azure/azure-cli/blob/579b75d721d9781fdd183484d84800b90d687320/src/azure-cli/azure/cli/command_modules/acs/custom.py#L2263
            $data.KubeContext = "$($data.Subscription).$($data.ResourceGroup).$($data.ClusterName)-admin"

            # If it wasn't specifically the Istio files that changed, then
            # assume the change to execute is Helmsman. Only istio.json and
            # istio-1.2.3.yaml style files are considered Istio changes.
            If ($fileName -eq "istio.json" -or $fileName -match "^istio-[0-9\.]+\.yaml$") {
                $data.Update = "Istio"
            }

            $data
        }

    } |
    # Group by every property so we can use grouping to detect the unique set of
    # changes per cluster.
    Group-Object 'Subscription', 'ResourceGroup', 'ClusterName', 'Update' |
    ForEach-Object {
        $_.Group | Select-Object -First 1
    } |
    Group-Object 'Update' -AsHashTable

    # This will be a hashtable of grouped records where the key is the type of update.
    # @{
    #    "helm" = @(
    #      @{
    #         "Subscription"  = "sub"
    #         "ResourceGroup" = "rg"
    #         "ClusterName"   = "aks"
    #         "KubeContext"   = "sub.rg.aks"
    #         "Update"        = "Helm"
    #       },
    #       ...
    #    ),
    #    "istio" = @( ... )
    # }
    $updates
}

﻿<#
.SYNOPSIS
    Inspects a given cluster change definition and executes the deployment of
    Istio based on the desired state.
.PARAMETER ClusterChange
    The cluster change definition with the location where Istio should be
    updated.
.PARAMETER Kubectl
    The location of the kubectl CLI.
.PARAMETER DryRun
    Flag indicating if this is a dry run. WhatIf carries through from the
    caller, but there may or may not be a dry run with a WhatIf.
#>
Function Deploy-Istio {
    [CmdletBinding(SupportsShouldProcess = $True, ConfirmImpact = "High")]
    Param(
        [Parameter(Mandatory = $True)]
        [ClusterChange]
        $ClusterChange,

        [Parameter(Mandatory = $True)]
        [string]
        $Kubectl,

        [Parameter()]
        [Switch]
        $DryRun
    )
    Begin {
        # Require a minimum of 1.7.0 because istioctl changed at that point, plus that's pretty old.
        $minAllowedIstioVersion = New-Object -TypeName 'System.Version' -ArgumentList "1.7.0"

        Function Get-ActualIstioVersion {
            [OutputType([System.Version[]])]
            Param(
                [ClusterChange]
                $ClusterChange
            )
            # Whether it's the real thing or a WhatIf without a dry run, we
            # ALWAYS query the cluster to see what the installed Istio
            # version(s) are. We can't even give an accurate WhatIf without dry
            # run if we don't have SOMETHING to go on here. We'll use the latest
            # istioctl for query.
            $istioctl = Get-Istioctl -Latest -WhatIf:$False

            Write-Verbose "Getting Istio version data from cluster."
            $istioVersionInfo = &"$istioctl" version -o json --context $ClusterChange.KubeContext | ConvertFrom-Json

            # Checks if the result contains a 'meshVersion' property. If not, it means the cluster doesn't have any Istio installation.
            If ($null -eq $istioVersionInfo.meshVersion) {
                Write-Verbose "No Istio version found. This is a first install."
                return @()
            }

            $allActualVersions = $istioVersionInfo.meshVersion | Where-Object { $_.Component -eq "istiod" } | ForEach-Object {
                New-Object -TypeName 'System.Version' -ArgumentList $_.Info.version
            } | Sort-Object | Select-Object -Unique

            Write-Verbose "Cluster $ClusterChange installed Istio versions:"
            $allActualVersions | ForEach-Object { Write-Verbose "- $_" }
            $allActualVersions
        }

        Function Get-DesiredDefaultIstioVersion {
            [OutputType([System.Version])]
            Param(
                [ClusterChange]
                $ClusterChange,

                [System.Version[]]
                $AllDesiredVersions
            )
            # Get the default version that should be used - this is helpful in
            # canary.
            $istioJsonPath = Join-Path $ClusterChange.BasePath "istio.json"
            If (Test-Path $istioJsonPath) {
                $istioMetadata = Get-Content (Join-Path $ClusterChange.BasePath "istio.json") | ConvertFrom-Json -Depth 100 -NoEnumerate
                $defaultVersion = New-Object -TypeName 'System.Version' -ArgumentList $istioMetadata.default
                Write-Verbose "Desired default $ClusterChange Istio version: $defaultVersion"
                If ($AllDesiredVersions -notcontains $defaultVersion) {
                    throw "Cluster $ClusterChange has Istio version $defaultVersion specified as desired default but that version has no manifest (no `istio-$defaultVersion.yaml` found). You can't specify a default version that has no manifest."
                }
            }
            If (-not $defaultVersion) {
                Write-Verbose "No default Istio version is specified for $ClusterChange."
            }
            $defaultVersion
        }

        Function Get-DesiredIstioVersion {
            [OutputType([System.Version[]])]
            Param(
                [ClusterChange]
                $ClusterChange
            )
            # Locate required versions. Sort them oldest to newest - that's the
            # order we'll install.
            $allDesiredVersions = Get-ChildItem $ClusterChange.BasePath -Filter "istio-*.yaml" | Select-Object -ExpandProperty "Name" | ForEach-Object {
                If ($_ -match "istio-(?<version>[0-9\.]+)\.yaml") {
                    New-Object -TypeName 'System.Version' -ArgumentList $Matches["version"]
                }
            } | Sort-Object

            Write-Verbose "Cluster $ClusterChange Istio versions to install:"
            $allDesiredVersions | ForEach-Object { Write-Verbose "- $_" }
            $allDesiredVersions
        }

        Function New-Revision() {
            [CmdletBinding(SupportsShouldProcess = $False)]
            Param(
                [Parameter(Mandatory = $True)]
                [System.Version]
                [ValidateNotNullOrEmpty()]
                $Version
            )

            # Revision tags in Istio can't have dashes. Community standard is
            # the format v1-2-3.
            return "v" + ($Version.ToString() -replace '\.', '-')
        }
    }
    Process {
        # This [Array] / @() trick when calling the method forces the result to
        # be an array even if it's a single item. We need this so we can use
        # .Contains and array functions on it.
        [Array]$allDesiredVersions = @(Get-DesiredIstioVersion $ClusterChange)

        # Check minimum version against desired state.
        $versionTooSmall = $allDesiredVersions | Where-Object { $_ -lt $minAllowedIstioVersion } | Select-Object -First 1
        If ($versionTooSmall) {
            throw "Cluster $ClusterChange has Istio version $versionTooSmall set to install. This deployment only supports version $minAllowedIstioVersion or higher."
        }

        # Check for valid upgrade/canary version ranges.
        If ($allDesiredVersions.Length -gt 2) {
            # We don't allow more than two versions in a cluster. It's not clear
            # whether Istio even supports this, but since we only need canary
            # we'll protect folks from doing bad things.
            throw "Cluster $ClusterChange has $($allDesiredVersions.Length) Istio versions configured for installation. You may have a maximum of two - one default, one canary."
        }
        ElseIf ($allDesiredVersions.Length -eq 2) {
            # Ensure the two Istio versions are within two minor revisions.
            $v1 = $allDesiredVersions[0]
            $v2 = $allDesiredVersions[1]
            $minorSpread = [System.Math]::Abs($v1.Minor - $v2.Minor)
            If ($v1.Major -ne $v2.Major -or $minorSpread -gt 2) {
                throw "Cluster $ClusterChange has Istio versions $v1 and $v2 configured. Istio canary only supports a difference of up to two minor revisions. See https://istio.io/latest/docs/setup/upgrade/canary/#before-you-upgrade for more information."
            }
        }

        $defaultDesiredVersion = Get-DesiredDefaultIstioVersion $ClusterChange $allDesiredVersions
        [Array]$allActualVersions = @(Get-ActualIstioVersion $ClusterChange)

        # Check minimum version against actual state.
        $versionTooSmall = $allActualVersions | Where-Object { $_ -lt $minAllowedIstioVersion } | Select-Object -First 1
        If ($versionTooSmall) {
            throw "Cluster $ClusterChange has Istio version $versionTooSmall already installed. This deployment only supports version $minAllowedIstioVersion or higher. Upgrade the cluster manually so the installed version is greater than $minAllowedIstioVersion."
        }

        # Install/update all the versions required.
        $allDesiredVersions | ForEach-Object {
            $version = $_
            $manifest = Join-Path $ClusterChange.BasePath "istio-$version.yaml"
            $tag = New-Revision $version
            $istioctl = Get-Istioctl -Version $version -WhatIf:($WhatIfPreference -and -not $DryRun)

            # Run the precheck for install/upgrade of the version. Doesn't
            # matter if it's already installed or not, this is a good safety
            # check.
            If ($PSCmdlet.ShouldProcess("$ClusterChange", "Analyze Istio $version cluster readiness") -or ($WhatIfPreference -and $DryRun)) {
                &"$istioctl" x precheck --context "$($ClusterChange.KubeContext)"
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE during cluster pre-check for Istio $version in $ClusterChange."
                }
            }

            # The version is already installed, so if we're "actually doing the
            # upgrade" or otherwise not skipping the dry run, do the analysis of
            # the changes. If you're doing a canary upgrade (adding a second
            # version of Istio into the cluster) you may see a warning about
            # "you're upgrading from X to Y, be sure to analyze the manifest for
            # breaking changes" and that can be scary. We're NOT UPGRADING IN
            # PLACE so we don't need to analyze the manifest for that sort of
            # breaking change.
            If ($allActualVersions.Contains($version) -and
                ($PSCmdlet.ShouldProcess("$ClusterChange", "Analyze Istio $version manifest") -or ($WhatIfPreference -and $DryRun))
            ) {
                &"$istioctl" analyze $manifest --context "$($ClusterChange.KubeContext)"
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE during manifest analysis for Istio $version in $ClusterChange`: $manifest"
                }
            }
            Else {
                Write-Verbose "Skipping manifest analysis for Istio $version in $ClusterChange - version not already installed, so there's nothing to compare against."
            }

            # Do the install or update to Istio - everything checks out.
            If ($PSCmdlet.ShouldProcess("$ClusterChange", "Install/update Istio $version")) {
                # `--verify` does not respect `--readiness-timeout`. In fact,
                # `--readiness-timeout` doesn't seem to do much at all.
                # https://github.com/istio/istio/issues/29413
                #
                # To more reliably verify, we'll separately await the rollout
                # status for each deployment and then verify after everything is
                # up. If it doesn't all come up, verify obviously won't be
                # successful, either.
                &"$istioctl" manifest install --context "$($ClusterChange.KubeContext)" -f $manifest --set revision=$tag -y --readiness-timeout 10m0s
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE installing Istio $version into $ClusterChange."
                }

                # Select by tag to ensure we don't include _other_ Istio deployments in this check.
                $deployments = & "$Kubectl" get deploy -n istio-system -o name -l="istio.io/rev==$tag" --context "$($ClusterChange.KubeContext)"
                $deployments | ForEach-Object {
                    # Wait for each deployment to succeed. istiod takes the longest, sometimes several minutes.
                    $deployment = $_
                    Write-Verbose "Checking deployment $deployment..."
                    & "$Kubectl" rollout status $deployment -n istio-system --context "$($ClusterChange.KubeContext)" --watch=true --timeout=10m
                    If ($LASTEXITCODE -ne 0) {
                        throw "Error $LASTEXITCODE checking deployment $deployment in Istio $version for $ClusterChange."
                    }
                }

                &"$istioctl" verify-install --context "$($ClusterChange.KubeContext)" --revision $tag
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE validating Istio $version in $ClusterChange."
                }
            }
            ElseIf ($WhatIfPreference -and $DryRun) {
                &"$istioctl" manifest install --context "$($ClusterChange.KubeContext)" -f $manifest --set revision=$tag --dry-run -y
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE during dry run installing Istio $version into $ClusterChange."
                }
            }
        }

        # If there's a default version specified, update the default tag. If
        # not, don't mess with it.
        If ($defaultDesiredVersion) {
            $istioctl = Get-Istioctl -Version $defaultDesiredVersion -WhatIf:($WhatIfPreference -and -not $DryRun)
            $tag = New-Revision $defaultDesiredVersion
            If ($PSCmdlet.ShouldProcess("$ClusterChange", "Set default Istio version to $defaultDesiredVersion")) {
                &"$istioctl" tag set default --revision $tag --context $ClusterChange.KubeContext --overwrite -y
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE setting $ClusterChange default Istio tag to $tag."
                }
            }
            ElseIf ($WhatIfPreference -and $DryRun) {
                # There's no dry run for tag setting, so we'll just write out
                # the command line that would be executed.
                Write-Host "[DRY RUN] &`"$istioctl`" tag set default --revision $tag --context $($ClusterChange.KubeContext) --overwrite -y"
            }
        }

        # Remove any versions that are deployed but don't have a manifest. This may mean removing all the versions of Istio.
        $allActualVersions | Where-Object { -not ($allDesiredVersions.Contains($_)) } | ForEach-Object {
            $version = $_
            $versionToRemove = New-Revision $version
            $istioctl = Get-Istioctl -Version $version -WhatIf:($WhatIfPreference -and -not $DryRun)
            If ($PSCmdlet.ShouldProcess("$ClusterChange", "Remove Istio version $versionToRemove")) {
                &"$istioctl" x uninstall --revision $versionToRemove --context $ClusterChange.KubeContext -y
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE removing Istio $versionToRemove from $ClusterChange."
                }
            }
            ElseIf ($WhatIfPreference -and $DryRun) {
                # Dry run on install actually checks things and tries to confirm
                # real deletion but won't DO IT. It looks scarier than it is.
                &"$istioctl" x uninstall --revision $versionToRemove --context $($ClusterChange.KubeContext) --dry-run -y
                If ($LASTEXITCODE -ne 0) {
                    throw "Error $LASTEXITCODE during dry run removing Istio $versionToRemove from $ClusterChange."
                }
            }
        }
    }
}

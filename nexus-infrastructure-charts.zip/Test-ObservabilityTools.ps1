﻿<#
.SYNOPSIS
    Tests the monitoring/observability tools set up in a cluster.
.DESCRIPTION
    Runs some basic analysis on the deployed observability tools for the current
    Kubernetes (kubectl) context. Makes the assumption things are deployed on
    standard ports with standardized names.
#>
[CmdletBinding(SupportsShouldProcess = $False, PositionalBinding = $False)]
Param(
)


#--- CONFIGURATION ---
# This is the stuff you can change to update what gets checked.

# These glyphs prefix individual message types.
$Glyphs = @{
    "Success" = [char]0x221A;
    "Warning" = "!";
    "Error"   = [char]0x00D8;
}

# Number of spaces per "indent level."
$IndentSize = 2

# The local port we'll use during kubectl port-forward operations.
$PortForwardLocal = 8899

# A tool is a set of information about how to check for it, whether it's
# required/optional, how to get it, and what platform(s) it's on.
$ToolsToCheck = @(
    @{
        "Name"         = "Kubectl";
        "Required"     = $true;
        "Command"      = "kubectl";
        "Location"     = @{
            "Windows" = "choco install kubernetes-cli";
            "MacOS"   = "brew install kubernetes-cli";
            "Linux"   = "https://git-scm.com/download/linux";
        };
        "PlatformTest" = { $true };
        "Reason"       = "kubectl is the command line utility for working in Kubernetes. This script uses kubectl for querying the cluster.";
    }
)

# List of deployments with selectors to check - these should all be 100% ready.
$DaemonsetsToCheck = @(
    @{
        "Name"      = "Fluentd";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app.kubernetes.io/name" = "fluentd-elasticsearch";
        };
    },
    @{
        "Name"      = "Jaeger Agent";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app.kubernetes.io/component" = "agent";
            "app.kubernetes.io/name"      = "jaeger-agent";
        };
    },
    @{
        "Name"      = "Node Exporter";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app"       = "prometheus";
            "component" = "node-exporter";
        };
    },
    @{
        "Name"      = "Kured";
        "Namespace" = "kured";
        "Selector"  = @{
            "app" = "kured";
        };
    }
)

# List of deployments with selectors to check - these should all be 100% ready.
$DeploymentsToCheck = @(
    @{
        "Name"      = "Jaeger Collector";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app.kubernetes.io/component" = "collector";
            "app.kubernetes.io/name"      = "jaeger-collector";
        };
    },
    @{
        "Name"      = "Jaeger Operator";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app.kubernetes.io/name" = "jaeger-operator";
        };
    },
    @{
        "Name"      = "Jaeger Query";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app.kubernetes.io/component" = "query";
            "app.kubernetes.io/name"      = "jaeger-query";
        };
    },
    @{
        "Name"      = "Kibana";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app" = "kibana";
        };
    },
    @{
        "Name"      = "Kubernetes State Metrics";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app.kubernetes.io/name" = "kube-state-metrics";
        };
    },
    @{
        "Name"      = "Prometheus";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app"       = "prometheus";
            "component" = "server";
        }
    },
    @{
        "Name"      = "Prometheus Push Gateway";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app"       = "prometheus";
            "component" = "pushgateway";
        };
    },
    @{
        "Name"      = "Kiali Operator";
        "Namespace" = "kiali-operator";
        "Selector"  = @{
            "app.kubernetes.io/name" = "kiali-operator";
        };
    },
    @{
        "Name"      = "Kiali";
        "Namespace" = "istio-system";
        "Selector"  = @{
            "app.kubernetes.io/name" = "kiali";
        };
    }
)

# List of stateful sets with selectors to check - these should all be 100% ready.
$StatefulSetsToCheck = @(
    @{
        "Name"      = "ElasticSearch Client";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app"       = "elasticsearch-client";
        };
    },
    @{
        "Name"      = "ElasticSearch Data";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app" = "elasticsearch-data";
        };
    },
    @{
        "Name"      = "ElasticSearch Master";
        "Namespace" = "monitoring";
        "Selector"  = @{
            "app" = "elasticsearch-master";
        };
    }
)

# Service definitions to run through kubectl port-forward for checking.
$ServicesToCheck = @(
    @{
        "Name"       = "ElasticSearch";
        "Namespace"  = "monitoring";
        "Selector"   = @{
            "app"       = "elasticsearch-client";
        };
        "TestScript" = { Test-ElasticSearch }
    },
    @{
        "Name"       = "Prometheus";
        "Namespace"  = "monitoring";
        "Selector"   = @{
            "app"       = "prometheus";
            "component" = "server";

        };
        "TestScript" = { Test-Prometheus }
    },
    @{
        "Name"       = "Kibana";
        "Namespace"  = "monitoring";
        "Selector"   = @{
            "app" = "kibana";
        };
        "TestScript" = { Test-Kibana }
    },
    @{
        "Name"       = "Kiali";
        "Namespace"  = "istio-system";
        "Selector"   = @{
            "app.kubernetes.io/name" = "kiali";
        };
        "TestScript" = { Test-Kiali }
    }
)

#--- FUNCTIONS ---
function Get-Indent {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false, Position = 0)]
        [int] $IndentLevel = 0
    )

    New-Object -TypeName "System.String" -ArgumentList ' ', ($IndentLevel * $IndentSize)
}

function Get-WrappedText {
    [CmdletBinding()]
    param (
        [String] $Text,
        [String] $Indent
    )

    $maxLineLength = $Host.UI.RawUI.WindowSize.Width - $Indent.Length
    $wrapped = [System.Collections.ArrayList]@()
    $wrapChars = " ,.?!:;-`t".ToCharArray()

    $lines = $Text.Replace("`r`n", "`n").Split("`n")
    ForEach ($line in $lines) {
        $lastWrap = 0
        $currentIndex = 0
        Do {
            If ($lastWrap + $maxLineLength -gt $line.Length) {
                $currentIndex = $line.Length
            }
            Else {
                $currentIndex = $line.LastIndexOfAny($wrapChars, [Math]::Min($line.Length - 1, $lastWrap + $maxLineLength)) + 1;
            }
            if ($currentIndex -le $lastWrap) {
                $currentIndex = [Math]::Min($lastWrap + $maxLineLength, $line.Length );
            }
            $wrapped.Add($line.Substring($lastWrap, $currentIndex - $lastWrap).Trim()) | Out-Null
            $lastWrap = $currentIndex;
        } While ( $currentIndex -lt $line.Length );
    }

    For ($i = 0; $i -lt $wrapped.Count; $i++) {
        $wrapped[$i] = "$Indent$($wrapped[$i])"
    }

    $wrapped -join "`n"
}

function Start-PortForward {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $ServiceName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Namespace,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $ServicePort
    )

    $processInfo = New-Object System.Diagnostics.ProcessStartInfo -Args kubectl
    $processInfo.ArgumentList.Add("port-forward")
    $processInfo.ArgumentList.Add("svc/$ServiceName")
    $processInfo.ArgumentList.Add("-n")
    $processInfo.ArgumentList.Add($Namespace)
    $processInfo.ArgumentList.Add("$PortForwardLocal`:$ServicePort")
    $processInfo.RedirectStandardOutput = $true

    $process = [System.Diagnostics.Process]::Start($processInfo)

    # It takes about three seconds for kubectl to get things working.
    Start-Sleep -Seconds 3
    return $process
}

function Test-Daemonsets {
    ForEach ($daemonset in $DaemonsetsToCheck) {
        $daemonsetName = $daemonset.Name
        $namespace = $daemonset.Namespace
        $selector = [String]::Join(",", ($daemonset.Selector.Keys | ForEach-Object { "$_=$($daemonset.Selector.$_)" }))
        $foundItems = kubectl get daemonset -n $namespace -l $selector -o json
        If ($LASTEXITCODE -ne 0) {
            Write-Message "Error" "Error retrieving deployment $deploymentName."
            Write-Message "Info" "Kubectl encountered a problem getting the deployment in the $namespace namespace." 2
            continue;
        }

        $foundItems = ($foundItems | ConvertFrom-Json -Depth 100).items
        If ($foundItems.Count -eq 0) {
            Write-Message "Error" "Failed to get daemonset $daemonsetName."
            Write-Message "Info" "Kubectl couldn't find the daemonset in the cluster in the $namespace namespace." 2
            continue;
        }

        ForEach ($foundItem in $foundItems) {
            $name = $foundItem.metadata.name
            $ready = $foundItem.status.numberReady
            $total = $foundItem.status.desiredNumberScheduled

            If ($ready -eq $total) {
                Write-Message "Success" "$daemonsetName ($name) ready ($ready/$total)."

            }
            Else {
                Write-Message "Error" "$daemonsetName ($name) not ready ($ready/$total)."
                Write-Message "Info" "The $name daemonset of $daemonsetName isn't reading as 100% ready. Check `kubectl describe daemonset/$name -n $namespace` to see what's going on." 2
            }
        }
    }
}

function Test-Deployments {
    ForEach ($deployment in $DeploymentsToCheck) {
        $deploymentName = $deployment.Name
        $namespace = $deployment.Namespace
        $selector = [String]::Join(",", ($deployment.Selector.Keys | ForEach-Object { "$_=$($deployment.Selector.$_)" }))
        $foundItems = kubectl get deployment -n $namespace -l $selector -o json
        If ($LASTEXITCODE -ne 0) {
            Write-Message "Error" "Error retrieving deployment $deploymentName."
            Write-Message "Info" "Kubectl encountered a problem getting the deployment in the $namespace namespace." 2
            continue;
        }

        $foundItems = ($foundItems | ConvertFrom-Json -Depth 100).items
        If ($foundItems.Count -eq 0) {
            Write-Message "Error" "Failed to get deployment $deploymentName."
            Write-Message "Info" "Kubectl couldn't find the deployment in the cluster in the $namespace namespace." 2
            continue;
        }

        ForEach ($foundItem in $foundItems) {
            $name = $foundItem.metadata.name
            $ready = $foundItem.status.readyReplicas
            $total = $foundItem.status.replicas

            If ($ready -eq $total) {
                Write-Message "Success" "$deploymentName ($name) ready ($ready/$total)."

            }
            Else {
                Write-Message "Error" "$deploymentName ($name) not ready ($ready/$total)."
                Write-Message "Info" "The $name deployment of $deploymentName isn't reading as 100% ready. Check `kubectl describe deploy/$name -n $namespace` to see what's going on." 2
            }
        }
    }
}

function Test-ElasticSearch {
    # TLS, when enabled, uses certificates only trusted inside the cluster (e.g., Istio).
    # Force anonymous access or you'll get an error when it tries to negotiate for a client cert.
    $health = Invoke-RestMethod -Method Get -Uri http://localhost:$PortForwardLocal/_cluster/health -SkipCertificateCheck -Authentication None
    Switch ($health.status) {
        "green" {
            Write-Message "Success" "ElasticSearch ($name) healthy."
            Break;
        }
        "yellow" {
            Write-Message "Warning" "ElasticSearch ($name) degraded."
            Write-Message "Info" ($health | ConvertTo-Json) 2
            Break;
        }
        Default {
            Write-Message "Error" "ElasticSearch ($name) unhealthy."
            Write-Message "Info" ($health | ConvertTo-Json) 2
            Break;
        }
    }

    If ($health.unassigned_shards -gt 0) {
        Write-Message "Info" "There are $($health.unassigned_shards) unassigned shards. Troubleshooting info: https://www.datadoghq.com/blog/elasticsearch-unassigned-shards/" 2
    }
}

function Test-Kiali {
    $health = Invoke-RestMethod -Method Get -Uri http://localhost:$PortForwardLocal/api/status
    Switch ($health.status."Kiali state") {
        "running" {
            Write-Message "Success" "Kiali ($name) healthy."
            Break;
        }
        Default {
            Write-Message "Error" "Kiali ($name) unhealthy."
            Write-Message "Info" ($health | ConvertTo-Json) 2
            Break;
        }
    }
}

function Test-Kibana {
    $health = Invoke-RestMethod -Method Get -Uri http://localhost:$PortForwardLocal/api/status
    Switch ($health.status.overall.state) {
        "green" {
            Write-Message "Success" "Kibana ($name) healthy."
            Break;
        }
        "yellow" {
            Write-Message "Warning" "Kibana ($name) degraded."
            Write-Message "Info" ($health | ConvertTo-Json) 2
            Break;
        }
        Default {
            Write-Message "Error" "Kibana ($name) unhealthy."
            Write-Message "Info" ($health | ConvertTo-Json) 2
            Break;
        }
    }
}

function Test-Prometheus {
    $targets = Invoke-RestMethod -Method Get -Uri http://localhost:$PortForwardLocal/api/v1/targets
    If ($targets.data.activeTargets.Count -eq 0) {
        Write-Message "Warning" "Prometheus ($name) has no targets."
        Write-Message "Info" "Prometheus doesn't appear to be scraping anything." 2
        return;
    }
    $totalTargets = $targets.data.activeTargets.Count
    $down = $targets.data.activeTargets | Where-Object { $_.health -ne "up" }
    If ($down.Count -eq 0) {
        Write-Message "Success" "Prometheus ($name) healthy - $totalTargets targets."
        return;
    }

    Write-Message "Warning" "Prometheus ($name) has ($($down.Count) / $totalTargets) unhealthy targets."
    $down | ForEach-Object {
        Write-Message "Info" "- $($_.labels.job) / $($_.labels.instance)" 2
    }
}

function Test-Services {
    ForEach ($service in $ServicesToCheck) {
        $serviceName = $service.Name
        $namespace = $service.Namespace
        $selector = [String]::Join(",", ($service.Selector.Keys | ForEach-Object { "$_=$($service.Selector.$_)" }))
        $foundItems = kubectl get service -n $namespace -l $selector -o json
        If ($LASTEXITCODE -ne 0) {
            Write-Message "Error" "Error retrieving $serviceName services."
            Write-Message "Info" "Kubectl encountered a problem getting the $serviceName service info." 2
            continue;
        }

        $foundItems = ($foundItems | ConvertFrom-Json -Depth 100).items
        If ($foundItems.Count -eq 0) {
            Write-Message "Error" "Failed to get $serviceName services."
            Write-Message "Info" "Kubectl couldn't find any $serviceName services in the $namespace namespace." 2
            continue;
        }
        ForEach ($foundItem in $foundItems) {
            $name = $foundItem.metadata.name
            $port = $foundItem.spec.ports[0].port
            $process = $null
            Try {
                $process = Start-PortForward -ServiceName $name -Namespace $namespace -ServicePort $port
                Invoke-Command -ScriptBlock $service.TestScript
            }
            Catch {
                Write-Message "Error" "Error while testing $serviceName service $name."
                Write-Message "Info" $_.ToString() 2
            }
            Finally {
                If ($null -ne $process) {
                    $process.Kill()
                    $process.Dispose()
                }
            }
        }
    }
}

function Test-StatefulSets {
    ForEach ($statefulset in $StatefulSetsToCheck) {
        $statefulsetName = $statefulset.Name
        $namespace = $statefulset.Namespace
        $selector = [String]::Join(",", ($statefulset.Selector.Keys | ForEach-Object { "$_=$($statefulset.Selector.$_)" }))
        $foundItems = kubectl get statefulset -n $namespace -l $selector -o json
        If ($LASTEXITCODE -ne 0) {
            Write-Message "Error" "Error retrieving statefulset $statefulsetName."
            Write-Message "Info" "Kubectl encountered a problem getting the statefulset in the $namespace namespace." 2
            continue;
        }

        $foundItems = ($foundItems | ConvertFrom-Json -Depth 100).items
        If ($foundItems.Count -eq 0) {
            Write-Message "Error" "Failed to get statefulset $statefulsetName."
            Write-Message "Info" "Kubectl couldn't find the statefulset in the cluster in the $namespace namespace." 2
            continue;
        }

        ForEach ($foundItem in $foundItems) {
            $name = $foundItem.metadata.name
            $ready = $foundItem.status.readyReplicas
            $total = $foundItem.status.replicas

            If ($ready -eq $total) {
                Write-Message "Success" "$statefulsetName ($name) ready ($ready/$total)."

            }
            Else {
                Write-Message "Error" "$statefulsetName ($name) not ready ($ready/$total)."
                Write-Message "Info" "The $name statefulset of $statefulsetName isn't reading as 100% ready. Check `kubectl describe statefulset/$name -n $namespace` to see what's going on." 2
            }
        }
    }
}

function Test-ToolInstall {
    ForEach ($tool in $ToolsToCheck) {
        If (-not (Invoke-Command -ScriptBlock $tool.PlatformTest)) {
            continue;
        }
        $found = $False
        If ($tool.Command.GetType().Name -ne "String") {
            If ($IsMacOS) {
                $found = Invoke-Command -ScriptBlock $tool.Command["MacOS"]
            }
            ElseIf ($IsLinux) {
                $found = Invoke-Command -ScriptBlock $tool.Command["Linux"]
            }
            Else {
                $found = Invoke-Command -ScriptBlock $tool.Command["Windows"]
            }
        }
        Else {
            $command = Get-Command $tool.Command -ErrorAction Ignore
            $found = $Null -ne $command
        }

        $location = $tool.Location
        If ($location.GetType().Name -ne "String") {
            If ($IsMacOS) {
                $location = $location["MacOS"]
            }
            ElseIf ($IsLinux) {
                $location = $location["Linux"]
            }
            Else {
                $location = $location["Windows"]
            }
        }
        If (-not $found) {
            $messageType = "Error"
            If (-not $tool.Required) {
                $messageType = "Warning"
            }
            Write-Message $messageType $tool.Name
            Write-Message "Info" "Get it: $($location)`n$($tool.Reason)" 2
        }
        ElseIf ($command.CommandType -eq 'Alias') {
            Write-Message "Warning" "$($tool.Name) - '$($command.Name)' is an alias for '$($command.ResolvedCommand)'. Consider installing the actual tool."
            Write-Message "Info" "Get it: $($location)`n$($tool.Reason)" 2
        }
        Else {
            Write-Message "Success" $tool.Name
        }
    }
}

function Write-Header {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [String] $Message
    )

    Write-Host -BackgroundColor "Gray" -ForegroundColor "Black" "*** $Message ***" -NoNewline
    Write-Host " "
}

function Write-Message {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [ValidateSet("Info", "Success", "Warning", "Error")]
        [String] $MessageType,
        [Parameter(Mandatory = $true, Position = 1)]
        [String] $Message,
        [Parameter(Mandatory = $false, Position = 2)]
        [int] $IndentLevel = 1
    )

    $color = switch ($MessageType) {
        "Success" { "Green" }
        "Warning" { "DarkYellow" }
        "Error" { "Red" }
        default { "Gray" }
    }
    $initialTab = Get-Indent $IndentLevel
    If ($Glyphs.ContainsKey($MessageType)) {
        $Message = "$($Glyphs[$MessageType]) $Message"
    }
    $wrapped = Get-WrappedText $Message $initialTab
    Write-Host -ForegroundColor $color "$wrapped"
}

function Write-ReportHeader {
    Write-Host -BackgroundColor "Gray" -ForegroundColor "Black" "Observability Tool Check " -NoNewline
    Write-Host " "
    Write-Host ""
    Write-Message "Info" "This script checks the current Kubernetes context for observability tool availability. It's not a 100% guarantee everything is perfect, but it should give you a good indication." 0
    Write-Message "Success" "Success messages show things that are set up."
    Write-Message "Error" "Errors show you things you're missing."
    Write-Message "Warning" "Warning items may not be showstoppers but it's worth checking out."
    Write-Host ""
}

#--- SCRIPT CHECKS ---

Write-ReportHeader
Write-Header "CLI Tools"
Test-ToolInstall
Write-Host ""

$CurrentContext = &kubectl config current-context
If ($LASTEXITCODE -ne 0) {
    Write-Message "Error" "Unable to retrieve current kubectl context. Verify you have a context set."
    Exit $LASTEXITCODE
}
Write-Header "Observability Check: $CurrentContext"
Write-Header "Kubernetes Objects"
Test-Deployments
Test-Daemonsets
Test-StatefulSets
Write-Host ""
Write-Header "Service Health Checks"
Write-Message "Info" "Checks will `kubectl port-forward` to access services in the cluster and verify health."
Test-Services

# Digital Nexus: Kubernetes Infrastructure for Ping cluster

Here you can find infrastructure information related to Ping cluster.

## Istio Upgrades

When upgrading Istio, there are a couple of health checks you can use to verify that Ping services are still working: [ping directory](https://pingdirectory2.nexus-westus2-ping.fiserv.io/available-state) and [ping federate](https://pingfederate-engine.nexus-westus2-ping.fiserv.io/pf/heartbeat.ping).

<#
.SYNOPSIS
    Creates an AKS context using the given parameters.
.PARAMETER SubscriptionId
    The Azure subscription to which the cluster belongs.
.PARAMETER ResourceGroup
    The Azure resource group to which the cluster belongs.
.PARAMETER ClusterName
    The name of the Azure Kubernetes cluster.
#>
Param(
    [Parameter(Mandatory = $True)]
    [String]
    $SubscriptionId,

    [Parameter(Mandatory = $True)]
    [String]
    $ResourceGroup,

    [Parameter(Mandatory = $True)]
    [String]
    $ClusterName
)

az aks get-credentials `
    --subscription "$SubscriptionId" `
    -g "$ResourceGroup" `
    -n "$ClusterName" `
    --context "$SubscriptionId.$ResourceGroup.$ClusterName" `
    --admin `
    --overwrite-existing

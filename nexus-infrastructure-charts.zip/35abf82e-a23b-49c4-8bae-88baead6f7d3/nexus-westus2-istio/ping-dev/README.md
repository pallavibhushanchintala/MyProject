# Digital Nexus: Kubernetes Infrastructure for the Istio cluster

Here you can find infrastructure information related to the Istio cluster.

This cluster is a temporary cluster used for testing Istio policies for restricting access
between a `directory-dmz` namespace and other namespaces while still allowing traffic
to the PingFederate Engine, secured by mTLS enforced by that service.

## Istio Upgrades

When upgrading Istio in this environment, there are a couple of health checks you can use to verify that Ping services are still working: [PingDirectory](https://pingdirectory2.nexus-westus2-istio.fiserv.io/available-state)
[PingFederate](https://pingfederate-engine.nexus-westus2-istio.fiserv.io/pf/heartbeat.ping).

# kured

[Home Page](https://github.com/weaveworks/kured)

The Kubernetes Reboot Daemon is a mechanism you can use to reboot the nodes in your Kubernetes cluster in a rolling fashion. It handles cordon, reboot, uncordon and can be set up to avoid rebooting during certain specified times.

This is particularly interesting in a hosted cluster like AKS because rebooting the nodes is how security patches get applied to the node OS.

The Helm chart for kured is [hosted in the git repo for kured](https://hub.helm.sh/charts/kured/kured).

```bash
helm repo add kured https://weaveworks.github.io/kured
helm install my-release kured/kured
```

## Prerequisites

- Prometheus

## Auto-Reboot on Update

By default [AKS nodes check for OS updates every evening](https://docs.microsoft.com/en-us/azure/aks/node-updates-kured). The way kured works, it detects when an update is applied and it places a file `/var/run/reboot-required` on the node. When this happens, the kured service takes over and performs the rolling reboot of the nodes so all the nodes get the updates.

## Manually Test a kured Reboot

Instructions here are based on [the official docs for SSH connections to a VMSS cluster](https://docs.microsoft.com/en-us/azure/aks/ssh).

First, you need an SSH key since you're going to SSH into a node on the cluster. If you don't have one, create one. You can do that with [`ssh-keygen`](https://www.ssh.com/ssh/keygen/), which may already be on your system if you're running Linux or Mac.

```powershell
ssh-keygen -t rsa
```

Next, set up your SSH key to allow you to connect to a node in the VM Scale Set.

```powershell
$cluster_resource_group = "nexus-westus2-dev"
$cluster_name = "digital-nexus"
$public_key_file = "~/.ssh/id_rsa.pub"
$public_key = Get-Content $public_key_file

# Get scale set info.
$node_resource_group = az aks show --resource-group $cluster_resource_group --name $cluster_name --query nodeResourceGroup -o tsv
$scale_set_name = az vmss list --resource-group $node_resource_group --query [0].name -o tsv

# Attach your SSH key to the scale set.
#
# Double escaping is correct here - the az command
# wants to see \" in the string you pass it; and PowerShell
# wants quote itself escaped as `" so to get it through
# PowerShell and the az command, it's \`"
az vmss extension set `
  --resource-group $node_resource_group `
  --vmss-name $scale_set_name `
  --name VMAccessForLinux `
  --publisher Microsoft.OSTCExtensions `
  --version 1.4 `
  --protected-settings "{\`"username\`":\`"azureuser\`", \`"ssh_key\`":\`"$public_key\`"}"

az vmss update-instances --instance-ids '*' `
    --resource-group $node_resource_group `
    --name $scale_set_name
```

List the nodes in your VMSS so you can get the `INTERNAL-IP` of one that you want to SSH into. You'll need this later.

```powershell
kubectl get nodes -o wide
```

Now you can start the SSH helper pod in the cluster. In this case, you start with just a base Debian image.

```powershell
kubectl run -it --rm aks-ssh --image=debian
```

Once that image fires up, you'll need to install the SSH client.

```sh
apt-get update && apt-get install openssh-client -y
```

Now you need to copy your SSH key into the container. **Open a new terminal window** on your host machine so you can copy it into your pod.

```powershell
$private_key_file = "~/.ssh/id_rsa"
$pod = kubectl get pod -l run=aks-ssh -o jsonpath='{.items[0].metadata.name}'
kubectl cp $private_key_file $pod`:/id_rsa
```

**Back in the SSH helper pod terminal** you need to change permissions on the file you just copied in so it's user read-only. You can then connect to the VMSS node from in that helper pod. You'll need the `INTERNAL-IP` of one of the nodes, which you got earlier.

```sh
# Set the key to user read-only.
chmod 0600 id_rsa

# SSH to the internal IP address of one of the nodes. The
# "azureuser" username is from that JSON blob earlier.
ssh -i id_rsa azureuser@10.240.0.4

# Look to see if there's already a reboot scheduled.
ls -la /var/run/reboot-required
```

If there's no reboot required, you can force one.

```sh
touch /var/run/reboot-required
```

Exit the SSH session, then exit the helper pod. When you exit the helper pod, it will disappear. **Your public SSH key is still authorized on the VMSS, though.**

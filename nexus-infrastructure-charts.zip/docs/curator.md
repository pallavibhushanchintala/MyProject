# Curator

[Home Page](https://github.com/elastic/curator)

Curator is a scheduled process that cleans up ElasticSearch data and maintains the database.

## Prerequisites

- ElasticSearch

## The Curator Scheduled Job

If you uninstall Curator it will leave the job behind. You need to manually delete it.

```powershell
kubectl -n monitoring delete job -l app=elasticsearch-curator,release=curator
```

If you want to manually call the job once you can do that.

```powershell
kubectl create job curator-run -n monitoring --from=cronjob/curator-elasticsearch-curator
kubectl get jobs -n monitoring
```

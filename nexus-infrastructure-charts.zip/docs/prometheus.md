# Prometheus

[Home Page](https://prometheus.io/)

Prometheus queries and stores metrics for the kubernetes cluster and apps configured to use it.

## Prerequisites

- Istio

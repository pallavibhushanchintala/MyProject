# Kubernetes Event-Driven Autoscaling (KEDA)

[Home Page](https://keda.sh/)
[GitHub](https://github.com/kedacore)

KEDA is a way to, basically, put serverless functions into Kubernetes. It allows for the definition of a scaled object (a "function") to be put into the cluster and when a given event is encountered, a new pod will be started to handle the event.

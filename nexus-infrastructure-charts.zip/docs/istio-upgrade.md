# Upgrade Istio

Istio provides [a canary upgrade method](https://istio.io/latest/docs/setup/upgrade/) recommended for live clusters which prevents traffic disruptions, allowing you to monitor the effect of the upgrade with a small percentage of the workloads before migrating all the traffic to the new version. This is the process we follow for Istio upgrades.

> :warning: **There are not canary deployments for the data plane, [only in-place upgrades](https://istio.io/latest/docs/setup/upgrade/canary/#data-plane).** This means that once you execute the installation a new version of the gateways will be deployed.

## Add the New Version

Create a feature branch for adding the manifest for the new Istio version, then create the Istio manifest. This should be placed in your cluster folder (see the [README](../README.md) for details on folder naming/structure). This version will be named in the format `istio-X.Y.Z.yaml`. For example, `istio-1.13.4.yaml` will install Istio 1.13.4.

Use the `Deploy-ClusterInfrastructure.ps1` script to do a dry run of the installation. This will run cluster checks and manifest analysis as needed to see if things should work.

```powershell
./Deploy-ClusterInfrastructure.ps1 -WhatIf
```

Create a pull request for your new manifest. Set the PR as auto-complete. After a dry-run and approval, it will deploy Istio for real into the cluster.

## Verify the New Version Deployment

The installation builds the revision based on the version of Istio. The format for the revision naming is `v{dash-delimited-version}`. For example, if you're deploying version `1.13.4` then the revision will be `v1-13-4`. The `.` characters are replaced by `-` since `.` is not a valid character in a revision name.

**Check that there are two installations of the Pilot.** The Pilot pod is the Istio control plane component running `istiod`. You'll see the Istio revision in the pod name. This example shows Istio 1.12.7 and 1.13.4 running side-by-side.

```text
PS> kubectl get pods -n istio-system -l app=istiod
NAME                                    READY   STATUS    RESTARTS   AGE
istiod-v1-12-7-786779888b-p9s5n         1/1     Running   0          114m
istiod-v1-13-4-6956db645c-vwhsk         1/1     Running   0          1m
```

**Check that there are two sidecar injector configurations** including the new revision. As with the control plane, you'll see the Istio revision in the name.

```text
PS> kubectl get mutatingwebhookconfigurations
NAME                            WEBHOOKS   AGE
istio-sidecar-injector-v1-12-7  1          114m
istio-sidecar-injector-v1-13-4  1          1m
```

**Look at the set of revisions and tags** which should show the list of everything installed.

```text
PS> istioctl x revision list
REVISION TAG      ISTIO-OPERATOR-CR                    PROFILE REQD-COMPONENTS
v1-12-7  default  istio-system/installed-state-v1-12-7 default base
                                                               istiod
                                                               ingress:istio-ingressgateway
v1-13-4  <no-tag> istio-system/installed-state-v1-13-4 default base
                                                               istiod
                                                               ingress:istio-ingressgateway
default  <no-tag> <no-iop>

PS> istioctl tag list
TAG     REVISION NAMESPACES
default v1-12-7
```

**Test the Istio sidecars with some select pods and services.** Installing the new revision doesn't have any impact on the existing Envoy sidecars. Select some low-risk/low-traffic namespaces to be updated to enable the injection of the new version of the sidecars. Istio uses labels to [control the injection policy](https://istio.io/latest/docs/setup/additional-setup/sidecar-injection/#controlling-the-injection-policy) and determine which pods should get the sidecar injected. The labels when working with revisions look like `istio.io/rev={revision}`.

To update the namespaces you need to change the label `istio-injection="enabled"` to point to the new revision, e.g. `istio.io/rev=v1-13-4`.

```powershell
kubectl label namespace directory istio-injection- istio.io/rev=v1-13-4
```

After that, you need to restart the pods in that namespace to trigger the injection of the new sidecar. **Consider restarting one pod at a time**, doing some testing/verification, and then restarting the next one instead of doing a mass restart.

There are ideas for testing in the [Test the Upgrade](#test-the-upgrade) section later in this document.

## Update Helmsman Values

Create a feature branch for updating the `*-values.yaml` files used in Helmsman deployment. Look through these YAML files and find any that use the old version of Istio (likely to manually inject sidecar pods). Update those so they use the new version of Istio.

Use the `Deploy-ClusterInfrastructure.ps1` script to do a dry run of the installation. This will show what Helm charts will be updated on the next deployment.

```powershell
./Deploy-ClusterInfrastructure.ps1 -WhatIf
```

Create a pull request for your Helmsman value updates. Set the PR as auto-complete. After a dry-run and approval, it will deploy these changes for real into the cluster.

## Update the Default Istio Version and Remove the Previous Version

Create a feature branch where you do two things:

- Update the `istio.json` file to [specify the new version of Istio as the default](https://istio.io/latest/docs/setup/upgrade/canary/#default-tag).
- Delete the `istio-X.Y.Z.yaml` associated with the old control plane version. The auto-deployment will see it's gone and run an uninstall.

Use the `Deploy-ClusterInfrastructure.ps1` script to do a dry run of the installation. This will show that the tag will get updated.

```powershell
./Deploy-ClusterInfrastructure.ps1 -WhatIf
```

**These both have to happen at the same time to avoid a short period of downtime during the auto-upgrade process.** Since desired state installs from oldest to newest Istio versions and you can only have [one copy of the data plane](https://istio.io/latest/docs/setup/upgrade/canary/#data-plane), if you _only_ change the default version and don't _remove the previous version at the same time_ then there will be a period during the installation where the process installs the previous version (desired state) and _downgrades_ the data plane prior to deploying the new version and re-upgrading it. Updating the default and removing the previous version manifest at the same time avoids this by skipping the re-deployment of the prior version.

Create a pull request for your default setting updates. Set the PR as auto-complete. After a dry-run and approval, it will deploy that change for real into the cluster. You should see the default get updated.

```text
PS> istioctl tag list
TAG     REVISION NAMESPACES
default v1-13-4
```

## Restart all Pods

Any running pods will still have the previous version of the Istio sidecar injected. You need to restart the pods to get the new version in place.

In addition, if you had some test/canary namespaces, revert the labels on them to the standard/default injection label and restart the pods. They will stay on the new version of Istio since it has been marked as the default.

```powershell
kubectl label namespace directory istio.io/rev- istio-injection=enabled
```

## Test the Upgrade

Upgrading works in a backward-compatible way, including [jumping across two minor versions](https://istio.io/latest/docs/setup/upgrade/canary/#before-you-upgrade). Even so, you should run some tests to verify the upgrade didn't cause problems. Here are some things to test. You should do some of these during the canary phase _and_ do a robust test/verification after the upgrade is complete.

- Send requests to the microservices through Apigee, make sure the gateways and the traffic within the mesh is working.
- Review the logs of the proxies that are sent to Splunk. Check the format is the expected (text, not JSON).
- Use the command `istioctl proxy-status` to check which version of Istio is used by the pods. You can use the command `kubectl get mutatingwebhookconfigurations` to verify there are two sidecar injector configurations including the new revision.
- Review the Istio CRDs, such us `PeerAuthentication` for mTLS setup, and `RequestAuthentications` definitions associated with the microservices.
- Check the [dashboards](https://dev.azure.com/F-DC/Digital%20Nexus/_wiki/wikis/architecture/288/Dashboards) to verify the health of the system.
- Check that the pipelines run as usual, specifically the ones with a canary deployment of the microservice.
- For additional tests that may apply to a specific cluster, check out the README in the cluster folder.

## Troubleshoot the Upgrade

You may need to troubleshoot the upgrade or get more information about the internal status.

**Get the current and the target versions of `istioctl`.** During the upgrade process, the auto-deployment script handles this for you, but if you need to run manual commands, you need to use the version of `istioctl` that matches the version deployed in cluster. You can get the `istioctl` CLI [here](https://github.com/istio/istio/releases/).

The command `istioctl proxy-status` proxy-status can be used to list the pods inside the mesh and which ones are remaining to be migrated.

```text
PS> istioctl proxy-status
NAME                                                   CLUSTER        CDS        LDS        EDS        RDS          ISTIOD                              VERSION
istio-egressgateway-579cc9dcf9-s5rns.istio-system      Kubernetes     SYNCED     SYNCED     SYNCED     NOT SENT     istiod-v1-13-4-5dc6bfd5dd-zwmtg     1.13.4
istio-egressgateway-579cc9dcf9-sfr6m.istio-system      Kubernetes     SYNCED     SYNCED     SYNCED     NOT SENT     istiod-v1-13-4-5dc6bfd5dd-zwmtg     1.13.4
istio-ingressgateway-8477c6467c-nvzzc.istio-system     Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-zwmtg     1.13.4
istio-ingressgateway-8477c6467c-plgr5.istio-system     Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-tg5gb     1.13.4
jaeger-operator-7976c46bd5-md79q.monitoring            Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-tg5gb     1.13.4
kayenta-api-85bd7bcd87-577qd.kayenta                   Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-tg5gb     1.13.4
kayenta-shared-redis-master-0.kayenta                  Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-tg5gb     1.13.4
kayenta-shared-redis-replicas-0.kayenta                Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-zwmtg     1.13.4
kayenta-shared-redis-replicas-1.kayenta                Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-tg5gb     1.13.4
kayenta-shared-redis-replicas-2.kayenta                Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-zwmtg     1.13.4
prometheus-server-66f8df6966-lll5c.monitoring          Kubernetes     SYNCED     SYNCED     SYNCED     SYNCED       istiod-v1-13-4-5dc6bfd5dd-zwmtg     1.13.4
```

## Rollback

In case you need to revert an upgrade the process is similar to deploying a new revision. It's sort of "fail-forward."

- Add an `istio-X.Y.Z.yaml` manifest for the previous Istio version.
- Update the `cluster.toml` and any `values.yaml` files to the previous Istio version.
- Set `istio.json` to indicate the default Istio version is the previous version.
- Restart all pods.
- Delete the `istio-A.B.C.yaml` manifest for the version you're rolling back.

## Future Improvements

According to the Istio documentation, there is a feature called [Stable Revision Labels](https://istio.io/latest/docs/setup/upgrade/canary/#stable-revision-labels-experimental) currently in an experimental phase. This functionality avoids the necessity for relabeling the namespaces after a new revision gets deployed in the cluster, by using tags associated to specific revisions, similar to the `default` tag. The association can be modified, changing the revision used in a namespace without changing the labels. More information can be found [here](https://istio.io/latest/blog/2021/revision-tags/).

## Known issues

### Invalid memory address or nil pointer dereference

`Dry-run changes` step in the pipeline for Istio upgrade throws the following error:

```text
What if: Performing the operation "Analyze Istio 1.16.2 manifest" on target "35abf82e-a23b-49c4-8bae-88baead6f7d3/nexus-westus2-ping/digital-nexus". panic: runtime error: invalid memory address or nil pointer dereference [signal SIGSEGV: segmentation violation code=0x1 addr=0x28 pc=0x2846da3]
goroutine 1 [running]:
istio.io/istio/pkg/config/analysis/analyzers/envoyfilter.(*EnvoyPatchAnalyzer ).analyzeEnvoyFilterPatch(0x40dc67, 0xc001cb1200, {0x3a1fa80, 0xc001bfa820?}, {0xc001c15780?, 0xc000ab6fd0?, 0x0?})
```

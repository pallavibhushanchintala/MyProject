# ElasticSearch

[Home Page](https://www.elastic.co/products/elasticsearch)

ElasticSearch is the storage for Jaeger and Fluentd logging. Curator is a scheduled process that cleans up data and maintains the database. Kibana is the dashboard for querying ElasticSearch.

## Tips on Updating ElasticSearch

- **Keep all ElasticSearch components on the same version.** If you mess with the version you need to do it in sync with all the components.
- **Keep the ElasticSearch and Kibana versions aligned.** You'll see errors logged and possible incompatibilities if you don't.
- **You must deploy and start the cluster in order** - `master` => `data` => `client`. If you don't start in that order, the cluster may never actually start up.
- **Helmsman will wait 15 minutes for ElasticSearch components** to deploy. This overrides the default five minute wait time because setting up persistent volumes is a slow process.
- **If you need to change the storage size** on any of the components (the `volumeClaimTemplate` settings in `values.yaml`) you may need to disable and re-enable the whole stack. Changing those values changes settings on a `StatefulSet` and Kubernetes won't let you modify just the volume claim size. Remember the cluster order from above - if you have to change `data`, you'll need to disable/deploy/re-enable/deploy on `data` _and_ on `client`; to change the `master` storage you'll have to disable/re-enable all three. You may also end up having to delete the persistent volumes because they may or may not re-allocate/resize.

## Checking ElasticSearch Health

You can check the health of the cluster by forwarding the `elasticsearch-client` service...

```powershell
kubectl port-forward svc/elasticsearch-client -n monitoring 9200:9200
```

[Then access the cluster health endpoint](http://localhost:9200/_cluster/health?pretty) to see JSON like this:

```json
{
  "cluster_name" : "elasticsearch",
  "status" : "green",
  "timed_out" : false,
  "number_of_nodes" : 7,
  "number_of_data_nodes" : 2,
  "active_primary_shards" : 0,
  "active_shards" : 0,
  "relocating_shards" : 0,
  "initializing_shards" : 0,
  "unassigned_shards" : 0,
  "delayed_unassigned_shards" : 0,
  "number_of_pending_tasks" : 0,
  "number_of_in_flight_fetch" : 0,
  "task_max_waiting_in_queue_millis" : 0,
  "active_shards_percent_as_number" : 100.0
}
```

Node stats [can be accessed](http://localhost:9200/_nodes/stats/fs?pretty) to show individual machines and data volumes in JSON (abbreviated results shown here):

```json
{
  "_nodes" : {
    "total" : 9,
    "successful" : 9,
    "failed" : 0
  },
  "cluster_name" : "elasticsearch",
  "nodes" : {
    "3aT-E055TYqKMuvc86iGbA" : {
      "timestamp" : 1623431298697,
      "name" : "elasticsearch-client-6d75868b4f-qql2h",
      "transport_address" : "10.244.0.46:9300",
      "host" : "10.244.0.46",
      "ip" : "10.244.0.46:9300",
      "roles" : [
        "ingest"
      ],
      "fs" : {
        "timestamp" : 1623431298703,
        "total" : {
          "total_in_bytes" : 133018140672,
          "free_in_bytes" : 99897597952,
          "available_in_bytes" : 99880820736
        },
        "data" : [
          {
            "path" : "/usr/share/elasticsearch/data/nodes/0",
            "mount" : "/ (overlay)",
            "type" : "overlay",
            "total_in_bytes" : 133018140672,
            "free_in_bytes" : 99897597952,
            "available_in_bytes" : 99880820736
          }
        ],
        "io_stats" : { }
      }
    }
  }
}
```

To see the disk space usage for the cluster, you can look at [the basic allocations](http://localhost:9200/_cat/allocation?v) which will look like this:

```text
shards disk.indices disk.used disk.avail disk.total disk.percent host        ip          node
   136       24.9gb    24.9gb      4.4gb     29.4gb           84 10.244.2.29 10.244.2.29 elasticsearch-data-0
   136       24.9gb    24.9gb      4.4gb     29.4gb           84 10.244.0.48 10.244.0.48 elasticsearch-data-1
```

Or you can [break it down by individual shard](http://localhost:9200/_cat/shards?v) - this list can get _very long_:

```text
index                          shard prirep state      docs   store ip          node
jaeger-service-2021-06-09      3     r      STARTED       1   3.7kb 10.244.2.29 elasticsearch-data-0
jaeger-service-2021-06-09      3     p      STARTED       1   3.7kb 10.244.0.48 elasticsearch-data-1
jaeger-service-2021-06-09      1     r      STARTED       2   3.8kb 10.244.2.29 elasticsearch-data-0
jaeger-service-2021-06-09      1     p      STARTED       2   3.8kb 10.244.0.48 elasticsearch-data-1
jaeger-service-2021-06-09      2     p      STARTED       1   3.4kb 10.244.2.29 elasticsearch-data-0
jaeger-service-2021-06-09      2     r      STARTED       1   3.4kb 10.244.0.48 elasticsearch-data-1
jaeger-service-2021-06-09      4     p      STARTED       1   3.4kb 10.244.2.29 elasticsearch-data-0
jaeger-service-2021-06-09      4     r      STARTED       1   3.4kb 10.244.0.48 elasticsearch-data-1
jaeger-service-2021-06-09      0     p      STARTED       2   3.5kb 10.244.2.29 elasticsearch-data-0
jaeger-service-2021-06-09      0     r      STARTED       2   3.5kb 10.244.0.48 elasticsearch-data-1
logstash-2021.06.09            3     r      STARTED 1338982 840.7mb 10.244.2.29 elasticsearch-data-0
logstash-2021.06.09            3     p      STARTED 1338982 840.6mb 10.244.0.48 elasticsearch-data-1
logstash-2021.06.09            1     r      STARTED 1337445 839.8mb 10.244.2.29 elasticsearch-data-0
logstash-2021.06.09            1     p      STARTED 1337445 840.2mb 10.244.0.48 elasticsearch-data-1
logstash-2021.06.09            2     p      STARTED 1338223 839.9mb 10.244.2.29 elasticsearch-data-0
logstash-2021.06.09            2     r      STARTED 1338223 840.1mb 10.244.0.48 elasticsearch-data-1
logstash-2021.06.09            4     p      STARTED 1337342   838mb 10.244.2.29 elasticsearch-data-0
logstash-2021.06.09            4     r      STARTED 1337342 838.8mb 10.244.0.48 elasticsearch-data-1
logstash-2021.06.09            0     p      STARTED 1335077 838.1mb 10.244.2.29 elasticsearch-data-0
logstash-2021.06.09            0     r      STARTED 1335077 838.1mb 10.244.0.48 elasticsearch-data-1
jaeger-span-2021-06-10         3     r      STARTED   35864   1.2mb 10.244.2.29 elasticsearch-data-0
jaeger-span-2021-06-10         3     p      STARTED   35864   1.3mb 10.244.0.48 elasticsearch-data-1
jaeger-span-2021-06-10         1     r      STARTED   34214   1.2mb 10.244.2.29 elasticsearch-data-0
...
```

In Azure Kubernetes, [the "default" storage class is standard HDD; the "managed-premium" class is SSD](https://docs.microsoft.com/en-us/azure/aks/azure-disks-dynamic-pv). Those are ready out of the box. Set the `storageClass` values to `default` in your values file to use standard disks.

## Troubleshooting

Fluentd and ElasticSearch somewhat go hand-in-hand, so check the [Fluentd page we have](fluentd.md) for additional tips.

Amazon [has an ElasticSearch troubleshooting page](https://aws.amazon.com/premiumsupport/knowledge-center/elasticsearch-red-yellow-status/) that also helps with troubleshooting.

### Full Disk

In the Fluentd log you may see errors like this:

```json
{
  "index": {
    "_id": "R97n-3kBh5LtzRK8rMvh",
    "_index": "logstash-2021.06.11",
    "_type": "_doc",
    "error": {
      "reason": "blocked by: [FORBIDDEN/12/index read-only / allow delete (api)];",
      "type": "cluster_block_exception"
    },
    "status": 403
  }
}
```

The key is that `read-only` part. Per [this StackOverflow question](https://stackoverflow.com/questions/50609417/elasticsearch-error-cluster-block-exception-forbidden-12-index-read-only-all) it appears this means ElasticSearch has hit a full disk threshold and has switched to read-only mode. [The disk-based shard allocation settings](https://www.elastic.co/guide/en/elasticsearch/reference/6.8/disk-allocator.html) control the point at which the cluster will consider the disk full and will go to read only mode.

See the "checking ElasticSearch health" section, above, for how to query for disk space usage.

### Starved Thread Pool on Bulk Insert

If you don't have enough threads to handle all the bulk input operations, Fluentd will time out on writing to ElasticSearch. Turning that value up can help.

- [StackOverflow question about it](https://stackoverflow.com/questions/37855803/rejected-execution-of-org-elasticsearch-transport-transportservice-error)
- [Related ElasticSearch docs](https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-threadpool.html)

```yaml
cluster:
  config:
    thread_pool.write.queue_size: 100
```

## ElasticSearch Security

> :warning: **Due to various challenges in the cluster, we didn't end up implementing ElasticSearch security.** [If you go back in the repo](https://dev.azure.com/F-DC/Digital%20Nexus/_git/nexus-infrastructure-charts?version=GCbee2a589e3baebece686dca8296676b996f86d2e) and look at the `/35abf82e-a23b-49c4-8bae-88baead6f7d3/westus2/infra` folder you can see how ElasticSearch and other components were starting to shape up with security in place. That may be a good starting point.

You can't simply use Istio sidecar injection to add mTLS to ElasticSearch. The problem is that it uses a node-to-node communications channel on port 9300 to do master election and the Envoy proxy + mTLS breaks it. [Using a PKI realm to enable certificate authentication is a "gold" license feature](https://www.elastic.co/guide/en/kibana/current/elasticsearch-mutual-tls.html). In the free version of ElasticSearch you can use username + password + TLS authentication between components like ElasticSearch and Kibana.

TLS is supported by [using the built-in configuration](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/security-basic-setup-https.html) to set up encryption between ElasticSearch cluster nodes and on the API endpoints. This is done much like Prometheus scraping for mTLS pods - a manually injected sidecar and use of the Istio certificates using the built-in configuration.

ElasticSearch needs the [built-in user `elastic`](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/built-in-users.html) to be configured with a password in order for node-to-node authentication to work. Straight mTLS with identity only by certificates doesn't appear to be an option, at least for the Helm chart deployment. To that end, we have an `elastic-credentials` chart in this repository that can deploy a secret that can be shared across all ElasticSearch nodes.

By default we want to [allow anonymous access](https://www.elastic.co/guide/en/elasticsearch/reference/current/anonymous-access.html) to simple health and monitoring endpoints so tools don't also have to share that secret. Monitoring information exposes nothing proprietary. You will need to [define a custom role](https://www.elastic.co/guide/en/elasticsearch/reference/current/defining-roles.html) with `cluster/monitor` permissions to grant to the anonymous user for that.

## References

- [Walkthrough on ElasticSearch security](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/configuring-stack-security.html)
- [Security settings reference for ElasticSearch](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/security-settings.html), includes TLS settings info
- [Anonymous access setup for ElasticSearch](https://www.elastic.co/guide/en/elasticsearch/reference/7.14/anonymous-access.html), used for health checks/monitoring
- [mTLS between Kibana and ES](https://www.elastic.co/guide/en/kibana/current/elasticsearch-mutual-tls.html) - this is a gold license feature
- [Walkthrough on Kibana security](https://www.elastic.co/guide/en/kibana/7.14/using-kibana-with-security.html)
- [Security settings reference for Kibana](https://www.elastic.co/guide/en/kibana/7.14/security-settings-kb.html)
- Helm charts:
  - [ElasticSearch values.yaml](https://github.com/elastic/helm-charts/blob/master/elasticsearch/values.yaml)
  - [ElasticSearch example showing security](https://github.com/elastic/helm-charts/blob/master/elasticsearch/examples/security/values.yaml)
  - [Kibana values.yaml](https://github.com/elastic/helm-charts/blob/master/kibana/values.yaml)
  - [Kibana example showing security](https://github.com/elastic/helm-charts/blob/master/kibana/examples/security/values.yaml)

# cert-manager

[Home Page](https://cert-manager.io/)

cert-manager handles retrieval and rotation of TLS certificates via ACME protocol (LetsEncrypt). Primarily used for associating TLS certificates with Kubernetes ingress resources.

## Enabling DNS01 Solving

A `DNS01` challenge is used rather than `HTTP01`. cert-manager wants to dynamically launch a pod to answer the `HTTP01` challenge but that doesn't work too well with Istio. [This article explains some hackery to work around it](https://medium.com/@gregoire.waymel/istio-cert-manager-lets-encrypt-demystified-c1cbed011d67) as well as explaining why `HTTP01` is problematic in Istio. [This blog article](https://itsmetommy.com/2019/10/10/kubernetes-istio-with-secret-discovery-service-sds-cert-manager/) makes it look simple but this doesn't appear to work. That said, the article does have a good walkthrough of setting up a certificate that can be solved by cert-manager.

[The cert-manager documentation](https://cert-manager.io/docs/configuration/acme/dns01/azuredns/) explains how to set up `DNS01` with Azure DNS. You will end up creating a service principal for DNS work and setting up a secret in the `cert-manager` namespace with the service principal password.

**You will need the information for the DNS solver when setting up the cluster issuers.** You can see where these are used in the `dns01-clusterissuers` chart in this repo.

# Kibana

[Home Page](https://www.elastic.co/products/kibana)

Kibana is the query dashboard for ElasticSearch logs.

**Keep the ElasticSearch and Kibana versions aligned.** You'll see errors logged and possible incompatibilities if you don't.

The Elastic stack (ElasticSearch + Kibana) are pretty closely related. Check the [ElasticSearch docs in our repo](elasticsearch.md) for more info and tips, especially on security setup.

## Prerequisites

- ElasticSearch

## Initial Setup

If it's the first deployment of the system and you've never visited before, you'll be asked to set up a new log index. Set up `logstash-*` as the index pattern. This is the data that Fluentd pipes into ElasticSearch.

## Browse Without an Ingress

Forward the port from the Kibana instance in the cluster to your local machine:

```powershell
$SvcName = kubectl get svc --namespace monitoring -l "app=kibana" -o jsonpath="{.items[0].metadata.name}"
kubectl --namespace monitoring port-forward svc/$SvcName 5601
```

Visit [the local Kibana port](http://localhost:5601) to view the dashboard.

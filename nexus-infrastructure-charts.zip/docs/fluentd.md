# Fluentd

[Home Page](https://www.fluentd.org/)

Fluentd passes logs from Kubernetes entities over to ElasticSearch for indexing and querying. The configuration here allows Fluentd to work better with ASP.NET Core apps and Serilog. The base container deployed by default [is this one from the main Kubernetes repo](https://github.com/kubernetes/kubernetes/blob/master/cluster/addons/fluentd-elasticsearch/fluentd-es-image/Dockerfile).

## Prerequisites

- ElasticSearch

## Configuration

Configuration [is included into the system](https://github.com/kubernetes/kubernetes/blob/master/cluster/addons/fluentd-elasticsearch/fluentd-es-image/fluent.conf) using `@include /etc/fluent/config.d/*.conf` which [reads config files in alphabetical order](https://docs.fluentd.org/configuration/config-file#6-reuse-your-config-the-include-directive). This allows us to append new config files (like the Serilog compact JSON support) by relying on this order.

The `containers.input.conf` configuration is mostly the default that ships with the chart, but at the end there are some entries added to parse Serilog compact JSON format. (That's why you might see something oddly named like `container.serilog.conf` - to ensure sort order.)

The `values.yaml` has `output.conf` settings to add threads to the flush thread count and avoid timeouts sending to ElasticSearch. It will need to be updated if authentication is enabled in ElasticSearch.

## Splunk Integration

The Splunk output plugin is added in a custom `fluentd-elasticsearch` container [that we own](https://dev.azure.com/F-DC/Digital%20Nexus/_git/docker-fluentd). If you need to add Splunk output, add an `output.splunk.conf` file (so it sorts alphabetically after `output.conf`) and add just the Splunk bits.

You can test if you're getting Splunk logging by querying Splunk for `index=kubernetes source="http:DC-AKS events"` which should show you the logs flowing in.

## Not Done

There are two configuration updates that should be added to improve the overall log/search experience.

- **`@t` should be the `@timestamp` field**: Serilog compact JSON outputs the field `@t` with the timestamp for the log message. By default, Fluentd uses the timestamp associated with the console log write, not this `@t` field. The `@timestamp` on Serilog-compact-JSON-written log entries should come from the `@t` field. An alternative is to use `Serilog.Formatter.ElasticsearchJsonFormatter`.
- **There is a conflict in `pid` field data type**: If you look at the ElasticSearch index after Fluentd starts piping in logs, the field `pid` is listed both as a string and a number. It's unclear how it got set that way in the first place, but it should be a number.

## Troubleshooting

Fluentd and ElasticSearch somewhat go hand-in-hand, so check the [ElasticSearch page we have](elasticsearch.md) for additional tips.

### Missing Data

If you find that there are patches of time where data is missing, it could be that Fluentd has filled the ElasticSearch connection buffer and has eventually lost connection.

- [GitHub issue describing the problem](https://github.com/uken/fluent-plugin-elasticsearch/issues/525)
- [fluentd-elasticsearch plugin troubleshooting guide](https://github.com/uken/fluent-plugin-elasticsearch/blob/master/README.Troubleshooting.md)

In this case, the answer appears to be to set the fluentd-elasticsearch connection to not reload connections - the plugin should be configured like this:

```text
reconnect_on_error true
reload_on_failure true
reload_connections false
```

This should be the default setup in `fluentd-values.yaml` for each cluster.

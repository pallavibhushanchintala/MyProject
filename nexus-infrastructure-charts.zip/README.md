# Digital Nexus: Kubernetes Infrastructure Deployment

Once a Kubernetes cluster is deployed, there are foundational pieces (e.g., Istio service mesh) that get  laid down so applications can use these facilities. This repository is a live repo, similar to the [`nexus-infrastructure`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/nexus-infrastructure) repo, but this one is about maintaining the set of Helm charts that deploy the foundations into the clusters.

If you're looking for our internal Helm charts repo, that's [over here.](https://dev.azure.com/F-DC/Infrastructure/_git/helm-charts)

## Repository Layout

The layout here is:

```text
subscription
 └ resource-group
    └ cluster-name
deploy
docs
```

Where the cluster definition folders are...

- **`subscription`**: Azure subscription ID. The GUID is used to ensure uniqueness since subscription names are not necessarily unique.
- **`resource-group`**: The resource group in the Azure subscription that contains the Kubernetes cluster.
- **`cluster-name`**: The actual name of the Azure Kubernetes cluster.

Automated deployments can use this structure to determine exactly where to authenticate in order to push the right charts to the right places.

And there are some ancillary folders...

- **`deploy`** has scripts and build templates used by the auto-deployment process.
- **`docs`**  contains detailed information about applications that get deployed, things you may need to know. Avoids the README here getting too bloated.

## Configuring a Cluster

Your cluster definition should be in a folder with the structure `subscription/resource-group/cluster-name` as discussed in the [Repository Layout](#repository-layout) section. Each cluster definition may have:

- One or more Istio manifests: Any file named like `istio-X.Y.Z.yaml` (`istio-1.13.4.yaml`) will be assumed to contain an Istio manifest for the specified version of Istio.
- Istio metadata: A file named `istio.json` should contain metadata about the overall Istio installation, like what version should be default.
- Helmsman desired state: A `cluster.toml` file should contain the set of Helm charts and dependency order for deploying things into the cluster.

### Istio Manifests

Istio manifest files should be in the format `istio-X.Y.Z.yaml` where `X.Y.Z` is the version of Istio to install. For example, `istio-1.13.4.yaml` is the data for Istio v1.13.4.

Inside the manifest is the YAML for [the `istioctl` profile to install](https://istio.io/latest/docs/setup/install/istioctl/). This can change based on Istio version. The installation/update process will try to run manifest analysis and cluster readiness checks prior to the deployment of each version, but it's up to you to make sure what's in the manifest is correct.

While different versions of Istio may be deployed into a cluster at the same time, you also need to be able to specify metadata about the overall cluster setup, like which version of Istio is the default. That's where `istio.json` comes in.

`istio.json` has the following format. Currently only the default version of Istio is specified. This version will [end up with the `default` tag after a canary upgrade](https://istio.io/latest/docs/setup/upgrade/canary/#default-tag).

```json
{
  "default": "1.13.4"
}
```

Here's how you can do a canary upgrade to the Istio control plane. **Each of these steps will be a separate pull request** that will cause a deployment to run.

1. Add an `istio-X.Y.Z.yaml` manifest for the new Istio version to install. This is the canary version. After this is installed, you can do some testing with it on some select pods/services to verify things look good.
2. If the canary is unsuccessful, remove the `istio-X.Y.Z.yaml` you added. This will cause the version to be uninstalled. After this you're done. Otherwise...
3. Update any `values.yaml` manifests that reference the Istio version. Some have manually-injected sidecars that specify an Istio version. These need to be updated to use the new version.
4. Update `istio.json` to specify the new version of Istio as the default. Delete the old `istio-A.B.C.yaml` for the version of Istio that is no longer in use.  Any new pod deployments will get this version of the sidecar injected. After this deploys and the default is updated, you will need to restart all deployments that have sidecars so the correct version of the sidecar will be injected. The deployment does not do this for you.

The [Istio upgrade docs in this repo](./docs/istio-upgrade.md) go into more detail about what you can look at/test while doing an upgrade.

### Helmsman Desired State

A file named `cluster.toml` indicates the [Helmsman desired state](https://github.com/Praqma/helmsman/blob/master/docs/desired_state_specification.md) for the cluster. This is where you define the list of Helm charts, values, and dependency order for deployment.

The standard header metadata for a Helmsman desired state file looks like this:

```toml
context = "54faa056.dc-centralus-prod-dsl-rg1.aks-dsl1-centralus"

[metadata]
subscription = "54faa056-251d-4933-ba58-0556a6adb641"
resourceGroup = "dc-centralus-prod-dsl-rg1"
cluster = "aks-dsl1-centralus"
environment = "prod"

[settings]
kubeContext = "35abf82e-a23b-49c4-8bae-88baead6f7d3.nexus-westus2-ping.digital-nexus-admin"
```

Where:

- `context` is a label that will be applied to all Helmsman deployments to indicate ownership. If a cluster gets deployed with multiple `cluster.toml` files for some reason, this stops both files from defining the same deployment. (This repo does not support multiple `cluster.toml` files.) The format of the label is `subscription-first-eight.resource-group.cluster-name`. The maximum length of this value is 63 characters since it is used as a label value in Kubernetes, which is why the subscription is shortened.
- `metadata.subscription`, `metadata.resourceGroup`, and `metadata.cluster` should match the respective values as those in the folder path.
- `metadata.environment` is a human-readable note to help folks understand whether the cluster is `development` or `production` and be able to gauge the importance of changes.
- `settings.kubeContext` must be in the form `subscription.resource-group.cluster-name-admin`. The `subscription`, `resource-group`, and `cluster-name` must match the respective values as those in the folder path. The `-admin` suffix is a requirement due to the `az aks login` command always appending `-admin` to the end of a generated `kubectl` context for cluster admins.

While there is no fixed requirement on the naming of Helm values files, generally the format is `chart-name-values.yaml`, like `prometheus-values.yaml` for the `prometheus` chart. **Any YAML file in the cluster folder that is not Istio-related is considered to be a Helm value file.**

## Making Changes

The process for making changes - provisioning a new cluster, updating an existing cluster - is:

- Create a feature branch. This should be named in the format `feature/XXXX` following Gitflow structure.
- Make your changes.
- Test them out locally using the `-WhatIf` option to see what would happen.
- Make sure to merge/rebase on master to ensure you have the latest updates.
- Create a pull request from your branch to `master`. **Set it to auto-complete** so when the PR is accepted - which includes the final deployment of the changes - it will automatically get merged back to `master`.
- The automated deployment will handle detecting changes, generating a dry-run "plan," and getting approval to execute the final update.

> :warning: **Make small, atomic changes** rather than lots of changes in one pull request. For example, instead of trying to update every infrastructure component in a cluster to the latest version all at once, update one at a time. Not only does this reduce "blast radius" :boom: if something goes wrong, but also allows a better audit trail and easier rollback.

If you're looking to make changes to our internal Helm charts, [that repo is over here.](https://dev.azure.com/F-DC/Infrastructure/_git/helm-charts)

### Tools

If you want to do a dry-run deployment to a cluster to see what might change based on your updates, you'll need...

- [az](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli)
- [PowerShell Core](https://github.com/PowerShell/PowerShell)
- [Helmsman 3.15+](https://github.com/Praqma/helmsman)
- [kubectl](https://github.com/kubernetes/kubectl)
- [Helm 3.8.0+](https://github.com/helm/helm)
- [helm-diff](https://github.com/databus23/helm-diff)

### Authenticating for Fiserv Charts

There are several internal charts that are used here that are stored in Azure Container Registry. This uses the `helm` OCI support for storing and retrieving artifacts. The `Mount-HelmAcr.ps1` script helps automate the process of using the `az` CLI to get a token and use that with `helm`. You can see more info along with usage examples by running `Get-Help Mount-HelmAcr.ps1`.

### Kubernetes Cluster Contexts

You need to have a Kubernetes context for the cluster(s) to which you're deploying. For Azure Kubernetes you can do that with the `az` CLI.

```powershell
$subscription = "subscription"
$resourceGroup = "resource-group"
$clusterName = "cluster-name"

az aks get-credentials `
  --subscription "$subscription" `
  -g "$resourceGroup" `
  -n "$clusterName" `
  --context "$subscription.$resourceGroup.$clusterName" `
  --admin `
  --overwrite-existing
```

This will create a new context formatted like `subscription.resource-group.cluster-name-admin` like `54faa056-251d-4933-ba58-0556a6adb641.dc-centralus-prod-dsl-rg1.aks-dsl1-centralus-admin`. This is the same format that the automated deployment will use.

### Try It Out (Dry Run)

To see what your changes will do, you can run the deployment script in a dry-run fashion.

```powershell
# Make sure you're signed into the Azure Container Registry for Helm charts.
./Mount-HelmAcr.ps1

# See all the options for the deployment script.
Get-Help ./Deploy-ClusterInfrastructure.ps1

# Run the auto-deploy in a dry-run fashion.
./Deploy-ClusterInfrastructure.ps1 -WhatIf

# See a LOT more details about what's happening in dry-run.
./Deploy-ClusterInfrastructure.ps1 -WhatIf -Verbose

# Do a super-quick summary without actually executing a full dry-run that
# interrogates the cluster.
./Deploy-ClusterInfrastructure.ps1 -WhatIf -Verbose -SkipDryRun
```

### Using VS Code

The workspace has a set of recommended extensions that can help you work with Helm and Kubernetes. In the VS Code extensions window, "Show Recommended Extensions" or enter `@recommended` to see them as "Workspace Recommendations."

If you use the `redhat.vscode-yaml` extension (one of the recommendations) you can get automatic validation of YAML files based on official schema if you name your files right. It automatically uses [the JSON schema store](http://schemastore.org/api/json/catalog.json) to map filenames to schema. For example, you'll see `prometheus.yaml` maps to Prometheus configuration (rather than a values file for the Prometheus Helm chart, which is why Helm chart values files end with `-values`).

## Reviewing and Approving Changes

If you are responsible for reviewing and approving pull requests, there are several things to check:

- **Make sure the latest changes from `master` are in the pull request.** If there are a lot of pull requests happening, it's possible one gets out of date. There isn't a good programmatic way to enforce this. If this isn't the case, you may find a deployment here _rolls back_ something that got fixed in a different PR.
- **All branch policies should pass before approving deployment.** A pull request will do a dry run and get things ready, just waiting for an environment owner to approve the final deployment. Before the owner clicks that approval button, _all branch policies must be satisfied_. Required reviewers must approve the PR, all comments must be resolved, etc. If the owner tries to allow deploy without these things, the deploy will be aborted and the whole dry-run/approval loop will have to be re-queued.
- **Ensure changes are small and contained.** Don't let folks update every version of every component in the entire cluster. If something goes wrong, it's harder to recover from lots of changes. Plus, from an audit perspective, being able to see the PR list as an audit trail is helpful.

## How Auto-Deployment Works

There are two primary pieces to the auto-deployment mechanism for cluster infrastructure: the build and the script.

### The Build

The build, found in `azure-pipelines.yml`, **only runs on feature branches and pull requests.**

- Feature branch builds (`features/*`) will do a dry-run so developers can see what their changes _would_ do in the event of a real deployment.
- Pull requests to `master` will do a dry-run _first_, then ask for approval to do the **real deployment.**

The build uses the branch information as well as the directory structure conventions to determine what to execute and which Kubernetes contexts to create.

Any ancillary build templates required specifically for the deployment can be found in the `deploy` folder.

### The Deployment

The `Deploy-ClusterInfrastructure.ps1` script is the entry point for deployment - both dry-run and the real thing.

The logic is, basically:

1. Locate changes. By default it will compare your feature branch with `master` and use that as the change list.
2. Execute on Istio changes for each cluster. This will happen if there are any changes to `istio.json` and `istio-*.yaml` files. If there are no changes to these files, the operation is skipped for that cluster.
    1. Get the set of _desired_ Istio versions/state.
    2. Get the set of _actual_ Istio versions/state. This is done by querying the cluster.
    3. For each _desired_ version (from lowest to highest version)...
        1. Run a pre-check to ensure the cluster can take the version.
        2. If the version is already installed, analyze the manifest to check for issues.
        3. Install the version of Istio with the manifest. If there were no changes, this is effectively a no-op.
    4. Ensure the desired `default` Istio tag is set to the proper value.
    5. For each _actual_ version that is _not desired_ (from lowest to highest version), uninstall that Istio version.
3. Execute Helmsman for each cluster with changes. This will happen if there are any changes to _any file that is not Istio-related_ in the cluster folder.

> :warning: **DO NOT HAND TWEAK THINGS THAT GET DEPLOYED THIS WAY. AVOID MANUALLY DEPLOYING.** There is no way to force a particular cluster to re-deploy or to ignore a specific change. You _can_ execute the `Deploy-ClusterInfrastructure.ps1` script with a `-FullRefresh` parameter and it will do both Istio and Helmsman runs for _all clusters_. If all the clusters are correctly up to date, this should be a no-op. If folks have been poking around "trying things out," well, that's not infrastructure-as-code, now, is it? It's recommended to only do `-FullRefresh` while you have the latest `master` as the active branch. If you do it from a feature branch, it'll deploy all the feature branch changes. Don't do that. `-FullRefresh` is an escape hatch if the automation/pipeline goes wrong. Use the pipeline to deploy, never deploy manually.

## Health Check

While not every cluster will get every component (e.g., cluster issuers, etc.), the `Test-ObservabilityTools.ps1` script will do a health check (to the extent possible) to see if the various observability components - Jaeger, Fluentd, ElasticSearch, Kiali, Kibana, etc. - are running and healthy.

## Troubleshooting

There is a bunch of documentation in the `docs` folder to explain what some of the charts are (the ones we pull from public repos) and how they work. Check out that `docs` folder for additional information if something is unclear.

**If you see a `401 Unauthorized`** error during Helmsman...

```text
Error: failed to authorize: failed to fetch oauth token: unexpected status: 401 Unauthorized
2022-09-28 09:44:18 ERROR: chart [ oci://digitalnexus.azurecr.io/helm/splunk-metrics ] version [ 1.4.9 ] can't be found. If this is not a local chart, add the repo [ helm ] in your helmRepos stanza. Error output: Getting latest non-local chart's version oci://digitalnexus.azurecr.io/helm/splunk-metrics-1.4.9 failed with non-zero exit code 1: exit status 1
```

...that means you haven't authenticated to the Azure Container Registry for the Helm charts. **Run the `./Mount-HelmAcr.ps1` script to log in.**

**If you see timeout messages** when testing against the commercial tenant cluster, [you probably forgot to MFA to access the subscription](https://mfa.onefiserv.net/FiservMFAPortal/).

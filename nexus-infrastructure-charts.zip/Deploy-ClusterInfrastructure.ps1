﻿<#
.SYNOPSIS
    Detects changes in the source tree and auto-updates Kubernetes cluster
    contents.
.DESCRIPTION
    Compares a specified branch or commit to the latest in `master` and
    determines which cluster(s) need things updated. Handles both Istio and
    Helmsman updates.

    If you specify `-WhatIf` you'll execute the changes in a "dry run" format so
    you can see what would change. This still requires actually authenticating
    against each cluster to calculate the changes in the dry run. If you only
    want to see a short summary of the detected changes without a dry run, use
    the `-SkipDryRun` flag along with `-WhatIf`. Note the cluster may still need
    to be queried for some state to give an accurate summary, so skipping the
    dry run is faster but doesn't mean zero network connectivity.

    The script assumes you have created kubectl contexts for each cluster named
    in the format `subscription.resource-group.cluster-name-admin` like
    `35abf82e-a23b-49c4-8bae-88baead6f7d3.nexus-westus2-infra.digital-nexus-admin`. It
    will check for the required contexts prior to executing changes and fail if
    they are not present. The "-admin" suffix is required because the `az` command
    line tool forcibly adds that to all cluster admin credentials.

    You can get the cluster admin context like this:

    az aks get-credentials `
      --subscription "$subscription" `
      -g "$resourceGroup" `
      -n "$clusterName" `
      --context "$subscription.$resourceGroup.$clusterName" `
      --admin `
      --overwrite-existing
.PARAMETER TargetCommit
    The name of the branch or the SHA commit hash to compare to `master` to
    detect changes. If this is being deployed from a PR, it should be the PR
    branch name. If you have changes you haven't pushed to origin, specify
    `HEAD`.
.PARAMETER FullRefresh
    Force a full update of Istio and Helm in all clusters regardless of whether
    a change is detected. Useful if someone has been manually modifying things
    in a cluster and you want to force a deploy of the existing setup.
.PARAMETER SkipDryRun
    Used in conjunction with `-WhatIf`, this will only do the change detection
    portion of the deployment without executing the dry run. This can help in
    fast debugging so you don't have to authenticate with every cluster.
.PARAMETER Force
    Bypasses prompting to update and executes all updates forcibly.
.EXAMPLE
    ./Deploy-ClusterInfrastructure.ps1

    Execute the auto-deploy. Whatever branch is currently checked out will be
    compared to `master` and that's what will be used as the basis for
    deployment. You will be asked to confirm each change.
.EXAMPLE
    ./Deploy-ClusterInfrastructure.ps1 -Force

    Execute the auto-deploy but skip being prompted for changes. This is the
    NUCLEAR OPTION. This is really only interesting in a non-interactive
    automated build situation.
.EXAMPLE
    ./Deploy-ClusterInfrastructure.ps1 -WhatIf

    Detect changes that would be deployed and do a dry run on those changes.
    Helpful for seeing what will possibly be deployed, similar to
    `terraform plan`. Note that the difference is that `terraform plan` can
    create a fixed plan to apply; this is simply a dry run of the install. It
    is not guaranteed that the output from `-WhatIf` will be literally
    identical to what gets deployed on a subsequent execution without
    `-WhatIf`. It's a dry run, not a plan.
.EXAMPLE
    ./Deploy-ClusterInfrastructure.ps1 -WhatIf -SkipDryRun

    Detect changes that would be deployed and write a log of summarizing the
    updates that would take place. No actual dry run will be executed; instead
    this will write only the names of the operations that would run.
.EXAMPLE
    ./Deploy-ClusterInfrastructure.ps1 -WhatIf -FullRefresh

    Execute a dry run against all clusters for both Helmsman and Istio to see
    how the deployed environment differs from the target environment. Skips
    detection of changes and assumes everything has changed and needs a full
    refresh.
#>

[CmdletBinding(SupportsShouldProcess = $True, ConfirmImpact = "High", DefaultParameterSetName = "DetectChanges")]
Param(
    [Parameter(ParameterSetName = "DetectChanges")]
    [string]
    $TargetCommit = "HEAD",

    [Parameter(ParameterSetName = "FullRefresh")]
    [Switch]
    $FullRefresh,

    [Parameter()]
    [Switch]
    $SkipDryRun,

    [Parameter()]
    [Switch]
    $Force
)
Begin {
    class ClusterChange {
        [string]$Subscription
        [string]$ResourceGroup
        [string]$ClusterName
        [string]$BasePath
        [string]$Update = "Helm"
        [string]$KubeContext
        [string] ToString() {
            # Used in logging/WhatIf processing.
            return "$($this.Subscription)/$($this.ResourceGroup)/$($this.ClusterName)"
        }
    }

    # Import functions from external files so this script doesn't get too
    # unwieldy. These will only be available to this script.
    . $PSScriptRoot/deploy/Confirm-RequiredContexts.ps1
    . $PSScriptRoot/deploy/Deploy-Istio.ps1
    . $PSScriptRoot/deploy/Get-ClusterChange.ps1
    . $PSScriptRoot/deploy/Get-Istioctl.ps1

    If ($env:SYSTEM_DEBUG) {
        # Support the build adding debug parameters.
        $VerbosePreference = "Continue"
    }

    $helm = Get-Command "helm" -ErrorAction Ignore | Select-Object -ExpandProperty Source
    If ($Null -eq $helm) {
        throw "Helm was not found. This is required for Helm deployment."
    }
    Write-Verbose "Helm is at $helm"

    $helmsman = Get-Command "helmsman" -ErrorAction Ignore | Select-Object -ExpandProperty Source
    If ($Null -eq $helmsman) {
        throw "Helmsman was not found. This is required for Helm deployment."
    }
    Write-Verbose "Helmsman is at $helmsman"

    $kubectl = Get-Command "kubectl" -ErrorAction Ignore | Select-Object -ExpandProperty Source
    If ($Null -eq $kubectl) {
        throw "kubectl was not found. This is required for Helm deployment and context checking."
    }
    Write-Verbose "kubectl is at $kubectl"

    $git = Get-Command "git" -ErrorAction Ignore | Select-Object -ExpandProperty Source
    If ($Null -eq $helmsman) {
        throw "Git was not found. This is required for change detection."
    }
    Write-Verbose "Git is at $git"
}

Process {
    If ($Force -and -not $Confirm) {
        $ConfirmPreference = 'None'
    }

    $changeGroups = Get-ClusterChange $git $TargetCommit $FullRefresh
    If ($changeGroups.Length -eq 0) {
        Write-Verbose "No changes detected."
        exit 0
    }

    Confirm-RequiredContexts $kubectl $changeGroups

    # Do the Istio updates first.
    $istioChangeGroups = $changeGroups["Istio"]
    If ($istioChangeGroups) {
        $istioChangeGroups | ForEach-Object {
            $change = $_
            If ($PSCmdlet.ShouldProcess("$change", "Install Istio")) {
                Deploy-Istio -ClusterChange $change -Kubectl $kubectl -Confirm:$false
            }
            ElseIf ($WhatIfPreference) {
                Deploy-Istio -ClusterChange $change -Kubectl $kubectl -DryRun:(-not $SkipDryRun)
            }
        }
    }
    Else {
        Write-Verbose "No Istio changes detected."
    }

    # After Istio, Helmsman.
    $helmChangeGroups = $changeGroups["Helm"]
    If ($helmChangeGroups) {
        $helmChangeGroups | ForEach-Object {
            $change = $_
            $clusterToml = Join-Path $change.BasePath "cluster.toml"
            If (-not (Test-Path $clusterToml)) {
                throw "No Helmsman cluster.toml found for $change. Expected to be at $clusterToml."
            }

            Write-Verbose "Helmsman manifest for $change is at $clusterToml"
            If ($VerbosePreference -ne "SilentlyContinue") {
                $helmsmanVerbose = "-verbose"
                $helmsmanDebug = "-debug"
            }
            If ($PSCmdlet.ShouldProcess("$change", "Install Helm Charts")) {
                & "$helmsman" -f "$clusterToml" -apply $helmsmanVerbose $helmsmanDebug
                If ($LASTEXITCODE -ne 0) {
                    throw "Helmsman exited with code $LASTEXITCODE. Check the output for details."
                }
            }
            ElseIf ($WhatIfPreference -and -not $SkipDryRun) {
                & "$helmsman" -f "$clusterToml" -dry-run $helmsmanVerbose $helmsmanDebug
                If ($LASTEXITCODE -ne 0) {
                    Write-Warning "Helmsman exited with code $LASTEXITCODE. If you are installing something that requires new custom resource definitions, it could be because of that. Check the output above to see what potentially failed. It could technically be OK."
                }
            }
        }
    }
    Else {
        Write-Verbose "No Helmsman changes detected."
    }
}

﻿$artifactsFolder = Join-Path $PSScriptRoot "artifacts"
If (Test-Path $artifactsFolder) {
    Write-Host "Cleaning artifacts folder."
    Remove-Item $artifactsFolder -Recurse -Force
}

Write-Host "Creating artifacts folder."
New-Item $artifactsFolder -Force -ItemType Directory | Out-Null

Get-ChildItem $PSScriptRoot/src -Directory | ForEach-Object {
    $archive = Join-Path $artifactsFolder "$($_.BaseName).zip"
    $source = $_.FullName
    Compress-Archive -Path $source -DestinationPath $archive
}

Write-Host "Done."

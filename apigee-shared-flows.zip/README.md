# Apigee: Shared Flows

[Shared flows in Apigee](https://docs.apigee.com/api-platform/fundamentals/shared-flows) are reusable blocks of policies that you can call from an API proxy using the [Flow Callout policy](https://docs.apigee.com/api-platform/reference/policies/flow-callout-policy). It's kind of like calling a subroutine.

This repo has various shared flows used in DSL API proxies.

## Shared Flows

### dsl-request-headers

Sets the `Service-Host` header to the Kubernetes service that the proxy targets. This allows Istio to properly route both internal and external traffic the same.

Usage:

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<FlowCallout async="false" continueOnError="false" enabled="true" name="Request-Header-Update">
    <DisplayName>Request Header Update</DisplayName>
    <Parameters>
        <Parameter name="service_host">my-service.my-namespace.svc.cluster.local</Parameter>
    </Parameters>
    <SharedFlowBundle>dsl-request-headers</SharedFlowBundle>
</FlowCallout>
```

| Parameter      | Example                                     | Meaning                                                                   |
| -------------- | ------------------------------------------- | ------------------------------------------------------------------------- |
| `service_host` | `my-service.my-namespace.svc.cluster.local` | Fully-qualified Kubernetes-internal hostname for the target microservice. |

### dsl-response-headers

Removes the following unnecessary headers from the response to the client:

- X-Envoy-Upstream-Service-Time

Usage:

```xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<FlowCallout async="false" continueOnError="false" enabled="true" name="Response-Headers-Update">
    <DisplayName>Response Headers Update</DisplayName>
    <SharedFlowBundle>dsl-response-headers</SharedFlowBundle>
</FlowCallout>
```

## Development

Put new shared flows under the `src` folder in a folder named for your shared flow.

- Start the name with `dsl-`.
- Use `kebab-case` (all lowercase, dash separators).
- You must put a `sharedflowbundle` folder under that, which is where your shared flow goes. That name - `sharedflowbundle` is important during the publish process.

Usually it's best to start by designing it in the Apigee UI and then export the first version.

The `build.ps1` script will zip all the policies up and put the results in an `artifacts` folder.

The CI/CD build will run `build.ps1` and publish the built flows.

# Deployment: banking/accounts

This is the Helm chart for deploying the accounts service.

Deployment is primarily controlled through the `azure-pipelines.yml` build definition.

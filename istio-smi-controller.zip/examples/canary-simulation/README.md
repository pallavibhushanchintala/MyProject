# Azure DevOps Canary Simulation

The example here is meant to mimic the mechanism used by Azure DevOps to do a canary deployment. This can show you not only how a `TrafficSplit` works, but also show how Azure DevOps canary works with it. This example uses the Kubernetes `echoserver` to echo pod information and let you see how things are working.

## Initial Setup

The initial setup will create a "deployed service" that has...

- A `namespace` called `canary-simulation` where everything will be.
- An Ubuntu container in a `diagnostics` deployment that we can use for testing.
- The initial `echoserver` version that is marked `stable`.
- The `service`, `trafficsplit`, and `virtualservice` components to route traffic to the stable service.

```pwsh
# Deploy the initial setup.
kubectl apply -k ./overlays/1-setup
```

Looking in the namespace...

```pwsh
kubectl get deployment,service,trafficsplit,virtualservice -n canary-simulation
```

...you should see something like this:

```text
NAME                          READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/diagnostics   1/1     1            1           9s
deployment.apps/echoserver    1/1     1            1           9s

NAME                        TYPE        CLUSTER-IP     EXTERNAL-IP   PORT(S)    AGE
service/echoserver          ClusterIP   10.0.135.133   <none>        8080/TCP   10s
service/echoserver-stable   ClusterIP   10.0.63.9      <none>        8080/TCP   9s

NAME                                        SERVICE
trafficsplit.split.smi-spec.io/echoserver   echoserver

NAME                                               GATEWAYS   HOSTS            AGE
virtualservice.networking.istio.io/echoserver-vs              ["echoserver"]   8s
```

What is all this stuff?

- `deployment/diagnostics` is the Ubuntu container we'll use for testing (in a moment).
- `deployment/echoserver` is the "stable" deployment of `echoserver`. It's marked up like it was deployed from an earlier canary, ready for the next version.
- `service/echoserver` is a basic Kubernetes `service` that targets _all_ of the versions of `echoserver` out there. It's not really used for anything but _discovery_ - that is, it needs to be there so pods calling it can find it in DNS. It's really the `virtualservice` that does the routing.
- `service/echoserver-stable` is a `service` that specifically targets `deployment/echoserver` because it's tagged as `stable`.
- `trafficsplit/echoserver` is an SMI `trafficsplit` - this is how the Azure DevOps canary deployment controls traffic without having to know about every service mesh. The SMI controller will convert that into...
- `virtualservice/echoserver-vs` - the Istio `virtualservice` that routes traffic.

If you look inside the `trafficsplit` or `virtualservice` you'll see _all_ traffic to `echoserver` is being routed to the `echoserver-stable` service.

You can get a shell into the diagnostics container and test the `echoserver`:

```pwsh
# Get a shell into the container.
$pod = kubectl get pod `
  -l component=diagnostics `
  -n canary-simulation `
  -o jsonpath='{.items[0].metadata.name}'
kubectl exec --stdin --tty $pod `
  -n canary-simulation `
  -c diagnostics `
  -- `
  /usr/bin/pwsh

# Now you're in the container, so try getting some info.
curl http://echoserver:8080

# The "stable" version of the service should provide the same info.
curl http://echoserver-stable:8080

# Get out of the diagnostics container with...
exit
```

You'll see some info that looks like this (trimmed):

```text
Hostname: echoserver-f6b745b4c-x9xnh

Pod Information:
  node name:     aks-nodepool01-53335527-vmss000004
  pod name:      echoserver-f6b745b4c-x9xnh
  pod namespace: canary-simulation
  pod IP:        11.1.2.135
```

**Pay attention to that info.** As we walk through this, the hostname and pod name will change based on which thing is getting traffic. That's how you know it's working!

> :question: **Where did that `-stable` stuff come from?** During the very first deployment of your service, Azure DevOps will _only_ have the `-canary` version of the service with no `-stable` or `-baseline` for comparison. Eventually (as you'll see later) the `-canary` gets promoted to be the `-stable` version. The `stable` annotations on the `deployment` and the `-stable` version of the `service` come from that promotion, ready for the next canary. This wasn't interesting to demo here, so we didn't walk through all those steps.

## Create Baseline and Canary

The first step in the Azure DevOps canary process is to create the `-baseline` and `-canary` versions of services.

- `-baseline` is a copy of the `-stable` version of the service.
- `-canary` is the _new_ version of the service.

```pwsh
# Deploy the baseline and canary.
kubectl apply -k ./overlays/2-init-canary
```

Now look what we have:

```pwsh
kubectl get deployment,service,trafficsplit,virtualservice -n canary-simulation
```

...you should see something like this:

```text
NAME                                  READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/diagnostics           1/1     1            1           8m28s
deployment.apps/echoserver            1/1     1            1           8m28s
deployment.apps/echoserver-baseline   1/1     1            1           39s
deployment.apps/echoserver-canary     1/1     1            1           39s

NAME                          TYPE        CLUSTER-IP     EXTERNAL-IP   PORT(S)    AGE
service/echoserver            ClusterIP   10.0.135.133   <none>        8080/TCP   8m29s
service/echoserver-baseline   ClusterIP   10.0.118.185   <none>        8080/TCP   40s
service/echoserver-canary     ClusterIP   10.0.0.121     <none>        8080/TCP   40s
service/echoserver-stable     ClusterIP   10.0.63.9      <none>        8080/TCP   8m28s

NAME                                        SERVICE
trafficsplit.split.smi-spec.io/echoserver   echoserver

NAME                                               GATEWAYS   HOSTS            AGE
virtualservice.networking.istio.io/echoserver-vs              ["echoserver"]   8m27s
```

And if you get a shell into the container again, you can get more info from different pods.

```pwsh
# Back in the diagnostics container...
# You should still only see stable info here.
curl http://echoserver:8080

# If you look at the canary version of the service, though...
curl http://echoserver-canary:8080
```

That peek into the `echoserver-canary` service should show you a hostname and pod name that have `-canary` in them:

```text
Hostname: echoserver-canary-7947f6c47-d2hbp

Pod Information:
  node name:     aks-nodepool01-53335527-vmss00000w
  pod name:      echoserver-canary-7947f6c47-d2hbp
  pod namespace: canary-simulation
  pod IP:        11.1.2.127
```

**That's important!** That change in the host/pod name shows you the "service version" you're connected to.

> :warning: **We don't actually have two service versions.** If you poke around you'll see we're not deploying two container image versions, it's just one version. We're demonstrating the traffic routing, not the service, so this is OK. You'll be able to see the differences by looking at the hostname and pod name in the response info.

## Take Traffic on Canary

Once the `baseline` and `canary` versions of things are out there, that's when Azure DevOps starts routing traffic. You get to configure how fast it ramps traffic onto the canary. For our demo, we'll just have one step - 50% canary traffic.

What this _actually_ breaks down to is:

- 50% `stable`
- 25% `baseline`
- 25% `canary`

This is the breakdown so you can compare apples-to-apples in stats between `baseline` and `canary`. The same amount of traffic, on average, should hit the two deployments. CPU usage, memory consumption, relative number of errors - these should be comparable across the two.

To control this, Azure DevOps deploys an updated `trafficsplit` with the appropriate breakdown. The SMI controller handles reconfiguring the `virtualservice`.

Let's watch it in action.

Open _two_ console windows. In the _first_ console window, get a shell into that diagnostics container and run this script:

```pwsh
# In the diagnostics container...
while($true){ curl http://echoserver:8080; start-sleep(1) }
```

Every second the `echoserver` service will get called and you'll see the host/pod name. Watch these values.

Now, in the _second_ console window, deploy the new `trafficsplit`.

```pwsh
# Canary time!
kubectl apply -k ./overlays/3-canary-traffic/
```

You should see the diagnostics container responses start including things from the `-baseline` and `-canary` pods. They're getting traffic!

When you're done watching, hit CTRL+C in the diagnostics container to stop the script.

## Promotion and Next Steps

When the canary is done running, Azure DevOps will run a few final updates to promote the new version of the service to be the stable version.

- Update the `trafficsplit/echoserver` so it only routes traffic to the `stable` service.
- Update the `deployment/echoserver` (the `stable` deployment) so it's using the new version of the service container.
- Remove the `-baseline` and `-canary` versions of the `deployment` and `service` since they're no longer taking traffic.

This leaves us in the same place we started, right after the initial setup.

If you want, you can play with the `trafficsplit` yourself to see how traffic redirection works.

When you're done, you can clean everything up in one go.

```pwsh
kubectl delete namespace canary-simulation
```

using Autofac;
using KubeOps.Operator;
using Serilog;

namespace Fiserv.Istio.SmiController;

/// <summary>
/// Startup logic for the SMI controller pipeline.
/// </summary>
[ExcludeFromCodeCoverage]
public class Startup
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Startup"/> class.
    /// </summary>
    /// <param name="configuration">
    /// The <see cref="IConfiguration"/> built by the host.
    /// </param>
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

        var (uaid, application) = configuration.GetApplicationProperties();
        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .EnrichWithEnhancedLoggingData(uaid, application)
            .CreateLogger();
    }

    /// <summary>
    /// Gets or sets the application configuration.
    /// </summary>
    /// <value>
    /// An <see cref="IConfiguration"/> containing application configuration.
    /// </value>
    public static IConfiguration Configuration { get; set; } = null!;

    /// <summary>
    /// Called by the ASP.NET Core startup loader after all services are registered
    /// with dependency injection. Configures the application pipeline.
    /// </summary>
    /// <param name="app">
    /// The <see cref="IApplicationBuilder"/> used to create the application pipeline.
    /// </param>
    public static void Configure(IApplicationBuilder app)
    {
        ArgumentNullException.ThrowIfNull(app);

        app.UseKubernetesOperator();
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after <see cref="ConfigureServices(IServiceCollection)"/>
    /// to register services directly with Autofac. Items registered here may override
    /// things registered in <see cref="ConfigureServices(IServiceCollection)"/>.
    /// </summary>
    /// <param name="builder">
    /// The <see cref="ContainerBuilder"/> used to register services with Autofac.
    /// </param>
    public static void ConfigureContainer(ContainerBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        var (uaid, application) = Configuration.GetApplicationProperties();
        builder.RegisterFiservAuditLogger(Configuration, uaid, application);
        builder.RegisterFiservAggregateLogger();
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after startup begins to register
    /// services with the generic .NET Core dependency management system.
    /// Items registered here will end up in the Autofac container and may
    /// be overridden by production or development container configuration.
    /// </summary>
    /// <param name="services">
    /// The <see cref="IServiceCollection"/> used to register services with .NET Core
    /// dependency management.
    /// </param>
    public static void ConfigureServices(IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);

        services.AddKubernetesOperator(settings =>
        {
            settings.Name = "istio-smi-controller";
        });
    }
}

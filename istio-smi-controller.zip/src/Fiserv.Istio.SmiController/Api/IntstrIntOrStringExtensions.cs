using k8s.Models;

namespace Fiserv.Istio.SmiController.Api;

/// <summary>
/// Extension methods for working with <see cref="IntstrIntOrString"/>.
/// </summary>
public static class IntstrIntOrStringExtensions
{
    /// <summary>
    /// Converts an <see cref="IntstrIntOrString"/> to a decimal value.
    /// </summary>
    /// <param name="value">
    /// The <see cref="IntstrIntOrString"/> with an integer value (<c>123</c>)
    /// or a resource-value style string (<c>123m</c>).
    /// </param>
    /// <returns>
    /// The <see cref="decimal"/> equivalent of the value. If the value is
    /// <see langword="null"/> or empty, a <c>0</c> will be returned.
    /// </returns>
    public static decimal ToDecimal(this IntstrIntOrString? value)
    {
        if (value is null || string.IsNullOrEmpty(value.Value))
        {
            return 0;
        }

        return new ResourceQuantity(value.Value).ToDecimal();
    }
}

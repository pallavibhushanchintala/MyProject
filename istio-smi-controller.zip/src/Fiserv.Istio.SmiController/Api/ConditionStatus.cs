namespace Fiserv.Istio.SmiController.Api;

/// <summary>
/// Well-known string constants used in conditions where there's a 'status' field.
/// </summary>
public static class ConditionStatus
{
    /// <summary>
    /// Indicates the condition has completed.
    /// </summary>
    public static readonly string True = "True";

    /// <summary>
    /// Indicates the condition has not completed.
    /// </summary>
    public static readonly string False = "False";

    /// <summary>
    /// Indicates the condition is in an unknown state.
    /// </summary>
    public static readonly string Unknown = "Unknown";
}

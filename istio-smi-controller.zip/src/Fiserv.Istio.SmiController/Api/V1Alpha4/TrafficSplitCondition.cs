using KubeOps.Operator.Entities.Annotations;
using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Condition used in status for <c>trafficsplits.split.smi-spec.io/v1alpha4</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class TrafficSplitCondition
{
    /// <summary>
    /// Gets or sets the last time the condition transitioned from one status to another.
    /// </summary>
    /// <value>
    /// A <see cref="DateTime"/> with the transition time.
    /// </value>
    /// <remarks>
    /// <para>
    /// The operator SDK doesn't support generating CRDs with <see cref="DateTimeOffset"/>.
    /// </para>
    /// </remarks>
    [Description("Last time the condition transitioned from one status to another.")]
    [JsonProperty(PropertyName = "lastTransitionTime", NullValueHandling = NullValueHandling.Ignore)]
    public DateTime? LastTransitionTime
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets a human-readable message indicating details about last transition.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> that contains details about the state
    /// transition. This is where errors or success message information will
    /// appear.
    /// </value>
    [Description("Human-readable message indicating details about last transition.")]
    [JsonProperty(PropertyName = "message", NullValueHandling = NullValueHandling.Ignore)]
    public string? Message
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets a unique, one-word, PascalCase reason for the
    /// condition's last transition.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the transition reason. This is the
    /// machine-readable equivalent of the human-readable message.
    /// </value>
    [Description("Unique, one-word, PascalCase reason for the condition's last transition.")]
    [JsonProperty(PropertyName = "reason")]
    public string? Reason
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the well-known value for the status of the condition.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with a indicating the status of the condition
    /// transition. Can be <c>True</c>, <c>False</c>, or <c>Unknown</c>.
    /// </value>
    /// <seealso cref="ConditionStatus"/>
    [Description("The status of the condition. Can be True, False, Unknown.")]
    [JsonProperty(PropertyName = "status")]
    public string Status { get; set; } = ConditionStatus.Unknown;

    /// <summary>
    /// Gets or sets the type of the condition.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with a unique, PascalCase word that explains
    /// the type of condition/transition that occurred.
    /// </value>
    [Description("The type of the condition.")]
    [JsonProperty(PropertyName = "type")]
    public string? Type
    {
        get; set;
    }
}

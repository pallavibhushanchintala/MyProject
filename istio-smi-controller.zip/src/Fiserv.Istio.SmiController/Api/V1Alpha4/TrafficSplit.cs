using k8s.Models;
using KubeOps.Operator.Entities;
using KubeOps.Operator.Entities.Annotations;

namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Service Mesh Interface (SMI) custom <c>trafficsplits.split.smi-spec.io/v1alpha4</c> resource.
/// </summary>
[KubernetesEntity(
    Group = "split.smi-spec.io",
    ApiVersion = "v1alpha4",
    Kind = "TrafficSplit",
    PluralName = "trafficsplits")]
[GenericAdditionalPrinterColumn(
    ".spec.service",
    "Service",
    "string",
    Description = "The apex service of this split.")]
[ExcludeFromCodeCoverage]
public class TrafficSplit : CustomKubernetesEntity<TrafficSplitSpec, TrafficSplitStatus>
{
}

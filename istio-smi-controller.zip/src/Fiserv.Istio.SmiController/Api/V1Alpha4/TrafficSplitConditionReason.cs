namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Well-known condition type constants used in <c>trafficsplits.split.smi-spec.io/v1alpha4</c> status.
/// </summary>
[ExcludeFromCodeCoverage]
public static class TrafficSplitConditionReason
{
    /// <summary>
    /// The condition is in its final state and completed successfully.
    /// </summary>
    public static readonly string Completed = "Completed";

    /// <summary>
    /// The condition failed to transition due to an error.
    /// </summary>
    public static readonly string Error = "Error";

    /// <summary>
    /// The condition is in progress and should be updated soon.
    /// </summary>
    public static readonly string Progressing = "Progressing";
}

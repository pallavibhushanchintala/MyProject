using k8s.Models;
using KubeOps.Operator.Entities.Annotations;
using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Service backend definition for <c>trafficsplits.split.smi-spec.io/v1alpha4</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class TrafficSplitBackend
{
    /// <summary>
    /// Gets or sets the name of the service receiving traffic.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the name of a Kubernetes service that
    /// should receive a portion of the traffic in the split.
    /// </value>
    [Required]
    [Description("Name of the Kubernetes service.")]
    [JsonProperty(PropertyName = "service")]
    public string Service { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the service weight.
    /// </summary>
    /// <value>
    /// An <see cref="int"/> with the relative weight indicating the amount
    /// of traffic the service should receive in the split.
    /// </value>
    [Required]
    [Description("Traffic weight value of this backend.")]
    [JsonProperty(PropertyName = "weight")]
    /*
    Using IntstrIntOrString here because the first version of the
    TrafficSplit spec...
    https://github.com/servicemeshinterface/smi-spec/blob/main/apis/traffic-split/v1alpha1/traffic-split.md
    ...defined weight as allowing resource-style definitions - 100m, for
    example, to indicate 0.1. After the first version of the spec that was
    abandoned but tools like Azure DevOps don't always pay attention and
    issue that old format instead of a number.
    */
    public IntstrIntOrString Weight { get; set; } = 0;
}

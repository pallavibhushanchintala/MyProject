using KubeOps.Operator.Entities.Annotations;
using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Status for <c>trafficsplits.split.smi-spec.io/v1alpha4</c>.
/// </summary>
public class TrafficSplitStatus
{
    /// <summary>
    /// Gets or sets the current state of the traffic split.
    /// </summary>
    /// <value>
    /// An <see cref="IList{T}"/> of the conditions to set in the traffic
    /// split status.
    /// </value>
    [Description("Current state of the traffic split.")]
    [JsonProperty(PropertyName = "conditions")]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public IList<TrafficSplitCondition> Conditions { get; set; } = new List<TrafficSplitCondition>();

    /// <summary>
    /// Adds or updates a condition in the <see cref="Conditions"/> collection by <see cref="TrafficSplitCondition.Type"/>.
    /// </summary>
    /// <param name="condition">
    /// The condition to add to the collection, or update if that condition type is already in the list.
    /// </param>
    public void AddOrUpdate(TrafficSplitCondition condition)
    {
        var found = this.Conditions.FirstOrDefault(c => string.Equals(c.Type, condition.Type, StringComparison.Ordinal));
        if (found != null)
        {
            this.Conditions.Remove(found);
        }

        this.Conditions.Add(condition);
    }
}

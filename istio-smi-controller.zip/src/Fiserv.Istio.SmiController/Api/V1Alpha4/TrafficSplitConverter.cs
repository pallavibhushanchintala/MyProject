using k8s;
using k8s.Models;
using KubeOps.Operator.Entities.Extensions;
using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Converts <see cref="TrafficSplit"/> into related Istio entities.
/// </summary>
public static class TrafficSplitConverter
{
    /// <summary>
    /// Converts a <see cref="TrafficSplit"/> into a <see cref="V1Beta1.VirtualService"/>.
    /// </summary>
    /// <param name="trafficSplit">
    /// The <see cref="TrafficSplit"/> to convert.
    /// </param>
    /// <returns>
    /// The <see cref="V1Beta1.VirtualService"/> equivalent of the <paramref name="trafficSplit"/>.
    /// </returns>
    public static V1Beta1.VirtualService ToV1Beta1VirtualService(TrafficSplit trafficSplit)
    {
        if (trafficSplit == null)
        {
            throw new ArgumentNullException(nameof(trafficSplit));
        }

        try
        {
            var weights = CalculateWeight(trafficSplit.Spec.Backends);
            var routes = trafficSplit.Spec.Backends
            .Select(backend => new V1Beta1.HttpRouteDestination
            {
                Destination = new()
                {
                    Host = backend.Service,
                },
                Weight = weights.TryGetValue(backend.Service, out var w) ? w : 0,
            })
            .Where(dest => dest.Weight > 0)
            .ToArray();

            // The owner of the VirtualService is the TrafficSplit. Deleting
            // the TrafficSplit will automatically garbage collect the
            // VirtualService.
            //
            // However, MakeOwnerReference doesn't set two
            // additional properties we need, and technically you can have
            // multiple owner references for each object. We want to declare
            // primary ownership.
            //
            // - blockOwnerDeletion: Ensures when things are getting garbage
            //   collected that the VirtualService will be deleted before
            //   the TrafficSplit is deleted.
            //   https://kubernetes.io/docs/concepts/architecture/garbage-collection/#foreground-deletion
            // - controller: Setting this stops other things in the cluster
            //   from claiming the VirtualService. Only one owner may have a
            //   'controller' set to 'true'.
            //   https://github.com/kubernetes/community/blob/master/contributors/design-proposals/api-machinery/controller-ref.md
            var owner = trafficSplit.MakeOwnerReference();
            owner.BlockOwnerDeletion = true;
            owner.Controller = true;

            var virtualService = new V1Beta1.VirtualService
            {
                Metadata = new()
                {
                    Name = $"{trafficSplit.Metadata.Name}-vs",
                    NamespaceProperty = trafficSplit.Metadata.NamespaceProperty,
                    Labels = new Dictionary<string, string>
                    {
                        { "traffic-split", trafficSplit.Metadata.Name },
                    },
                    OwnerReferences = new List<V1OwnerReference>
                    {
                        owner,
                    },
                },
                Spec = new()
                {
                    Gateways = ParseStringList(trafficSplit, TrafficSplitAnnotations.Gateways),
                    Hosts = ParseStringList(trafficSplit, TrafficSplitAnnotations.Hosts) ?? new[] { trafficSplit.Spec.Service },
                    Http = new V1Beta1.HttpRoute[]
                    {
                        new()
                        {
                            Route = routes,
                            Match = ParseJson<IEnumerable<V1Beta1.HttpMatchRequest>>(trafficSplit, TrafficSplitAnnotations.Match),
                        },
                    },
                },
            };

            var port = ParsePort(trafficSplit);
            if (port != null)
            {
                foreach (var route in virtualService.Spec.Http.Where(r => r.Route != null).SelectMany(r => r.Route ?? Array.Empty<V1Beta1.HttpRouteDestination>()))
                {
                    route.Destination.Port = new()
                    {
                        Number = port,
                    };
                }
            }

            return virtualService.Initialize();
        }
        catch (Exception ex)
        {
            throw new FormatException("Unable to convert TrafficSplit to VirtualService. See inner exception for details.", ex);
        }
    }

    private static Dictionary<string, int> CalculateWeight(IEnumerable<TrafficSplitBackend> backends)
    {
        var decimalWeights = backends.ToDictionary(item => item.Service, item => item.Weight.ToDecimal());
        var weights = new Dictionary<string, int>();
        var totalWeight = decimalWeights.Sum(item => item.Value);
        if (totalWeight == 0)
        {
            return weights;
        }

        var totalPercent = 0;
        var totalBackends = decimalWeights.Count;
        var index = 0;
        foreach (var backend in backends)
        {
            if (index == totalBackends - 1)
            {
                // The last service in the list takes the remaining
                // percentage to account for rounding issues.
                weights[backend.Service] = 100 - totalPercent;
            }
            else
            {
                // Round every service except the last one to the nearest
                // percentage based on the total quantity in the split.
                var percent = (int)Math.Round(decimalWeights[backend.Service] / totalWeight * 100, MidpointRounding.AwayFromZero);
                totalPercent += percent;
                weights[backend.Service] = percent;
            }

            index++;
        }

        return weights;
    }

    private static uint? ParsePort(TrafficSplit trafficSplit)
    {
        if (trafficSplit.Metadata?.Annotations == null ||
            !trafficSplit.Metadata.Annotations.TryGetValue(TrafficSplitAnnotations.Port, out var toParse) ||
            !uint.TryParse(toParse, out var parsed))
        {
            return default;
        }

        return parsed;
    }

    private static T? ParseJson<T>(TrafficSplit trafficSplit, string annotation)
    {
        if (trafficSplit.Metadata?.Annotations == null || !trafficSplit.Metadata.Annotations.TryGetValue(annotation, out var toParse))
        {
            return default;
        }

        return JsonConvert.DeserializeObject<T>(toParse);
    }

    private static IEnumerable<string>? ParseStringList(TrafficSplit trafficSplit, string annotation)
    {
        if (trafficSplit.Metadata?.Annotations == null || !trafficSplit.Metadata.Annotations.TryGetValue(annotation, out var toParse))
        {
            return null;
        }

        var values = toParse.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
        if (values.Length == 0)
        {
            return null;
        }

        return values;
    }
}

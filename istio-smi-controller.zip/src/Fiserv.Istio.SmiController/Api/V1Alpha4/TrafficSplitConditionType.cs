namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Well-known condition type constants used in <c>trafficsplits.split.smi-spec.io/v1alpha4</c> status.
/// </summary>
[ExcludeFromCodeCoverage]
public static class TrafficSplitConditionType
{
    /// <summary>
    /// The state of the associated virtual service.
    /// </summary>
    public static readonly string VirtualServiceUpdated = "VirtualServiceUpdated";
}

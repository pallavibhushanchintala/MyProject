using k8s.Models;
using KubeOps.Operator.Entities.Annotations;
using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Alpha4;

/// <summary>
/// Specification for <c>trafficsplits.split.smi-spec.io/v1alpha4</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class TrafficSplitSpec
{
    /// <summary>
    /// Gets or sets the root traffic split service.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the name of the service that clients
    /// will use to communicate with the backends.
    /// </value>
    [Required]
    [Description("The apex service of this split.")]
    [JsonProperty(PropertyName = "service")]
    public string Service { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the set of backends supporting the traffic split.
    /// </summary>
    /// <value>
    /// The set of services and relative weights that should take traffic
    /// when the root <see cref="Service"/> is requested.
    /// </value>
    [Required]
    [Description("The backend services of this split.")]
    [JsonProperty(PropertyName = "backends")]
    public IEnumerable<TrafficSplitBackend> Backends { get; set; } = Array.Empty<TrafficSplitBackend>();

    /// <summary>
    /// Gets or sets object references for user segment routing.
    /// </summary>
    /// <value>
    /// A set of <see cref="V1TypedLocalObjectReference"/> that can select
    /// an HTTP routing group or otherwise indicate a qualification that
    /// allows a user segment to be selected for this traffic split.
    /// </value>
    [Description("The HTTP route groups that this traffic split should match.")]
    [JsonProperty(PropertyName = "matches", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<V1TypedLocalObjectReference>? Matches
    {
        get; set;
    }
}

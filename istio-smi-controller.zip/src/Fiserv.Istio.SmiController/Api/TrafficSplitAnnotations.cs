namespace Fiserv.Istio.SmiController.Api;

/// <summary>
/// Annotation constants used for traffic split enhancement.
/// </summary>
public static class TrafficSplitAnnotations
{
    /// <summary>
    /// Annotation indicating the set of gateways to apply to the generated virtual service.
    /// </summary>
    public static readonly string Gateways = "istio.trafficsplit.smi-spec.io/gateways";

    /// <summary>
    /// Annotation indicating the set of hosts to apply to the generated virtual service.
    /// </summary>
    public static readonly string Hosts = "istio.trafficsplit.smi-spec.io/hosts";

    /// <summary>
    /// Annotation indicating the request match criteria to apply to the generated virtual service.
    /// </summary>
    public static readonly string Match = "istio.trafficsplit.smi-spec.io/match";

    /// <summary>
    /// Annotation indicating the specific port to which traffic should be directed in the generated virtual service.
    /// </summary>
    public static readonly string Port = "istio.trafficsplit.smi-spec.io/port";
}

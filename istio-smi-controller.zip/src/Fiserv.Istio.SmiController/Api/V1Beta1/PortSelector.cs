using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// Port selection for routing in <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class PortSelector
{
    /// <summary>
    /// Gets or sets a port number.
    /// </summary>
    /// <value>
    /// A valid port number for traffic routing.
    /// </value>
    [JsonProperty(PropertyName = "number", NullValueHandling = NullValueHandling.Ignore)]
    public uint? Number
    {
        get; set;
    }
}

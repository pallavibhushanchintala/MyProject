using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// HTTP traffic destination for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class HttpRouteDestination
{
    /// <summary>
    /// Gets or sets the destination service information.
    /// </summary>
    /// <returns>
    /// A <see cref="V1Beta1.Destination"/> that uniquely identifies the
    /// instances of a service to which the request/connection should be
    /// forwarded to.
    /// </returns>
    [JsonProperty(PropertyName = "destination")]
    public Destination Destination { get; set; } = new Destination();

    /// <summary>
    /// Gets or sets the proportion of traffic to send to the <see cref="Destination"/>.
    /// </summary>
    /// <value>
    /// The proportion of traffic to be forwarded to the service version.
    /// (0-100). Sum of weights across destinations SHOULD BE == 100. If
    /// there is only one destination in a rule, the weight value is assumed
    /// to be 100.
    /// </value>
    [JsonProperty(PropertyName = "weight", NullValueHandling = NullValueHandling.Ignore)]
    public int? Weight
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets header manipulation rules.
    /// </summary>
    /// <value>
    /// A <see cref="HeaderManipulationRules"/> with rules for manipulating headers
    /// in the request and response.
    /// </value>
    [JsonProperty(PropertyName = "headers", NullValueHandling = NullValueHandling.Ignore)]
    public HeaderManipulationRules? Headers
    {
        get; set;
    }
}

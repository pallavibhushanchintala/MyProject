using k8s.Models;
using KubeOps.Operator.Entities;
using KubeOps.Operator.Entities.Annotations;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// Istio <c>virtualservices.networking.istio.io/v1beta1</c> resource.
/// Primarily for serialization and reconciliation with SMI entities.
/// </summary>
/// <remarks>
/// <para>
/// The definition implemented here is not the literal complete definition
/// of everything Istio supports. Instead, it is only what the SMI
/// controller supports.
/// </para>
/// <para>
/// What this means is that when we deserialize the Istio virtual service
/// into this model, we will lose (intentionally) things that we don't
/// support. The controller assumes full control of the generated virtual
/// service - if the virtual service has something that isn't supported,
/// it's OK to drop. There's no notion of "merging" into an existing virtual
/// service.
/// </para>
/// </remarks>
[KubernetesEntity(
    Group = "networking.istio.io",
    ApiVersion = "v1beta1",
    Kind = "VirtualService",
    PluralName = "virtualservices")]
[IgnoreEntity]
[ExcludeFromCodeCoverage]
public class VirtualService : CustomKubernetesEntity<VirtualServiceSpec>
{
}

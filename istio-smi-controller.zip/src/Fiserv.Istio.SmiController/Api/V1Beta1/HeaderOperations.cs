using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// Header manipulations to apply in <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class HeaderOperations
{
    /// <summary>
    /// Gets or sets headers to overwrite.
    /// </summary>
    /// <value>
    /// A <see cref="Dictionary{K,V}"/> with header names/values to
    /// overwrite in the request or response.
    /// </value>
    [JsonProperty(PropertyName = "set", NullValueHandling = NullValueHandling.Ignore)]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public Dictionary<string, string>? SetHeaders
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets headers to add.
    /// </summary>
    /// <value>
    /// A <see cref="Dictionary{K,V}"/> with header names/values to add to
    /// the request or response.
    /// </value>
    [JsonProperty(PropertyName = "add", NullValueHandling = NullValueHandling.Ignore)]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public Dictionary<string, string>? AddHeaders
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets headers to remove.
    /// </summary>
    /// <value>
    /// A list of header names to remove from the request or response.
    /// </value>
    [JsonProperty(PropertyName = "remove", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<string>? RemoveHeaders
    {
        get; set;
    }
}

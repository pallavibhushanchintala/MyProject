using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// Specification for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class VirtualServiceSpec
{
    /// <summary>
    /// Gets or sets the list of destination hosts.
    /// </summary>
    /// <value>
    /// An <see cref="IEnumerable{T}"/> of the set of hosts to which traffic
    /// is being sent. Could be a DNS name with wildcard prefix or an IP
    /// address. Depending on the platform, short-names can also be used
    /// instead of a FQDN (i.e. has no dots in the name). In such a
    /// scenario, the FQDN of the host would be derived based on the
    /// underlying platform.
    /// </value>
    [JsonProperty(PropertyName = "hosts", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<string>? Hosts
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the list of gateways to apply these routes.
    /// </summary>
    /// <value>
    /// An <see cref="IEnumerable{T}"/> of the set of gateways and sidecars
    /// that should apply these routes. Gateways in other namespaces may be
    /// referred to by
    /// <c>&amp;lt;gateway namespace&amp;gt;/&amp;lt;gateway name&amp;gt;</c>;
    /// specifying a gateway with no namespace qualifier is the same as
    /// specifying the VirtualService’s namespace.
    /// </value>
    [JsonProperty(PropertyName = "gateways", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<string>? Gateways
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the list of route rules for HTTP traffic.
    /// </summary>
    /// <value>
    /// An ordered <see cref="IEnumerable{T}"/> of route rules for HTTP
    /// traffic. HTTP routes will be applied to platform service ports named
    /// ‘http-’/‘http2-’/‘grpc-*’, gateway ports with protocol HTTP / HTTP2
    /// / GRPC / TLS-terminated-HTTPS and service entry ports using HTTP /
    /// HTTP2 / GRPC protocols. The first rule matching an incoming request
    /// is used.
    /// </value>
    [JsonProperty(PropertyName = "http", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<HttpRoute>? Http
    {
        get; set;
    }
}

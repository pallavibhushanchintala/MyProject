using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// Specific service destination for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class Destination
{
    /// <summary>
    /// Gets or sets the host name of the service to receive traffic.
    /// </summary>
    /// <value>
    /// The name of a service from the service registry. Service names are
    /// looked up from the platform’s service registry (e.g., Kubernetes
    /// services, Consul services, etc.) and from the hosts declared by
    /// <c>ServiceEntry</c>. Traffic forwarded to destinations that are not
    /// found in either of the two will be dropped.
    /// </value>
    [JsonProperty(PropertyName = "host")]
    public string Host { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the name of a <c>DestinationRule</c> for traffic
    /// filtering.
    /// </summary>
    /// <value>
    /// The name of a subset within the service. Applicable only to services
    /// within the mesh. The subset must be defined in a corresponding
    /// <c>DestinationRule</c>.
    /// </value>
    [JsonProperty(PropertyName = "subset", NullValueHandling = NullValueHandling.Ignore)]
    public string? Subset
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the port being addressed.
    /// </summary>
    /// <value>
    /// Specifies the port on the host that is being addressed. If a service
    /// exposes only a single port it is not required to explicitly select
    /// the port.
    /// </value>
    [JsonProperty(PropertyName = "port", NullValueHandling = NullValueHandling.Ignore)]
    public PortSelector? Port
    {
        get; set;
    }
}

using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// HTTP routing definition for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class HttpRoute
{
    /// <summary>
    /// Gets or sets the route name.
    /// </summary>
    /// <value>
    /// The name assigned to the route for debugging purposes. The route’s
    /// name will be concatenated with the match’s name and will be logged
    /// in the access logs for requests matching this route/match.
    /// </value>
    [JsonProperty(PropertyName = "name", NullValueHandling = NullValueHandling.Ignore)]
    public string? Name
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the conditions for the rule to be activated.
    /// </summary>
    /// <value>
    /// Match conditions to be satisfied for the rule to be activated. All
    /// conditions inside a single match block have AND semantics, while the
    /// list of match blocks have OR semantics. The rule is matched if any
    /// one of the match blocks succeed.
    /// </value>
    [JsonProperty(PropertyName = "match", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<HttpMatchRequest>? Match
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the service targets and weights to receive traffic.
    /// </summary>
    /// <value>
    /// An <see cref="IEnumerable{T}"/> of the rules indicating where
    /// traffic should flow. A HTTP rule can either redirect or forward
    /// (default) traffic. The forwarding target can be one of several
    /// versions of a service. Weights associated with the service version
    /// determine the proportion of traffic it receives.
    /// </value>
    [JsonProperty(PropertyName = "route", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<HttpRouteDestination>? Route
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets header manipulation rules.
    /// </summary>
    /// <value>
    /// A <see cref="HeaderManipulationRules"/> with rules for manipulating headers
    /// in the request and response.
    /// </value>
    [JsonProperty(PropertyName = "headers", NullValueHandling = NullValueHandling.Ignore)]
    public HeaderManipulationRules? Headers
    {
        get; set;
    }
}

using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// HTTP rule matcher for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class HttpMatchRequest
{
    /// <summary>
    /// Gets or sets the match name.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the name of the match. The match’s name
    /// will be concatenated with the parent route’s name and will be logged
    /// in the access logs for requests matching this route.
    /// </value>
    [JsonProperty(PropertyName = "name", NullValueHandling = NullValueHandling.Ignore)]
    public string? Name
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the URI match value.
    /// </summary>
    /// <value>
    /// A <see cref="StringMatch"/> indicating the manner in which to match the URI.
    /// </value>
    [JsonProperty(PropertyName = "uri", NullValueHandling = NullValueHandling.Ignore)]
    public StringMatch? Uri
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the scheme match value.
    /// </summary>
    /// <value>
    /// A <see cref="StringMatch"/> indicating the manner in which to match the protocol scheme.
    /// </value>
    [JsonProperty(PropertyName = "scheme", NullValueHandling = NullValueHandling.Ignore)]
    public StringMatch? Scheme
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the HTTP method match value.
    /// </summary>
    /// <value>
    /// A <see cref="StringMatch"/> indicating the manner in which to match the HTTP method in the request.
    /// </value>
    [JsonProperty(PropertyName = "method", NullValueHandling = NullValueHandling.Ignore)]
    public StringMatch? Method
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the authority match value.
    /// </summary>
    /// <value>
    /// A <see cref="StringMatch"/> indicating the manner in which to match the authority in the URI.
    /// </value>
    [JsonProperty(PropertyName = "authority", NullValueHandling = NullValueHandling.Ignore)]
    public StringMatch? Authority
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the header match values.
    /// </summary>
    /// <value>
    /// A <see cref="Dictionary{K,V}"/> where the key is a header name
    /// (lowercase, hyphen separators) and the value is a
    /// <see cref="StringMatch"/> indicating the manner in which to match
    /// the header value.
    /// </value>
    [JsonProperty(PropertyName = "headers", NullValueHandling = NullValueHandling.Ignore)]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public Dictionary<string, StringMatch>? Headers
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the port being addressed.
    /// </summary>
    /// <value>
    /// Specifies the ports on the host that is being addressed. Many
    /// services only expose a single port or label ports with the protocols
    /// they support, in these cases it is not required to explicitly select
    /// the port.
    /// </value>
    [JsonProperty(PropertyName = "port", NullValueHandling = NullValueHandling.Ignore)]
    public uint? Port
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the labels for workload constraint.
    /// </summary>
    /// <value>
    /// One or more labels that constrain the applicability of a rule to
    /// source (client) workloads with the given labels. If the
    /// <see cref="VirtualServiceSpec.Gateways"/> are specified at the top
    /// level, it must include the reserved gateway "mesh" for this field to
    /// be applicable.
    /// </value>
    [JsonProperty(PropertyName = "sourceLabels", NullValueHandling = NullValueHandling.Ignore)]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public Dictionary<string, string>? SourceLabels
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets override gateways for this match request.
    /// </summary>
    /// <value>
    /// Names of gateways where the rule should be applied. Gateway names in
    /// the top-level <see cref="VirtualServiceSpec.Gateways"/> field (if
    /// any) are overridden. The gateway match is independent of
    /// <see cref="SourceLabels"/>.
    /// </value>
    [JsonProperty(PropertyName = "gateways", NullValueHandling = NullValueHandling.Ignore)]
    public IEnumerable<string>? Gateways
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the query parameters to match.
    /// </summary>
    /// <value>
    /// A <see cref="Dictionary{K,V}"/> where the key is a parameter name
    /// and the value is a <see cref="StringMatch"/> indicating the manner
    /// in which to match the parameter value.
    /// </value>
    [JsonProperty(PropertyName = "queryParams", NullValueHandling = NullValueHandling.Ignore)]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public Dictionary<string, StringMatch>? QueryParameters
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets a value indicating whether URI matching should be
    /// case-insensitive.
    /// </summary>
    /// <value>
    /// A <see cref="bool"/> to specify whether the URI matching should be
    /// case-insensitive. The case will be ignored only in the case of exact
    /// and prefix URI matches.
    /// </value>
    [JsonProperty(PropertyName = "ignoreUriCase", NullValueHandling = NullValueHandling.Ignore)]
    public bool? IgnoreUriCase
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the header anti-match values. Only allows a request to
    /// match this rule if it does NOT match any of these headers.
    /// </summary>
    /// <value>
    /// A <see cref="Dictionary{K,V}"/> where the key is a header name
    /// (lowercase, hyphen separators) and the value is a
    /// <see cref="StringMatch"/> indicating the manner in which to match
    /// the header value.
    /// </value>
    [JsonProperty(PropertyName = "withoutHeaders", NullValueHandling = NullValueHandling.Ignore)]
    [SuppressMessage("CA2227", "CA2227", Justification = "Property needs to be nullable and settable for serialization.")]
    public Dictionary<string, StringMatch>? WithoutHeaders
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets the source namespace to constrain the rule.
    /// </summary>
    /// <value>
    /// Source namespace constraining the applicability of a rule to
    /// workloads in that namespace. If the
    /// <see cref="VirtualServiceSpec.Gateways"/> are specified at the top
    /// level, it must include the reserved gateway "mesh" for this field to
    /// be applicable.
    /// </value>
    [JsonProperty(PropertyName = "sourceNamespace", NullValueHandling = NullValueHandling.Ignore)]
    public string? SourceNamespace
    {
        get; set;
    }
}

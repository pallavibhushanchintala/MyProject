using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// Request and response header manipulations for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
[ExcludeFromCodeCoverage]
public class HeaderManipulationRules
{
    /// <summary>
    /// Gets or sets request header manipulation rules.
    /// </summary>
    /// <value>
    /// Header manipulation rules to apply before forwarding a request to the destination service.
    /// </value>
    [JsonProperty(PropertyName = "request", NullValueHandling = NullValueHandling.Ignore)]
    public HeaderOperations? Request
    {
        get; set;
    }

    /// <summary>
    /// Gets or sets response header manipulation rules.
    /// </summary>
    /// <value>
    /// Header manipulation rules to apply before returning a response to the caller.
    /// </value>
    [JsonProperty(PropertyName = "response", NullValueHandling = NullValueHandling.Ignore)]
    public HeaderOperations? Response
    {
        get; set;
    }
}

using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Api.V1Beta1;

/// <summary>
/// String match definition for <c>virtualservices.networking.istio.io/v1beta1</c>.
/// </summary>
/// <remarks>
/// <para>
/// The properties here are mutually-exclusive: only one can be specified at
/// a time. Setting any one of the properties clears out the others.
/// </para>
/// </remarks>
public class StringMatch
{
    private string? _exact;
    private string? _prefix;
    private string? _regex;

    /// <summary>
    /// Gets or sets the exact match value.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating a value to match exactly.
    /// </value>
    [JsonProperty(PropertyName = "exact", NullValueHandling = NullValueHandling.Ignore)]
    public string? Exact
    {
        get => this._exact;
        set
        {
            if (value != null)
            {
                this._prefix = null;
                this._regex = null;
            }

            this._exact = value;
        }
    }

    /// <summary>
    /// Gets or sets the prefix match value.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating a match should be successful if the comparison value starts with this.
    /// </value>
    [JsonProperty(PropertyName = "prefix", NullValueHandling = NullValueHandling.Ignore)]
    public string? Prefix
    {
        get => this._prefix;
        set
        {
            if (value != null)
            {
                this._exact = null;
                this._regex = null;
            }

            this._prefix = value;
        }
    }

    /// <summary>
    /// Gets or sets the regex match value.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> indicating a match should be successful if compared using this value as a regular expression.
    /// </value>
    [JsonProperty(PropertyName = "regex", NullValueHandling = NullValueHandling.Ignore)]
    public string? Regex
    {
        get => this._regex;
        set
        {
            if (value != null)
            {
                this._prefix = null;
                this._exact = null;
            }

            this._regex = value;
        }
    }

    /// <summary>
    /// Custom serialization support to determine whether to serialize
    /// <see cref="Exact"/>.
    /// </summary>
    /// <returns>
    /// <see langword="true"/> if <see cref="Exact"/> should be serialized;
    /// otherwise <see langword="false"/>.
    /// </returns>
    public bool ShouldSerializeExact() => this.Exact != null && this.Prefix == null && this.Regex == null;

    /// <summary>
    /// Custom serialization support to determine whether to serialize
    /// <see cref="Prefix"/>.
    /// </summary>
    /// <returns>
    /// <see langword="true"/> if <see cref="Prefix"/> should be serialized;
    /// otherwise <see langword="false"/>.
    /// </returns>
    public bool ShouldSerializePrefix() => this.Exact == null && this.Prefix != null && this.Regex == null;

    /// <summary>
    /// Custom serialization support to determine whether to serialize
    /// <see cref="Regex"/>.
    /// </summary>
    /// <returns>
    /// <see langword="true"/> if <see cref="Regex"/> should be serialized;
    /// otherwise <see langword="false"/>.
    /// </returns>
    public bool ShouldSerializeRegex() => this.Exact == null && this.Prefix == null && this.Regex != null;
}

using Autofac.Extensions.DependencyInjection;
using KubeOps.Operator;
using Serilog;

namespace Fiserv.Istio.SmiController;

/// <summary>
/// Main entry point for the controller.
/// </summary>
[ExcludeFromCodeCoverage]
public static class Program
{
    /// <summary>
    /// Creates the service host for the controller.
    /// </summary>
    /// <param name="args">
    /// The command line arguments to provide to the host.
    /// </param>
    /// <returns>
    /// An <see cref="IHostBuilder"/> for continued configuration and execution.
    /// </returns>
    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .UseServiceProviderFactory(new AutofacServiceProviderFactory())
            .UseSerilog()
            .ConfigureWebHostDefaults(webBuilder => webBuilder.UseStartup<Startup>());

    /// <summary>
    /// Main entry point for the controller.
    /// </summary>
    /// <param name="args">
    /// The command line arguments to provide to the host.
    /// </param>
    /// <returns>
    /// A <see cref="Task"/> to await completion of the program.
    /// </returns>
    public static async Task Main(string[] args)
    {
        await CreateHostBuilder(args).Build().RunOperatorAsync(args);
    }
}

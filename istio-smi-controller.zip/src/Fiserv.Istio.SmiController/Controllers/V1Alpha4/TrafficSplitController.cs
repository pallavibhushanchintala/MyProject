using DotnetKubernetesClient;
using Fiserv.Istio.SmiController.Api;
using Fiserv.Istio.SmiController.Api.V1Alpha4;
using Fiserv.Istio.SmiController.Api.V1Beta1;
using KellermanSoftware.CompareNetObjects;
using KubeOps.Operator.Controller;
using KubeOps.Operator.Controller.Results;
using KubeOps.Operator.Rbac;

namespace Fiserv.Istio.SmiController.Controllers.V1Alpha4;

/// <summary>
/// Entity controller for managing <see cref="TrafficSplit"/> objects.
/// </summary>
/// <remarks>
/// <para>
/// This controller handles created, updated, and not-modified events,
/// treating all of them as the application of desired state. Regardless of
/// event, the desired vs. current state is checked and if there's a
/// difference, that difference is applied.
/// </para>
/// <para>
/// Delete events are not handled because the generated Istio virtual
/// service gets marked with an ownership reference such that if the <see
/// cref="TrafficSplit"/> is deleted, Kubernetes garbage collection will
/// automatically clean up the generated virtual service without any effort
/// here.
/// </para>
/// </remarks>
[EntityRbac(typeof(TrafficSplit), Verbs = RbacVerb.All)]
[EntityRbac(typeof(VirtualService), Verbs = RbacVerb.All)]
public class TrafficSplitController : IResourceController<TrafficSplit>
{
    /// <summary>
    /// Deep equality comparer for detecting differences between the desired
    /// and current states. Default behavior will only capture the first
    /// difference in compared objects, which is fine because we only need
    /// to know if they're equal.
    /// </summary>
    private static readonly CompareLogic DeepComparer;

    [SuppressMessage("CA1810", "CA1810", Justification = "Not able to instantiate nested property values without a constructor.")]
    static TrafficSplitController()
    {
        DeepComparer = new();

        // Allow weird serialization differences, like in memory
        // IEnumerable<T> might be backed by List<T> but when deserialized
        // it's T[].
        DeepComparer.Config.IgnoreObjectTypes = true;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="TrafficSplitController"/> class.
    /// </summary>
    /// <param name="logger">
    /// An <see cref="ILogger{T}"/> used for writing diagnostic messages.
    /// </param>
    /// <param name="client">
    /// An <see cref="IKubernetesClient"/> used for accessing the Kubernetes API.
    /// </param>
    public TrafficSplitController(ILogger<TrafficSplitController> logger, IKubernetesClient client)
    {
        this.Logger = logger ?? throw new ArgumentNullException(nameof(logger));
        this.Client = client ?? throw new ArgumentNullException(nameof(client));
    }

    /// <summary>
    /// Gets the Kubernetes API client.
    /// </summary>
    /// <value>
    /// An <see cref="IKubernetesClient"/> used for accessing the Kubernetes API.
    /// </value>
    public IKubernetesClient Client
    {
        get;
    }

    /// <summary>
    /// Gets the diagnostic logger.
    /// </summary>
    /// <value>
    /// An <see cref="ILogger{T}"/> used for writing diagnostic messages.
    /// </value>
    public ILogger<TrafficSplitController> Logger
    {
        get;
    }

    /// <inheritdoc />
    [ExcludeFromCodeCoverage(Justification = "Testing the reconcile handler directly: https://github.com/buehler/dotnet-operator-sdk/issues/282")]
    public async Task<ResourceControllerResult?> CreatedAsync(TrafficSplit entity)
    {
        if (entity == null)
        {
            throw new ArgumentNullException(nameof(entity));
        }

        this.Logger.LogChangeEvent("Created", entity.Metadata.Name, entity.Metadata.NamespaceProperty);
        await this.ReconcileAsync(entity);
        return null;
    }

    /// <inheritdoc />
    [ExcludeFromCodeCoverage(Justification = "Testing the reconcile handler directly: https://github.com/buehler/dotnet-operator-sdk/issues/282")]
    public async Task<ResourceControllerResult?> UpdatedAsync(TrafficSplit entity)
    {
        if (entity == null)
        {
            throw new ArgumentNullException(nameof(entity));
        }

        this.Logger.LogChangeEvent("Updated", entity.Metadata.Name, entity.Metadata.NamespaceProperty);
        await this.ReconcileAsync(entity);
        return null;
    }

    /// <inheritdoc />
    [ExcludeFromCodeCoverage(Justification = "Testing the reconcile handler directly: https://github.com/buehler/dotnet-operator-sdk/issues/282")]
    public async Task<ResourceControllerResult?> NotModifiedAsync(TrafficSplit entity)
    {
        if (entity == null)
        {
            throw new ArgumentNullException(nameof(entity));
        }

        // This is needed in case someone mucks with the VirtualService directly. This is basically "ensure desired state is still there."
        this.Logger.LogChangeEvent("Not Modified", entity.Metadata.Name, entity.Metadata.NamespaceProperty);
        await this.ReconcileAsync(entity);
        return null;
    }

    /// <summary>
    /// Primary reconciliation loop for create, update, and not-modified events. Applies desired state of virtual service.
    /// </summary>
    /// <param name="entity">
    /// The <see cref="TrafficSplit"/> containing the desired state of the virtual service.
    /// </param>
    /// <returns>
    /// A <see cref="Task"/> to await completion.
    /// </returns>
    public async Task ReconcileAsync(TrafficSplit entity)
    {
        if (entity == null)
        {
            throw new ArgumentNullException(nameof(entity));
        }

        try
        {
            VirtualService desired;
            try
            {
                desired = TrafficSplitConverter.ToV1Beta1VirtualService(entity);
            }
            catch (FormatException ex)
            {
                this.Logger.LogConversionError(ex);
                await this.SafeUpdateStatusAsync(
                    entity,
                    TrafficSplitConditionType.VirtualServiceUpdated,
                    ConditionStatus.False,
                    TrafficSplitConditionReason.Error,
                    $"Unable to convert traffic split into virtual service: {ex.Message}");
                return;
            }

            this.Logger.LogFindingVirtualService(desired.Metadata.NamespaceProperty, desired.Metadata.Name);
            var current = await this.Client.Get<VirtualService>(desired.Metadata.Name, desired.Metadata.NamespaceProperty);

            // The main managed resource controller which invokes our loop has a
            // top-level catch/log/retry built in.
            // https://github.com/buehler/dotnet-operator-sdk/blob/5a831aedc7eed457eca9e97b5f6e7e6a459cc483/src/KubeOps/Operator/Controller/ManagedResourceController%7BTEntity%7D.cs#L261
            // We don't need to do that manually here.
            ComparisonResult result;
            if (current == null)
            {
                this.Logger.LogCreatingVirtualService(desired.Metadata.NamespaceProperty, desired.Metadata.Name);
                await this.SafeUpdateStatusAsync(
                    entity,
                    TrafficSplitConditionType.VirtualServiceUpdated,
                    ConditionStatus.False,
                    TrafficSplitConditionReason.Progressing,
                    $"Creating virtual service {desired.Metadata.NamespaceProperty}/{desired.Metadata.Name}.");
                await this.Client.Create(desired);
                await this.SafeUpdateStatusAsync(
                    entity,
                    TrafficSplitConditionType.VirtualServiceUpdated,
                    ConditionStatus.True,
                    TrafficSplitConditionReason.Completed,
                    $"Virtual service {desired.Metadata.NamespaceProperty}/{desired.Metadata.Name} created.");
            }
            else if (!OwnerMatches(desired, current))
            {
                // If the owner doesn't match (that is, if there's a controller and it's not us) then we can't update it.
                // https://github.com/kubernetes/community/blob/master/contributors/design-proposals/api-machinery/controller-ref.md
                this.Logger.LogServiceOwnedByDifferentController(desired.Metadata.NamespaceProperty, desired.Metadata.Name, entity.Metadata.Name);
                await this.SafeUpdateStatusAsync(
                    entity,
                    TrafficSplitConditionType.VirtualServiceUpdated,
                    ConditionStatus.False,
                    TrafficSplitConditionReason.Error,
                    $"Operator is not the owner of virtual service {desired.Metadata.NamespaceProperty}/{desired.Metadata.Name}.");
            }
            else if (!(result = DeepComparer.Compare(desired.Spec, current.Spec)).AreEqual)
            {
                this.Logger.LogServiceHasDifference(desired.Metadata.NamespaceProperty, desired.Metadata.Name);
                this.Logger.LogServiceDifferenceDetails(result.DifferencesString);

                // We need to keep the metadata in place (e.g., resource version, ID).
                current.Spec = desired.Spec;

                // Merge labels.
                foreach (var item in desired.Metadata.Labels)
                {
                    current.Metadata.Labels[item.Key] = item.Value;
                }

                await this.SafeUpdateStatusAsync(
                    entity,
                    TrafficSplitConditionType.VirtualServiceUpdated,
                    ConditionStatus.False,
                    TrafficSplitConditionReason.Progressing,
                    $"Updating virtual service {desired.Metadata.NamespaceProperty}/{desired.Metadata.Name}.");
                await this.Client.Update(current);
                await this.SafeUpdateStatusAsync(
                    entity,
                    TrafficSplitConditionType.VirtualServiceUpdated,
                    ConditionStatus.True,
                    TrafficSplitConditionReason.Completed,
                    $"Virtual service {desired.Metadata.NamespaceProperty}/{desired.Metadata.Name} updated.");
            }
            else
            {
                this.Logger.LogNoChangeRequired(desired.Metadata.NamespaceProperty, desired.Metadata.Name);
            }
        }
        catch (Exception ex)
        {
            await this.SafeUpdateStatusAsync(
                entity,
                TrafficSplitConditionType.VirtualServiceUpdated,
                ConditionStatus.False,
                TrafficSplitConditionReason.Error,
                $"Exception: {ex.Message}");
            throw;
        }
    }

    private static bool OwnerMatches(VirtualService desired, VirtualService current)
    {
        var currentOwner = current.Metadata.OwnerReferences?.FirstOrDefault(o => o.Controller == true);
        if (currentOwner == null)
        {
            // There's NO owner, so it's not something we created.
            return false;
        }

        // This will definitely be here because we set it.
        var desiredOwner = desired.Metadata.OwnerReferences.First(o => o.Controller == true);

        // All the properties must match - names, types, IDs.
        return DeepComparer.Compare(desiredOwner, currentOwner).AreEqual;
    }

    [SuppressMessage("CA1031", "CA1031", Justification = "We can't fail if the update fails - we need to log and continue.")]
    private async Task SafeUpdateStatusAsync(TrafficSplit entity, string type, string status, string reason, string? message = null)
    {
        var condition = new TrafficSplitCondition
        {
            LastTransitionTime = DateTime.UtcNow,
            Message = message,
            Reason = reason,
            Status = status,
            Type = type,
        };

        entity.Status.AddOrUpdate(condition);
        try
        {
            await this.Client.UpdateStatus(entity);
        }
        catch (Exception ex)
        {
            this.Logger.LogStatusUpdateError(entity.Metadata.NamespaceProperty, entity.Metadata.Name, ex);
        }
    }
}

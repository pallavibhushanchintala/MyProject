namespace Fiserv.Istio.SmiController.Controllers.V1Alpha4;

/// <summary>
/// Logging extensions for the <see cref="TrafficSplitController"/>.
/// </summary>
[ExcludeFromCodeCoverage]
internal static class LoggerExtensions
{
    private static readonly Action<ILogger, string, string, string, Exception?> ChangeEventDelegate = LoggerMessage.Define<string, string, string>(LogLevel.Debug, new EventId(0), "{Event}: {Name} in {Namespace}");

    private static readonly Action<ILogger, Exception?> ConversionErrorDelegate = LoggerMessage.Define(LogLevel.Error, new EventId(0), "Unable to convert traffic split into virtual service. See the inner exception messages for details.");

    private static readonly Action<ILogger, string, string, Exception?> CreatingVirtualServiceDelegate = LoggerMessage.Define<string, string>(LogLevel.Information, new EventId(0), "Virtual service {Namespace}/{Name} not found; adding the service.");

    private static readonly Action<ILogger, string, string, Exception?> FindingVirtualServiceDelegate = LoggerMessage.Define<string, string>(LogLevel.Debug, new EventId(0), "Looking for virtual service {Namespace}/{Name} for reconciliation.");

    private static readonly Action<ILogger, string, string, Exception?> NoChangeRequiredDelegate = LoggerMessage.Define<string, string>(LogLevel.Debug, new EventId(0), "Virtual service {Namespace}/{Name} found and matches desired state. No action required.");

    private static readonly Action<ILogger, string, Exception?> ServiceDifferenceDetailsDelegate = LoggerMessage.Define<string>(LogLevel.Debug, new EventId(0), "Difference found: {Difference}");

    private static readonly Action<ILogger, string, string, Exception?> ServiceHasDifferenceDelegate = LoggerMessage.Define<string, string>(LogLevel.Information, new EventId(0), "Virtual service {Namespace}/{Name} found but does not match desired state; updating the service.");

    private static readonly Action<ILogger, string, string, string, Exception?> ServiceOwnedByDifferentControllerDelegate = LoggerMessage.Define<string, string, string>(LogLevel.Warning, new EventId(0), "Virtual service {Namespace}/{Name} found but it is not owned by the expected traffic split {SplitName}. Unable to update.");

    private static readonly Action<ILogger, string, string, Exception?> StatusUpdateErrorDelegate = LoggerMessage.Define<string, string>(LogLevel.Error, new EventId(0), "Unable to update traffic split {Namespace}/{Name} status.");

    /// <summary>
    /// Log that a change event was detected.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="eventName">
    /// The name of the event that was raised.
    /// </param>
    /// <param name="entityName">
    /// The name of the entity raising the event.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace in which the entity is deployed.
    /// </param>
    public static void LogChangeEvent(this ILogger logger, string eventName, string entityName, string entityNamespace)
    {
        ChangeEventDelegate(logger, eventName, entityName, entityNamespace, null);
    }

    /// <summary>
    /// Log an error that happened during conversion from traffic split to virtual service.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="ex">
    /// The exception with the error that occurred.
    /// </param>
    public static void LogConversionError(this ILogger logger, Exception ex)
    {
        ConversionErrorDelegate(logger, ex);
    }

    /// <summary>
    /// Log that a new virtual service is being created.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="entityName">
    /// The name of the new virtual service.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace of the new virtual service.
    /// </param>
    public static void LogCreatingVirtualService(this ILogger logger, string entityName, string entityNamespace)
    {
        CreatingVirtualServiceDelegate(logger, entityName, entityNamespace, null);
    }

    /// <summary>
    /// Log that a virtual service is being located so its status can be reconciled.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="entityName">
    /// The name of the virtual service being located.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace of the virtual service being located.
    /// </param>
    public static void LogFindingVirtualService(this ILogger logger, string entityName, string entityNamespace)
    {
        FindingVirtualServiceDelegate(logger, entityName, entityNamespace, null);
    }

    /// <summary>
    /// Logs that there are no changes required on a virtual service.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="entityName">
    /// The name of the virtual service.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace of the virtual service.
    /// </param>
    public static void LogNoChangeRequired(this ILogger logger, string entityName, string entityNamespace)
    {
        NoChangeRequiredDelegate(logger, entityName, entityNamespace, null);
    }

    /// <summary>
    /// Logs the details of a difference found between current and desired state for a virtual service.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="difference">
    /// The difference detected.
    /// </param>
    public static void LogServiceDifferenceDetails(this ILogger logger, string difference)
    {
        ServiceDifferenceDetailsDelegate(logger, difference, null);
    }

    /// <summary>
    /// Logs that there are changes required on a virtual service - its current state differs from desired state.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="entityName">
    /// The name of the virtual service.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace of the virtual service.
    /// </param>
    public static void LogServiceHasDifference(this ILogger logger, string entityName, string entityNamespace)
    {
        ServiceHasDifferenceDelegate(logger, entityName, entityNamespace, null);
    }

    /// <summary>
    /// Logs that a virtual service is owned by a different traffic split than expected so this controller can't make changes.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="entityName">
    /// The name of the virtual service.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace of the virtual service.
    /// </param>
    /// <param name="splitName">
    /// The name of the traffic split that owns the virtual service.
    /// </param>
    public static void LogServiceOwnedByDifferentController(this ILogger logger, string entityName, string entityNamespace, string splitName)
    {
        ServiceOwnedByDifferentControllerDelegate(logger, entityName, entityNamespace, splitName, null);
    }

    /// <summary>
    /// Logs that the status of a virtual service can't be updated.
    /// </summary>
    /// <param name="logger">
    /// The diagnostic logger.
    /// </param>
    /// <param name="entityName">
    /// The name of the virtual service.
    /// </param>
    /// <param name="entityNamespace">
    /// The namespace of the virtual service.
    /// </param>
    /// <param name="ex">
    /// The error that occurred during status update.
    /// </param>
    public static void LogStatusUpdateError(this ILogger logger, string entityName, string entityNamespace, Exception ex)
    {
        StatusUpdateErrorDelegate(logger, entityName, entityNamespace, ex);
    }
}

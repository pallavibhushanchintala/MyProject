using System.Diagnostics.CodeAnalysis;
using System.Linq.Expressions;
using DotnetKubernetesClient;
using Fiserv.Istio.SmiController.Api;
using Fiserv.Istio.SmiController.Api.V1Alpha4;
using Fiserv.Istio.SmiController.Controllers.V1Alpha4;
using k8s;
using Microsoft.Extensions.Logging;
using V1B1 = Fiserv.Istio.SmiController.Api.V1Beta1;

namespace Fiserv.Istio.SmiController.Test.Controllers.V1Alpha4;

// Not using the KubernetesObjectFactory testing support here due to
// challenges in making it work with parallel tests and mocking the
// Kubernetes client.
// https://github.com/buehler/dotnet-operator-sdk/issues/282
//
// When testing status updates, we can only test that the LAST status was
// called because the `Verify` calls don't look at the state of the object
// at the time of the original call, it looks at the object at the time the
// `Verify` executes.
[SuppressMessage("CA2252", "CA2252", Justification = "False positive: https://github.com/dotnet/roslyn-analyzers/issues/5366")]
public class TrafficSplitControllerTests
{
    [Fact]
    public async Task ReconcileAsync_NullTrafficSplit()
    {
        var controller = CreateController();
        await Assert.ThrowsAsync<ArgumentNullException>(async () => await controller.ReconcileAsync(null!));
    }

    [Fact]
    public async Task ReconcileAsync_BackingTypesMayChange()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);

        // We use List<T> or T[] usually; using a Stack<T> here
        // shows that we don't really care about the backing type
        // of IEnumerable<T>.
        var route = foundVirtualService.Spec.Http!.First();
        var stack = new Stack<V1B1.HttpRoute>();
        stack.Push(route);
        foundVirtualService.Spec.Http = stack;

        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);

        // There's no substantive difference.
        mockClient.Verify(x => x.Create(It.IsAny<V1B1.VirtualService>()), Times.Never);
        mockClient.Verify(x => x.Update(It.IsAny<V1B1.VirtualService>()), Times.Never);
    }

    [Fact]
    public async Task ReconcileAsync_ErrorConvertingSplit()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Metadata.Annotations ??= new Dictionary<string, string>();
        split.Metadata.Annotations[TrafficSplitAnnotations.Match] = "[invalid-json";
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);

        // We own it but we couldn't convert the new TrafficSplit so - no change.
        mockClient.Verify(x => x.Create(It.IsAny<V1B1.VirtualService>()), Times.Never);
        mockClient.Verify(x => x.Update(It.IsAny<V1B1.VirtualService>()), Times.Never);

        // Final status should indicate there's an error.
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.False, TrafficSplitConditionReason.Error))));
    }

    [Fact]
    public async Task ReconcileAsync_ExceptionUpdatesStatus()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        foundVirtualService.Spec.Hosts = new[] { "host-should-get-reset" };
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).Throws(new DivideByZeroException());
        await Assert.ThrowsAsync<DivideByZeroException>(async () => await controller.ReconcileAsync(split));
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.False, TrafficSplitConditionReason.Error))));
    }

    [Fact]
    public async Task ReconcileAsync_NoChangeRequired()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);

        // We own it but it's already in the correct state - no change.
        mockClient.Verify(x => x.Create(It.IsAny<V1B1.VirtualService>()), Times.Never);
        mockClient.Verify(x => x.Update(It.IsAny<V1B1.VirtualService>()), Times.Never);
    }

    [Fact]
    public async Task ReconcileAsync_StatusUpdateDoesNotThrow()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Spec.Service = "host-should-get-updated";
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.UpdateStatus(It.IsAny<TrafficSplit>())).Throws(new DivideByZeroException());
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);

        // Shouldn't throw even though all status updates throw.
        await controller.ReconcileAsync(split);
    }

    [Fact]
    public async Task ReconcileAsync_TrafficSplitAnnotationChanged()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Metadata.Annotations ??= new Dictionary<string, string>();
        split.Metadata.Annotations[TrafficSplitAnnotations.Gateways] = "gateway";
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.Update(It.Is<V1B1.VirtualService>(match => match.Spec.Gateways!.Count() == 1 && match.Spec.Gateways!.First() == "gateway")));
    }

    [Fact]
    public async Task ReconcileAsync_TrafficSplitChangeUpdatesStatus()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Spec.Service = "host-should-get-updated";
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.True, TrafficSplitConditionReason.Completed))));
    }

    [Fact]
    public async Task ReconcileAsync_TrafficSplitServiceChanged()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Spec.Service = "host-should-get-updated";
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.Update(It.Is<V1B1.VirtualService>(match => match.Spec.Hosts!.Count() == 1 && match.Spec.Hosts!.First() == "host-should-get-updated")));
    }

    [Fact]
    public async Task ReconcileAsync_UpdateMergesLabels()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Spec.Service = "host-changed";
        foundVirtualService.Metadata.Labels.Clear();
        foundVirtualService.Metadata.Labels["original"] = "here";

        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(
            x => x.Update(It.Is<V1B1.VirtualService>(
                match =>
                    match.Metadata.Labels["original"] == "here" &&
                    match.Metadata.Labels["traffic-split"] == split.Metadata.Name)));
    }

    [Fact]
    public async Task ReconcileAsync_UpdateRetainsObjectIdentification()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        split.Spec.Service = "host-changed";
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(
            x => x.Update(It.Is<V1B1.VirtualService>(
                match =>
                    match.Metadata.CreationTimestamp == foundVirtualService.Metadata.CreationTimestamp &&
                    match.Metadata.Generation == foundVirtualService.Metadata.Generation &&
                    match.Metadata.ResourceVersion == foundVirtualService.Metadata.ResourceVersion &&
                    match.Metadata.Uid == foundVirtualService.Metadata.Uid)));
    }

    [Fact]
    public async Task ReconcileAsync_VirtualServiceChanged()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        foundVirtualService.Spec.Hosts = new[] { "host-should-get-reset" };
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.Update(It.Is<V1B1.VirtualService>(match => match.Spec.Hosts!.Count() == 1 && match.Spec.Hosts!.First() == "default-service")));
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.True, TrafficSplitConditionReason.Completed))));
    }

    [Fact]
    public async Task ReconcileAsync_VirtualServiceChangeUpdatesStatus()
    {
        var split = CreateTrafficSplit();
        var foundVirtualService = CreateVirtualService(split);
        foundVirtualService.Spec.Hosts = new[] { "host-should-get-reset" };
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.True, TrafficSplitConditionReason.Completed))));
    }

    [Fact]
    public async Task ReconcileAsync_VirtualServiceCreationUpdatesStatus()
    {
        var split = CreateTrafficSplit();
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).Returns(Task.FromResult<V1B1.VirtualService?>(null));
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.True, TrafficSplitConditionReason.Completed))));
    }

    [Fact]
    public async Task ReconcileAsync_VirtualServiceDoesNotExist()
    {
        var split = CreateTrafficSplit();
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).Returns(Task.FromResult<V1B1.VirtualService?>(null));
        await controller.ReconcileAsync(split);
        mockClient.Verify(x => x.Create(It.Is<V1B1.VirtualService>(match => match.Metadata.Name == "test-split-vs" && match.Metadata.NamespaceProperty == "test-ns")));
    }

    [Fact]
    public async Task ReconcileAsync_VirtualServiceExistsButOwnedElsewhere()
    {
        var split = CreateTrafficSplit();

        // VirtualService has a different owner and doesn't match.
        var foundVirtualService = CreateVirtualService(null);
        foundVirtualService.Spec.Hosts = new[] { "spec-no-longer-matches" };
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);

        // No change should happen because we don't own it, despite the
        // desired state not matching the actual state.
        mockClient.Verify(x => x.Create(It.IsAny<V1B1.VirtualService>()), Times.Never);
        mockClient.Verify(x => x.Update(It.IsAny<V1B1.VirtualService>()), Times.Never);

        // Final status should indicate there's an error.
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.False, TrafficSplitConditionReason.Error))));
    }

    [Fact]
    public async Task ReconcileAsync_VirtualServiceExistsWithoutOwner()
    {
        var split = CreateTrafficSplit();

        // VirtualService isn't owned and doesn't match.
        var foundVirtualService = CreateVirtualService(split);
        foundVirtualService.Metadata.OwnerReferences = new List<k8s.Models.V1OwnerReference>();
        foundVirtualService.Spec.Hosts = new[] { "spec-no-longer-matches" };
        var controller = CreateController();
        var mockClient = Mock.Get(controller.Client);
        mockClient.Setup(x => x.Get<V1B1.VirtualService>("test-split-vs", "test-ns")).ReturnsAsync(foundVirtualService);
        await controller.ReconcileAsync(split);

        // No change should happen because we don't own it, despite the
        // desired state not matching the actual state.
        mockClient.Verify(x => x.Create(It.IsAny<V1B1.VirtualService>()), Times.Never);
        mockClient.Verify(x => x.Update(It.IsAny<V1B1.VirtualService>()), Times.Never);

        // Final status should indicate there's an error.
        mockClient.Verify(x => x.UpdateStatus(It.Is(StatusContains(ConditionStatus.False, TrafficSplitConditionReason.Error))));
    }

    [Fact]
    public void Ctor_NullClient()
    {
        var logger = Mock.Of<ILogger<TrafficSplitController>>();
        Assert.Throws<ArgumentNullException>(() => new TrafficSplitController(logger, null!));
    }

    [Fact]
    public void Ctor_NullLogger()
    {
        var client = Mock.Of<IKubernetesClient>();
        Assert.Throws<ArgumentNullException>(() => new TrafficSplitController(null!, client));
    }

    private static Expression<Func<TrafficSplit, bool>> StatusContains(string conditionStatus, string conditionReason)
    {
        return t => t.Status.Conditions.FirstOrDefault(
            c => string.Equals(c.Status, conditionStatus, StringComparison.Ordinal) &&
                string.Equals(c.Reason, conditionReason, StringComparison.Ordinal)) != null;
    }

    private static TrafficSplitController CreateController()
    {
        return new TrafficSplitController(Mock.Of<ILogger<TrafficSplitController>>(), Mock.Of<IKubernetesClient>());
    }

    private static V1B1.VirtualService CreateVirtualService(TrafficSplit? owner)
    {
        owner ??= CreateTrafficSplit();
        var service = TrafficSplitConverter.ToV1Beta1VirtualService(owner);
        service.Metadata.CreationTimestamp = DateTime.UtcNow;
        service.Metadata.Generation = 1;
        service.Metadata.ResourceVersion = "9908058";
        service.Metadata.Uid = Guid.NewGuid().ToString();
        return service;
    }

    private static TrafficSplit CreateTrafficSplit()
    {
        return new TrafficSplit
        {
            Metadata = new()
            {
                Name = "test-split",
                NamespaceProperty = "test-ns",
                Uid = Guid.NewGuid().ToString(),
            },
            Spec = new()
            {
                Service = "default-service",
                Backends = new TrafficSplitBackend[]
                {
                    new()
                    {
                        Service = "first-service",
                        Weight = 300,
                    },
                    new()
                    {
                        Service = "second-service",
                        Weight = 700,
                    },
                },
            },
        }.Initialize();
    }
}

using Fiserv.Istio.SmiController.Api.V1Beta1;
using Newtonsoft.Json;

namespace Fiserv.Istio.SmiController.Test.Api.V1Beta1;

public class StringMatchTests
{
    [Fact]
    public void Ctor_Defaults()
    {
        var sm = new StringMatch();
        Assert.Null(sm.Exact);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Regex);
    }

    [Fact]
    public void Exact_Setter()
    {
        var sm = new StringMatch
        {
            Exact = "a",
        };

        Assert.Equal("a", sm.Exact);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Regex);

        sm.Prefix = "b";
        sm.Exact = "c";
        Assert.Equal("c", sm.Exact);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Regex);

        sm.Regex = "d";
        sm.Exact = "e";
        Assert.Equal("e", sm.Exact);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Regex);

        sm.Regex = "f";
        sm.Exact = null;
        Assert.Null(sm.Exact);
        Assert.Equal("f", sm.Regex);

        sm.Prefix = "g";
        sm.Exact = null;
        Assert.Null(sm.Exact);
        Assert.Equal("g", sm.Prefix);
    }

    [Fact]
    public void Prefix_Setter()
    {
        var sm = new StringMatch
        {
            Prefix = "a",
        };

        Assert.Equal("a", sm.Prefix);
        Assert.Null(sm.Exact);
        Assert.Null(sm.Regex);

        sm.Exact = "b";
        sm.Prefix = "c";
        Assert.Equal("c", sm.Prefix);
        Assert.Null(sm.Exact);
        Assert.Null(sm.Regex);

        sm.Regex = "d";
        sm.Prefix = "e";
        Assert.Equal("e", sm.Prefix);
        Assert.Null(sm.Exact);
        Assert.Null(sm.Regex);

        sm.Regex = "f";
        sm.Prefix = null;
        Assert.Null(sm.Prefix);
        Assert.Equal("f", sm.Regex);

        sm.Exact = "g";
        sm.Prefix = null;
        Assert.Null(sm.Prefix);
        Assert.Equal("g", sm.Exact);
    }

    [Fact]
    public void Regex_Setter()
    {
        var sm = new StringMatch
        {
            Regex = "a",
        };

        Assert.Equal("a", sm.Regex);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Exact);

        sm.Prefix = "b";
        sm.Regex = "c";
        Assert.Equal("c", sm.Regex);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Exact);

        sm.Exact = "d";
        sm.Regex = "e";
        Assert.Equal("e", sm.Regex);
        Assert.Null(sm.Prefix);
        Assert.Null(sm.Exact);

        sm.Exact = "f";
        sm.Regex = null;
        Assert.Null(sm.Regex);
        Assert.Equal("f", sm.Exact);

        sm.Prefix = "g";
        sm.Regex = null;
        Assert.Null(sm.Regex);
        Assert.Equal("g", sm.Prefix);
    }

    [Fact]
    public void Deserialization_Default()
    {
        var actual = JsonConvert.DeserializeObject<StringMatch>("{}");
        Assert.Null(actual!.Exact);
        Assert.Null(actual.Prefix);
        Assert.Null(actual.Regex);
    }

    [Fact]
    public void Deserialization_Exact()
    {
        var actual = JsonConvert.DeserializeObject<StringMatch>("{\"exact\":\"a\"}");
        Assert.Equal("a", actual!.Exact);
        Assert.Null(actual.Prefix);
        Assert.Null(actual.Regex);
    }

    [Fact]
    public void Deserialization_MultipleProperties()
    {
        // Only one property is allowed. JSON will set the properties in the order listed.
        var actual = JsonConvert.DeserializeObject<StringMatch>("{\"regex\":\"a\",\"exact\":\"b\"}");
        Assert.Equal("b", actual!.Exact);
        Assert.Null(actual.Prefix);
        Assert.Null(actual.Regex);
    }

    [Fact]
    public void Deserialization_Prefix()
    {
        var actual = JsonConvert.DeserializeObject<StringMatch>("{\"prefix\":\"a\"}");
        Assert.Null(actual!.Exact);
        Assert.Equal("a", actual.Prefix);
        Assert.Null(actual.Regex);
    }

    [Fact]
    public void Deserialization_Regex()
    {
        var actual = JsonConvert.DeserializeObject<StringMatch>("{\"regex\":\"a\"}");
        Assert.Null(actual!.Exact);
        Assert.Null(actual.Prefix);
        Assert.Equal("a", actual.Regex);
    }

    [Fact]
    public void Serialization_Default()
    {
        var sm = new StringMatch();
        var actual = JsonConvert.SerializeObject(sm);
        Assert.Equal("{}", actual);
    }

    [Fact]
    public void Serialization_Exact()
    {
        var sm = new StringMatch
        {
            Exact = "a",
        };
        var actual = JsonConvert.SerializeObject(sm);
        Assert.Equal("{\"exact\":\"a\"}", actual);
    }

    [Fact]
    public void Serialization_Prefix()
    {
        var sm = new StringMatch
        {
            Prefix = "a",
        };
        var actual = JsonConvert.SerializeObject(sm);
        Assert.Equal("{\"prefix\":\"a\"}", actual);
    }

    [Fact]
    public void Serialization_Regex()
    {
        var sm = new StringMatch
        {
            Regex = "a",
        };
        var actual = JsonConvert.SerializeObject(sm);
        Assert.Equal("{\"regex\":\"a\"}", actual);
    }
}

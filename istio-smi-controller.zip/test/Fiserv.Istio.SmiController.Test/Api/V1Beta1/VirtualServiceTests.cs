using Fiserv.Istio.SmiController.Api.V1Beta1;

namespace Fiserv.Istio.SmiController.Test.Api.V1Beta1;

public class VirtualServiceTests
{
    [Fact]
    public void Serialization_1()
    {
        var obj = ReadScenario(1);
        Assert.NotNull(obj);
        Assert.Equal("networking.istio.io/v1beta1", obj!.ApiVersion);
        Assert.Equal("VirtualService", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("reviews-route", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.NotNull(obj.Spec.Hosts);
        Assert.Equal(new[] { "reviews.prod.svc.cluster.local" }, obj.Spec.Hosts);
        Assert.NotNull(obj.Spec.Http);
        Assert.Collection(
            obj.Spec.Http,
            route =>
            {
                Assert.Equal("reviews-v2-routes", route.Name);
                Assert.Collection(
                    route.Match!,
                    match =>
                    {
                        Assert.Equal("/wpcatalog", match.Uri!.Prefix);
                    },
                    match =>
                    {
                        Assert.Equal("/consumercatalog", match.Uri!.Prefix);
                    });

                // If/when we support `rewrite`, add that check here.
                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("reviews.prod.svc.cluster.local", routeDef.Destination.Host);
                        Assert.Equal("v2", routeDef.Destination.Subset);
                    });
            },
            route =>
            {
                Assert.Equal("reviews-v1-route", route.Name);
                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("reviews.prod.svc.cluster.local", routeDef.Destination.Host);
                        Assert.Equal("v1", routeDef.Destination.Subset);
                    });
            });
    }

    [Fact]
    public void Serialization_2()
    {
        var obj = ReadScenario(2);
        Assert.NotNull(obj);
        Assert.Equal("networking.istio.io/v1beta1", obj!.ApiVersion);
        Assert.Equal("VirtualService", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("my-productpage-rule", obj.Metadata.Name);
        Assert.Equal("istio-system", obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.NotNull(obj.Spec.Hosts);
        Assert.Equal(new[] { "productpage.prod.svc.cluster.local" }, obj.Spec.Hosts);
        Assert.NotNull(obj.Spec.Http);
        Assert.Collection(
            obj.Spec.Http,
            route =>
            {
                // If/when we support `timeout`, add that check here.
                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("productpage.prod.svc.cluster.local", routeDef.Destination.Host);
                    });
            });
    }

    [Fact]
    public void Serialization_3()
    {
        var obj = ReadScenario(3);
        Assert.NotNull(obj);
        Assert.Equal("networking.istio.io/v1beta1", obj!.ApiVersion);
        Assert.Equal("VirtualService", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("my-wiki-rule", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.NotNull(obj.Spec.Hosts);
        Assert.Equal(new[] { "wikipedia.org" }, obj.Spec.Hosts);
        Assert.NotNull(obj.Spec.Http);
        Assert.Collection(
            obj.Spec.Http,
            route =>
            {
                // If/when we support `timeout`, add that check here.
                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("wikipedia.org", routeDef.Destination.Host);
                    });
            });
    }

    [Fact]
    public void Serialization_4()
    {
        var obj = ReadScenario(4);
        Assert.NotNull(obj);
        Assert.Equal("networking.istio.io/v1beta1", obj!.ApiVersion);
        Assert.Equal("VirtualService", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("reviews-route", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.NotNull(obj.Spec.Hosts);
        Assert.Equal(new[] { "reviews.prod.svc.cluster.local" }, obj.Spec.Hosts);
        Assert.NotNull(obj.Spec.Http);
        Assert.Collection(
            obj.Spec.Http,
            route =>
            {
                Assert.NotNull(route.Headers?.Request?.SetHeaders);
                Assert.Equal("true", route.Headers.Request.SetHeaders["test"]);
                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("reviews.prod.svc.cluster.local", routeDef.Destination.Host);
                        Assert.Equal("v2", routeDef.Destination.Subset);
                        Assert.Equal(25, routeDef.Weight);
                    },
                    routeDef =>
                    {
                        Assert.Equal("reviews.prod.svc.cluster.local", routeDef.Destination.Host);
                        Assert.Equal("v1", routeDef.Destination.Subset);
                        Assert.NotNull(routeDef.Headers?.Response?.RemoveHeaders);
                        Assert.Equal(new[] { "foo" }, routeDef.Headers.Response.RemoveHeaders);
                        Assert.Equal(75, routeDef.Weight);
                    });
            });
    }

    [Fact]
    public void Serialization_5()
    {
        var obj = ReadScenario(5);
        Assert.NotNull(obj);
        Assert.Equal("networking.istio.io/v1beta1", obj!.ApiVersion);
        Assert.Equal("VirtualService", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("ratings-route", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.NotNull(obj.Spec.Hosts);
        Assert.Equal(new[] { "ratings.prod.svc.cluster.local" }, obj.Spec.Hosts);
        Assert.NotNull(obj.Spec.Http);
        Assert.Collection(
            obj.Spec.Http,
            route =>
            {
                Assert.Collection(
                    route.Match!,
                    match =>
                    {
                        Assert.NotNull(match.Headers);
                        Assert.Equal("jason", match.Headers["end-user"].Exact);
                        Assert.Equal("/ratings/v2/", match.Uri!.Prefix);
                        Assert.True(match.IgnoreUriCase);
                    });

                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("ratings.prod.svc.cluster.local", routeDef.Destination.Host);
                    });
            });
    }

    [Fact]
    public void Serialization_6()
    {
        var obj = ReadScenario(6);
        Assert.NotNull(obj);
        Assert.Equal("networking.istio.io/v1beta1", obj!.ApiVersion);
        Assert.Equal("VirtualService", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("reviews-route-two-domains", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.NotNull(obj.Spec.Hosts);
        Assert.Equal(new[] { "reviews.com" }, obj.Spec.Hosts);
        Assert.NotNull(obj.Spec.Http);
        Assert.Collection(
            obj.Spec.Http,
            route =>
            {
                Assert.Collection(
                    route.Route!,
                    routeDef =>
                    {
                        Assert.Equal("dev.reviews.com", routeDef.Destination.Host);
                        Assert.Equal(25, routeDef.Weight);
                    },
                    routeDef =>
                    {
                        Assert.Equal("reviews.com", routeDef.Destination.Host);
                        Assert.Equal(75, routeDef.Weight);
                    });
            });
    }

    private static VirtualService ReadScenario(int number) =>
        EmbeddedYamlReader.ReadScenario<VirtualService>($"Fiserv.Istio.SmiController.Test.Api.V1Beta1.Specification.virtualservice-{number}.yml") ?? throw new InvalidOperationException($"Unable to read scenario {number}.");
}

using Newtonsoft.Json;
using YamlDotNet.Serialization;

namespace Fiserv.Istio.SmiController.Test.Api;

public static class EmbeddedYamlReader
{
    /// <summary>
    /// Reads a YAML document and runs it through JSON deserialization.
    /// </summary>
    /// <param name="embeddedResourcePath">
    /// Path to the embedded resource to load and deserialize.
    /// </param>
    /// <typeparam name="T">
    /// The type of object to deserialize.
    /// </typeparam>
    /// <returns>
    /// The deserialized object from the YAML.
    /// </returns>
    public static T? ReadScenario<T>(string embeddedResourcePath)
    {
        // The YAML goes through a two-round deserialization mechanism. The
        // reason for this is that, while humans work in YAML and the
        // specifications show examples in YAML, the API responds in JSON
        // and the serialization markup is JSON-based. Hence, we need to
        // convert the specs/examples from YAML to JSON and then make use of
        // the JSON serialization markup.
        using var stream = typeof(EmbeddedYamlReader).Assembly.GetManifestResourceStream(embeddedResourcePath);
        if (stream == null)
        {
            throw new InvalidOperationException($"Unable to find embedded resource '{embeddedResourcePath}'.");
        }

        using var reader = new StreamReader(stream);

        var deserializer = new DeserializerBuilder().Build();
        var yaml = deserializer.Deserialize(reader);
        if (yaml == null)
        {
            return default;
        }

        var serializer = new SerializerBuilder().JsonCompatible().Build();
        var json = serializer.Serialize(yaml);
        if (json == null)
        {
            return default;
        }

        return JsonConvert.DeserializeObject<T>(json);
    }
}

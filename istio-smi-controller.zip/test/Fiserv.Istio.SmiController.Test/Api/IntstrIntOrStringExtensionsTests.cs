using Fiserv.Istio.SmiController.Api;
using k8s.Models;

namespace Fiserv.Istio.SmiController.Test.Api;

public class IntstrIntOrStringExtensionsTests
{
    [Theory]
    [InlineData("", 0)]
    [InlineData(null, 0)]
    [InlineData("0", 0)]
    [InlineData("0m", 0)]
    [InlineData("10", 10)]
    [InlineData("100m", 0.1)]
    [InlineData("1000m", 1)]
    public void ToDecimal_HandlesStringValues(string toParse, decimal expected)
    {
        var value = new IntstrIntOrString(toParse);
        Assert.Equal(expected, IntstrIntOrStringExtensions.ToDecimal(value));
    }

    [Fact]
    public void ToDecimal_NullInput()
    {
        IntstrIntOrString? value = null;
        Assert.Equal(0, IntstrIntOrStringExtensions.ToDecimal(value));
    }
}

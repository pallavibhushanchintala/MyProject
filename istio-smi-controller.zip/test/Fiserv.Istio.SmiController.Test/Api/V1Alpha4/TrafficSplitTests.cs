using Fiserv.Istio.SmiController.Api.V1Alpha4;

namespace Fiserv.Istio.SmiController.Test.Api.V1Alpha4;

public class TrafficSplitTests
{
    [Fact]
    public void Serialization_1()
    {
        var obj = ReadScenario(1);
        Assert.NotNull(obj);
        Assert.Equal("split.smi-spec.io/v1alpha4", obj!.ApiVersion);
        Assert.Equal("TrafficSplit", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("canary", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.Equal("website", obj.Spec.Service);
        Assert.NotNull(obj.Spec.Backends);
        Assert.Collection(
            obj.Spec.Backends,
            item =>
            {
                Assert.Equal("website-v1", item.Service);
                Assert.Equal(90, item.Weight);
            },
            item =>
            {
                Assert.Equal("website-v2", item.Service);
                Assert.Equal(10, item.Weight);
            });
        Assert.Null(obj.Spec.Matches);
    }

    [Fact]
    public void Serialization_2()
    {
        var obj = ReadScenario(2);
        Assert.NotNull(obj);
        Assert.Equal("split.smi-spec.io/v1alpha4", obj!.ApiVersion);
        Assert.Equal("TrafficSplit", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("ab-test", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.Equal("website", obj.Spec.Service);
        Assert.NotNull(obj.Spec.Backends);
        Assert.Collection(
            obj.Spec.Backends,
            item =>
            {
                Assert.Equal("website-v1", item.Service);
                Assert.Equal(0, item.Weight);
            },
            item =>
            {
                Assert.Equal("website-v2", item.Service);
                Assert.Equal(100, item.Weight);
            });
        Assert.NotNull(obj.Spec.Matches);
        Assert.Collection(
            obj.Spec.Matches,
            item =>
            {
                Assert.Equal("HTTPRouteGroup", item.Kind);
                Assert.Equal("ab-test", item.Name);
                Assert.Null(item.ApiGroup);
            });
    }

    [Fact]
    public void Serialization_3()
    {
        var obj = ReadScenario(3);
        Assert.NotNull(obj);
        Assert.Equal("split.smi-spec.io/v1alpha4", obj!.ApiVersion);
        Assert.Equal("TrafficSplit", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("foobar-rollout", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.Equal("foobar", obj.Spec.Service);
        Assert.NotNull(obj.Spec.Backends);
        Assert.Collection(
            obj.Spec.Backends,
            item =>
            {
                Assert.Equal("foobar-v1", item.Service);
                Assert.Equal(100, item.Weight);
            },
            item =>
            {
                Assert.Equal("foobar-v2", item.Service);
                Assert.Equal(0, item.Weight);
            });
        Assert.Null(obj.Spec.Matches);
    }

    [Fact]
    public void Serialization_4()
    {
        var obj = ReadScenario(4);
        Assert.NotNull(obj);
        Assert.Equal("split.smi-spec.io/v1alpha4", obj!.ApiVersion);
        Assert.Equal("TrafficSplit", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("foobar-rollout", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.Equal("foobar", obj.Spec.Service);
        Assert.NotNull(obj.Spec.Backends);
        Assert.Collection(
            obj.Spec.Backends,
            item =>
            {
                Assert.Equal("foobar-v1", item.Service);
                Assert.Equal(1000, item.Weight);
            },
            item =>
            {
                Assert.Equal("foobar-v2", item.Service);
                Assert.Equal(500, item.Weight);
            });
        Assert.Null(obj.Spec.Matches);
    }

    [Fact]
    public void Serialization_5()
    {
        var obj = ReadScenario(5);
        Assert.NotNull(obj);
        Assert.Equal("split.smi-spec.io/v1alpha4", obj!.ApiVersion);
        Assert.Equal("TrafficSplit", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("foobar-rollout", obj.Metadata.Name);
        Assert.Null(obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.Equal("foobar", obj.Spec.Service);
        Assert.NotNull(obj.Spec.Backends);
        Assert.Collection(
            obj.Spec.Backends,
            item =>
            {
                Assert.Equal("foobar-v2", item.Service);
                Assert.Equal(1, item.Weight);
            });
        Assert.Null(obj.Spec.Matches);
    }

    [Fact]
    public void Serialization_AzureDevOps()
    {
        var obj = EmbeddedYamlReader.ReadScenario<TrafficSplit>("Fiserv.Istio.SmiController.Test.Api.V1Alpha4.AzureDevOps.trafficsplit.yml");
        Assert.NotNull(obj);
        Assert.Equal("split.smi-spec.io/v1alpha1", obj!.ApiVersion);
        Assert.Equal("TrafficSplit", obj.Kind);
        Assert.NotNull(obj.Metadata);
        Assert.Equal("tenants-service-azure-pipelines-rollout", obj.Metadata.Name);
        Assert.Equal("directory", obj.Metadata.NamespaceProperty);
        Assert.NotNull(obj.Spec);
        Assert.Equal("tenants-service", obj.Spec.Service);
        Assert.NotNull(obj.Spec.Backends);
        Assert.Collection(
            obj.Spec.Backends,
            item =>
            {
                Assert.Equal("tenants-service-stable", item.Service);
                Assert.Equal("750m", item.Weight);
            },
            item =>
            {
                Assert.Equal("tenants-service-baseline", item.Service);
                Assert.Equal("125m", item.Weight);
            },
            item =>
            {
                Assert.Equal("tenants-service-canary", item.Service);
                Assert.Equal("125m", item.Weight);
            });
        Assert.Null(obj.Spec.Matches);
    }

    private static TrafficSplit ReadScenario(int number) =>
        EmbeddedYamlReader.ReadScenario<TrafficSplit>($"Fiserv.Istio.SmiController.Test.Api.V1Alpha4.Specification.trafficsplit-{number}.yml") ?? throw new InvalidOperationException($"Unable to read scenario {number}.");
}

using Fiserv.Istio.SmiController.Api;
using Fiserv.Istio.SmiController.Api.V1Alpha4;
using Fiserv.Istio.SmiController.Api.V1Beta1;
using k8s;
using k8s.Models;

namespace Fiserv.Istio.SmiController.Test.Api.V1Alpha4;

public class TrafficSplitConverterTests
{
    [Theory]
    [InlineData("*", new string[] { "*" })]
    [InlineData("*,foo", new string[] { "*", "foo" })]
    [InlineData("* , foo", new string[] { "*", "foo" })]
    [InlineData("* , , foo", new string[] { "*", "foo" })]
    public void ToV1Beta1VirtualService_Gateways_Annotation(string annotationValue, string[] expected)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Gateways, annotationValue },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Equal(expected, vs.Spec.Gateways!);
    }

    [Fact]
    public void ToV1Beta1VirtualService_Gateways_Default()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Null(vs.Spec.Gateways);
    }

    [Theory]
    [InlineData("")]
    [InlineData(",")]
    [InlineData(" , , ")]
    public void ToV1Beta1VirtualService_Gateways_Empty(string annotationValue)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Gateways, annotationValue },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Null(vs.Spec.Gateways);
    }

    [Theory]
    [InlineData("*", new string[] { "*" })]
    [InlineData("*,foo", new string[] { "*", "foo" })]
    [InlineData("* , foo", new string[] { "*", "foo" })]
    [InlineData("* , , foo", new string[] { "*", "foo" })]
    public void ToV1Beta1VirtualService_Hosts_Annotation(string annotationValue, string[] expected)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Hosts, annotationValue },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Equal(expected, vs.Spec.Hosts!);
    }

    [Theory]
    [InlineData("")]
    [InlineData(",")]
    [InlineData(" , , ")]
    public void ToV1Beta1VirtualService_Hosts_Empty(string annotationValue)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Gateways, annotationValue },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        var host = Assert.Single(vs.Spec.Hosts!);
        Assert.Equal(ts.Spec.Service, host);
    }

    [Fact]
    public void ToV1Beta1VirtualService_Hosts_Default()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        var host = Assert.Single(vs.Spec.Hosts!);
        Assert.Equal(ts.Spec.Service, host);
    }

    [Fact]
    public void ToV1Beta1VirtualService_Initialized()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        var meta = typeof(VirtualService).GetKubernetesTypeMetadata();
        Assert.Equal($"{meta.Group}/{meta.ApiVersion}", vs.ApiVersion);
        Assert.Equal(meta.Kind, vs.Kind);
    }

    [Fact]
    public void ToV1Beta1VirtualService_Labels()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Equal(ts.Metadata.Name, vs.Metadata.Labels["traffic-split"]);
    }

    [Fact]
    public void ToV1Beta1VirtualService_Match_Annotation()
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Match, "[{\"uri\":{\"prefix\":\"/headers\"}}]" },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Collection(
            vs.Spec.Http!,
            httpRoute =>
            {
                var match = Assert.Single(httpRoute.Match!);
                Assert.NotNull(match.Uri);
                Assert.Equal("/headers", match.Uri.Prefix);
            });
    }

    [Fact]
    public void ToV1Beta1VirtualService_Match_Default()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Collection(
            vs.Spec.Http!,
            httpRoute =>
            {
                Assert.Null(httpRoute.Match);
            });
    }

    [Fact]
    public void ToV1Beta1VirtualService_Match_ParseFailure()
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            // Malformed JSON missing opening [
            { TrafficSplitAnnotations.Match, "{\"uri\":{\"prefix\":\"/headers\"}}]" },
        };
        Assert.Throws<FormatException>(() => TrafficSplitConverter.ToV1Beta1VirtualService(ts));
    }

    [Fact]
    public void ToV1Beta1VirtualService_Name()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Equal("test-split-vs", vs.Metadata.Name);
    }

    [Theory]
    [InlineData("test-ns")]
    [InlineData(null)]
    [InlineData("")]
    public void ToV1Beta1VirtualService_Namespace(string ns)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.NamespaceProperty = ns;
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Equal(ts.Metadata.NamespaceProperty, vs.Metadata.NamespaceProperty);
    }

    [Fact]
    public void ToV1Beta1VirtualService_NullTrafficSplit()
    {
        Assert.Throws<ArgumentNullException>(() => TrafficSplitConverter.ToV1Beta1VirtualService(null!));
    }

    [Fact]
    public void ToV1Beta1VirtualService_Owner()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        var owner = Assert.Single(vs.Metadata.OwnerReferences);
        Assert.Equal(ts.ApiVersion, owner.ApiVersion);
        Assert.Equal(ts.Kind, owner.Kind);
        Assert.Equal(ts.Metadata.Name, owner.Name);
        Assert.Equal(ts.Metadata.Uid, owner.Uid);
        Assert.True(owner.BlockOwnerDeletion);
        Assert.True(owner.Controller);
    }

    [Theory]
    [InlineData("80", 80)]
    [InlineData("8080", 8080)]
    public void ToV1Beta1VirtualService_Port_Annotation(string annotationValue, uint expected)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Port, annotationValue },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        foreach (var destination in vs.Spec.Http!.SelectMany(r => r.Route!))
        {
            Assert.Equal(expected, destination.Destination.Port!.Number);
        }
    }

    [Fact]
    public void ToV1Beta1VirtualService_Port_Default()
    {
        var ts = CreateTrafficSplit();
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        foreach (var destination in vs.Spec.Http!.SelectMany(r => r.Route!))
        {
            Assert.Null(destination.Destination.Port);
        }
    }

    [Theory]
    [InlineData("")]
    [InlineData(" ")]
    public void ToV1Beta1VirtualService_Port_Empty(string annotationValue)
    {
        var ts = CreateTrafficSplit();
        ts.Metadata.Annotations = new Dictionary<string, string>
        {
            { TrafficSplitAnnotations.Port, annotationValue },
        };
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        foreach (var destination in vs.Spec.Http!.SelectMany(r => r.Route!))
        {
            Assert.Null(destination.Destination.Port);
        }
    }

    [Fact]
    public void ToV1Beta1VirtualService_Routes_WeightAllZero()
    {
        var ts = CreateTrafficSplit();
        foreach (var b in ts.Spec.Backends)
        {
            b.Weight = 0;
        }

        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Collection(
            vs.Spec.Http!,
            httpRoute =>
            {
                Assert.Empty(httpRoute.Route!);
            });
    }

    [Fact]
    public void ToV1Beta1VirtualService_Routes_WeightAllZeroButOne()
    {
        var ts = CreateTrafficSplit();
        ts.Spec.Backends.First().Weight = 0;
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Collection(
            vs.Spec.Http!,
            httpRoute =>
            {
                var r = Assert.Single(httpRoute.Route!);
                Assert.Equal(100, r.Weight);
            });
    }

    [Theory]
    [InlineData("30", "70", 30, 70)]
    [InlineData("300m", "700m", 30, 70)]
    [InlineData("6000m", "4", 60, 40)]
    [InlineData("250m", "750m", 25, 75)]
    [InlineData("500m", "1000m", 33, 67)]
    [InlineData("125m", "875m", 13, 87)]
    [InlineData("135m", "865m", 14, 86)]
    public void ToV1Beta1VirtualService_Routes_Weights(string actualFirstData, string actualSecondData, int expectedFirst, int expectedSecond)
    {
        var actualFirst = new IntstrIntOrString(actualFirstData);
        var actualSecond = new IntstrIntOrString(actualSecondData);
        var ts = CreateTrafficSplit();
        ts.Spec.Backends.First(b => b.Service == "first-service").Weight = actualFirst;
        ts.Spec.Backends.First(b => b.Service == "second-service").Weight = actualSecond;
        var vs = TrafficSplitConverter.ToV1Beta1VirtualService(ts);
        Assert.Collection(
            vs.Spec.Http!,
            httpRoute =>
            {
                Assert.Collection(
                    httpRoute.Route!,
                    route =>
                    {
                        Assert.Equal("first-service", route.Destination.Host);
                        Assert.Equal(expectedFirst, route.Weight);
                    },
                    route =>
                    {
                        Assert.Equal("second-service", route.Destination.Host);
                        Assert.Equal(expectedSecond, route.Weight);
                    });
            });
    }

    private static TrafficSplit CreateTrafficSplit()
    {
        return new TrafficSplit
        {
            Metadata = new()
            {
                Name = "test-split",
                NamespaceProperty = "test-ns",
                Uid = Guid.NewGuid().ToString(),
            },
            Spec = new()
            {
                Service = "default-service",
                Backends = new TrafficSplitBackend[]
                {
                    new()
                    {
                        Service = "first-service",
                        Weight = 300,
                    },
                    new()
                    {
                        Service = "second-service",
                        Weight = 700,
                    },
                },
            },
        }.Initialize();
    }
}

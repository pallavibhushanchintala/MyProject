using Fiserv.Istio.SmiController.Api.V1Alpha4;

namespace Fiserv.Istio.SmiController.Test.Api.V1Alpha4;

public class TrafficSplitStatusTests
{
    [Fact]
    public void AddOrUpdate_CaseSensitive()
    {
        var upper = new TrafficSplitCondition
        {
            Type = "TEST",
            Message = "message",
        };

        var status = new TrafficSplitStatus();
        status.AddOrUpdate(upper);

        var lower = new TrafficSplitCondition
        {
            Type = "test",
            Message = "message",
        };

        status.AddOrUpdate(lower);

        Assert.Equal(2, status.Conditions.Count);
    }

    [Fact]
    public void AddOrUpdate_Found()
    {
        var original = new TrafficSplitCondition
        {
            Type = "test",
            Message = "original",
        };

        var status = new TrafficSplitStatus();
        Assert.Empty(status.Conditions);
        status.AddOrUpdate(original);

        var expected = new TrafficSplitCondition
        {
            Type = "test",
            Message = "expected",
        };

        status.AddOrUpdate(expected);
        var actual = Assert.Single(status.Conditions);
        Assert.Same(expected, actual);
    }

    [Fact]
    public void AddOrUpdate_NotFound()
    {
        var expected = new TrafficSplitCondition
        {
            Type = "test",
            Message = "expected",
        };

        var status = new TrafficSplitStatus();
        Assert.Empty(status.Conditions);

        status.AddOrUpdate(expected);
        var actual = Assert.Single(status.Conditions);
        Assert.Same(expected, actual);
    }
}

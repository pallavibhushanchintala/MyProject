'use strict';
const argv = require('yargs').argv;
const del = require('del');
const exec = require('child_process').exec;
const fs = require('fs');
const gulp = require('gulp');
const gulpEslint = require('gulp-eslint');
const path = require('path');
const PluginError = require('plugin-error');
const shell = require('gulp-shell');

// Constants
const schemaLocation = 'schema.json';

// Arguments
const apigeeProxyData =
{
  'name': 'dsl-banking-accounts',
  'virtualHost': process.env.APIGEE_VIRTUALHOSTS || 'api-fiservapps',
  'targetUrl': process.env.ROOTAPIENDPOINT || 'https://52.182.211.56',
  'keyAlias': process.env.APIGEE_KEYALIAS || 'dsl-truststore-2023',
  'keyStore': process.env.APIGEE_KEYSTORE || 'ref://dsl-keystore'
};
const artifactsPath = process.env.BUILD_ARTIFACTSTAGINGDIRECTORY || path.join('.', 'artifacts');
const hostDefault = 'localhost:4708';
const host = argv.host || process.env.TEST_ENDPOINT || hostDefault;
const syncPostman = argv.syncPostman;

// Calculated values
const testsPath = path.join(artifactsPath, 'tests');

/**
 * Cleans previously generated artifacts.
 *
 * @returns {Promise<string[]>} Promise for awaiting completion.
 */
function clean() {
  return del([artifactsPath, testsPath]);
}
clean.description = 'Cleans previously generated artifacts.';

/**
 * Generates the Apigee proxy.
 *
 * @param {@callback} cb - The callback that handles the response.
 */
function generateProxy(cb) {
  const policies = path.join(__dirname, 'apigee', 'policies');
  const proxyCli =
    `dotnet apigee-proxygen "${apigeeProxyData.name}" "${schemaLocation}" ` +
    `-o "${artifactsPath}" ` +
    '-bpp /dsl ' +
    `-vh "${apigeeProxyData.virtualHost}" ` +
    `-t "${apigeeProxyData.targetUrl}" ` +
    `--policies "${policies}" ` +
    '--mtls ' +
    `--ssl-key-alias ${apigeeProxyData.keyAlias} ` +
    `--ssl-key-store ${apigeeProxyData.keyStore}`;

  // apigeetool handles zipping up the proxy at deploy time, we don't have to do that.
  exec(proxyCli, { cwd: __dirname }, function(err, stdout, stderr) {
    if (stdout) {
      console.log(stdout);
    }
    if (stderr) {
      console.log(stderr);
    }
    if (err) {
      cb(err);
    }
    cb();
  });
}
generateProxy.description = 'Generates the Apigee proxy based on the OpenAPI schema.';

/**
 * Generates Postman tests using Portman.
 */
async function generateTests() {
  if (!fs.existsSync(testsPath)) {
    fs.mkdirSync(testsPath);
  }

  const syncPostmanArg = syncPostman ? ' --syncPostman' : '';
  await shell.task(`npx portman -l ${schemaLocation} -b http://${host} -o ${testsPath}/postman.json -c portman-config.json ${syncPostmanArg}`)();
  fs.copyFileSync('postman_environment.json', `${testsPath}/postman_environment.json`);
}
generateTests.description = 'Generates Postman tests from the OAS3 specification using Portman.';
generateTests.flags = {
  '--host': `Host endpoint used in Portman tests, default: '${hostDefault}'`,
  '--syncPostman': 'Sync the contract tests with Postman. Assumes .env file has Postman API data.'
};

/**
 * Runs linting on source files.
 *
 * @returns {any} NodeJS.ReadWriteStream for piping things through ESLint.
 */
function lint() {
  // Linting is a separate task because putting a pipe and async/await in one
  // big task causes odd error reporting to occur where you can't turn off the
  // stack trace.
  return gulp.src(['*.js'])
    .pipe(gulpEslint())
    .pipe(gulpEslint.format())
    .pipe(gulpEslint.results((results) => {
      if (results.warningCount || results.errorCount) {
        // Custom handler so we can fail on warnings and errors here.
        throw new PluginError('gulp-eslint', `Linting failed with ${results.warningCount} warning${results.warningCount === 1 ? '' : 's'} and ${results.errorCount} error${results.errorCount === 1 ? '' : 's'}`);
      }
    }));
}

/**
 * Executes the generated Postman tests using Newman.
 */
async function test() {
  await shell.task(`newman run ${testsPath}/postman.json -e ${testsPath}/postman_environment.json`)();
}
test.description = 'Executes generated Postman tests using Newman.';

exports.clean = clean;
exports.build = gulp.series(generateProxy, generateTests, lint);
exports.generateProxy = generateProxy;
exports.generateTests = generateTests;
exports.test = test;
exports.default = gulp.series(clean, generateProxy, generateTests, lint);

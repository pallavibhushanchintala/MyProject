# Kubernetes Cluster Example: Basic

This example shows basic consumption of the Kubernetes cluster module. It creates prerequisites:

- Key Vault and policies to support customer-managed keys.
- Hub and spoke simulated network environment to support the network/policy requirements on the cluster nodes.

Then this example deploys the Kubernetes cluster module into that resource group, wiring up all the CMK and network support required.

Finally, an httpbin service is added to the cluster to show that traffic can make it from a designated public IP address, through a firewall, into the AKS subnet and finally into the cluster. This validates that the networking is correctly attached.

This definitely seems more complex than a "basic" example should be, but we do have a lot of prerequisites for getting a Kubernetes cluster deployed. This is as basic as it gets.

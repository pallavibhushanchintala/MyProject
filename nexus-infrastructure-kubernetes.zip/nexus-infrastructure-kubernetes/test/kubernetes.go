package test

import (
	"github.com/Azure/azure-sdk-for-go/services/containerservice/mgmt/2020-02-01/containerservice"
	"github.com/stretchr/testify/assert"
)

func validateKubernetesDeployment(ctx ValidationContext) {
	// We don't validate the VMSS backing the cluster because there are some
	// eventual consistency issues such that querying for the VMSS immediately
	// after deployment doesn't seem to actually find the VMSS. This failure
	// started happening around August 2020. Before that the VMSS was found.
	// This may be an issue with the Azure SDK for Go but we wasted a lot of
	// time trying to figure it out and never did.
	k8sCluster, err := ctx.ManagedClustersClient.Get(ctx.Context, ctx.Outputs.ResourceGroupName, ctx.Outputs.ClusterName)
	assert.Nil(ctx.T, err)
	assert.NotNil(ctx.T, k8sCluster)

	assert.True(ctx.T, *k8sCluster.ManagedClusterProperties.EnableRBAC, "RBAC should be enabled.")
	assert.Equal(ctx.T, containerservice.NetworkPlugin("azure"), k8sCluster.ManagedClusterProperties.NetworkProfile.NetworkPlugin, "Network should be Azure CNI to allow bring-your-own-subnet.")
	assert.Equal(ctx.T, containerservice.LoadBalancerSku("Standard"), k8sCluster.ManagedClusterProperties.NetworkProfile.LoadBalancerSku, "Load balancer should be standard to support availability zones.")
	assert.Equal(ctx.T, containerservice.ResourceIdentityType("SystemAssigned"), k8sCluster.Identity.Type, "The system should assign an identity for the cluster.")
	assert.Equal(ctx.T, ctx.Outputs.NodeResourceGroup, *k8sCluster.ManagedClusterProperties.NodeResourceGroup, "VMSS info should match the node info reported by the cluster.")
	assert.Equal(ctx.T, int32(5), *(*k8sCluster.ManagedClusterProperties.AgentPoolProfiles)[0].MinCount, "Minimum number of nodes not set.")
	assert.Equal(ctx.T, containerservice.OSType("Linux"), (*k8sCluster.ManagedClusterProperties.AgentPoolProfiles)[0].OsType, "Wrong OS type on default agent pool.")
	assert.Equal(ctx.T, ctx.Outputs.DiskEncryptionSetID, *k8sCluster.ManagedClusterProperties.DiskEncryptionSetID, "The disk encryption set should be enabled so CMK is used.")

	if val, ok := ((*k8sCluster.ManagedClusterProperties).AddonProfiles)["omsagent"]; ok {
		assert.True(ctx.T, *val.Enabled, "Container Insights was not enabled.")
	} else {
		assert.Fail(ctx.T, "The omsagent add-on was not present.")
	}
}

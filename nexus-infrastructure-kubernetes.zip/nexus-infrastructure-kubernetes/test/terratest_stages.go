package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

var stage = test_structure.RunTestStage

func apply(t *testing.T, dir string, opts *terraform.Options) {
	test_structure.SaveTerraformOptions(t, dir, opts)
	terraform.InitAndApply(t, opts)
}

func destroy(t *testing.T, dir string) {
	opts := test_structure.LoadTerraformOptions(t, dir)
	defer terraform.Destroy(t, opts)
}

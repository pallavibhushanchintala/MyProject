package test

import (
	"context"
	"strings"
	"testing"

	"github.com/Azure/azure-sdk-for-go/services/containerservice/mgmt/2020-02-01/containerservice"
	"github.com/Azure/go-autorest/autorest"
	"github.com/Azure/go-autorest/autorest/azure/auth"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

// ValidationContext has information about the ambient test environment
// when running the validation step.
type ValidationContext struct {
	T                     *testing.T
	Options               *terraform.Options
	Context               context.Context
	Outputs               Outputs
	Subscription          string
	Authorizer            autorest.Authorizer
	ManagedClustersClient containerservice.ManagedClustersClient
}

// Outputs carries around the outputs from deploying the module.
type Outputs struct {
	ClusterName         string
	ResourceGroupName   string
	ResourceGroupID     string
	NodeResourceGroup   string
	DiskEncryptionSetID string
	PublicIPAddress     string
}

// NewValidationContext creates a new context that has all outputs ready for running
// validation operations.
func NewValidationContext(t *testing.T, opts *terraform.Options) ValidationContext {
	ctx := ValidationContext{
		T:       t,
		Options: opts,
		Context: context.Background(),
		Outputs: Outputs{
			ClusterName:         terraform.OutputRequired(t, opts, "cluster_name"),
			ResourceGroupName:   terraform.OutputRequired(t, opts, "resource_group_name"),
			ResourceGroupID:     terraform.OutputRequired(t, opts, "resource_group_id"),
			NodeResourceGroup:   terraform.OutputRequired(t, opts, "node_resource_group"),
			DiskEncryptionSetID: terraform.OutputRequired(t, opts, "disk_encryption_set_id"),
			PublicIPAddress:     terraform.OutputRequired(t, opts, "public_ip_address"),
		},
	}

	// The resource group ID is like
	// /subscriptions/be62f057-87be-48e5-9c5f-c6fc74ac9d19/resourceGroups/testnae62B-zfkvf14i
	// so this is an easy way to get the subscription of the deployed set of
	// resources without having to re-read environment variables.
	ctx.Subscription = strings.Split(ctx.Outputs.ResourceGroupID, "/")[2]

	// Azure SDK for Go needs environment variables to authenticate and read
	// things from the environment.
	authorizer, err := auth.NewAuthorizerFromEnvironment()
	assert.Nil(t, err)
	ctx.Authorizer = authorizer

	ctx.ManagedClustersClient = containerservice.NewManagedClustersClient(ctx.Subscription)
	ctx.ManagedClustersClient.Authorizer = authorizer

	return ctx
}

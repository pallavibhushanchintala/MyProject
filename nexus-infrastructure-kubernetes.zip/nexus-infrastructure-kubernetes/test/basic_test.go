package test

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func TestBasicExample(t *testing.T) {
	const exampleDir = "../examples/basic"

	uniqueID := random.UniqueId()
	opts := &terraform.Options{
		TerraformDir: exampleDir,

		Vars: map[string]interface{}{
			"location":                 "westus2",
			"resource_group_name_base": fmt.Sprintf("test%s", uniqueID),
			"cluster_name_base":        fmt.Sprintf("test%s", uniqueID),
		},
	}

	// Deploy the cluster. Setting SKIP_destroy or SKIP_apply will
	// skip the corresponding stage for easier local test development.
	defer stage(t, "destroy", func() { destroy(t, exampleDir) })
	stage(t, "apply", func() { apply(t, exampleDir, opts) })

	// Validate the cluster works. Setting SKIP_validate will skip
	// this so an apply/destroy cycle can be tested without failing
	// on assertions.
	stage(t, "validate", func() { validateBasicExample(t, exampleDir) })
}

func validateBasicExample(t *testing.T, dir string) {
	opts := test_structure.LoadTerraformOptions(t, dir)
	ctx := NewValidationContext(t, opts)
	validateKubernetesDeployment(ctx)
	validateNetworkWiring(ctx)
}

func validateNetworkWiring(ctx ValidationContext) {
	// Integration - this shows a request to the public IP address is making it
	// all the way through the firewall to the internal load balancer and to a
	// container in the Kubernetes cluster.
	resp, err := http.Get(fmt.Sprintf("http://%s/status/200", ctx.Outputs.PublicIPAddress))
	assert.Nil(ctx.T, err)
	assert.Equal(ctx.T, 200, resp.StatusCode, "httpbin should have returned a 200 response.")
}

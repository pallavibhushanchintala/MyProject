# Digital Nexus Live Repository

This "live repository" is intended to be the 1:1 representation of what's deployed for Digital Nexus services.

## Repository Layout

The layout here is:

```text
subscription
 └ _global
 └ location
    └ _global
    └ environment
       └ resource
```

Where:

- **Subscription**: Azure subscription ID. The GUID is used to ensure uniqueness since subscription names are not necessarily unique.
- **Location**: The geographic location in Azure like `westus`, `centralus`, `eastus`, `germanynorth`, and so on. There may also be a `_global` folder that defines resources that are available across all the locations in this subscription, such as service principals, DNS entries, and so on.
- **Environment**: The logical environment(s) with deployed components (e.g., dev, test, prod). There may also be a `_global` folder that defines resources available across all the environments in this location.
- **Resource**: Within each environment, you deploy all the resources for that environment, such as Redis instances, VM scale sets, databases, load balancers, and so on. Each resource has its own module repo. Resources may be shared constructs (one Redis instance all services can use) or they may be service-specific (an Azure SQL database for a service that gets added to a common Azure SQL server).

## Workflow

All development for the infrastructure is done via pull requests using trunk-based development. There are no deployments from branches; individual modules get tested outside this repo. If you're changing stuff in here, it's "go time." No turning back.

**Create a branch.** Your branch should be named something like `feature/some-feature-name` or `feature/12345` (where `12345` is the work item associated with your task). This is consistent with standard Gitflow naming and makes it easier to find all the branches.

**Make your changes in the branch but do not deploy.** Change what you need, if you can do some local tests, but don't deploy anything to a real environment. The build pipeline handles deployment.

**Create a pull request for your changes.** The pull request is where things will get reviewed and, eventually deployed. If everything is reviewed and deployed properly, the change should go right into `master` so the `master` branch stays a 1:1 representation of what's deployed.

When you create the pull request, it's either _deployable_ (like a change to a component) or it's _not deployable_ (like an update to the README). Inside your pull request _description_ in Azure DevOps, be sure to include a JSON block that explains which it is.

For a _deployable_ pull request, include the expected Terraform version to use and the path to the module. Note that _most_ modules use the global Terraform version as set in the `terraform.hcl` at the root of the subscription.

````text
```json
{
  "terraform": "0.13.3",
  "module": "35abf82e-a23b-49c4-8bae-88baead6f7d3/westus2/dev/cosmosdb"
}
```
````

For a _non-deployable_ change, include a JSON block that says to skip deployment.

````text
```json
{
  "deploy": false
}
```
````

Be sure to include the `json` keyword by the backtick fences - the whole thing has to be there. There is a pull request template in the `.azuredevops` folder to help with this.

**Non-deployable changes get minor analysis.** There's not much to do here. These can be brought in easily. This is basically where the pipeline stops for those. Otherwise...

**Deployable changes will be serialized.** You can only make one change to a module at a time. If there are any pending pull requests that act on the same module, the build will fail - you need to take care of the earlier pull requests before you can plan and deploy something new to the same module.

**Deployable changes will generate a Terraform plan and graph.** These will be stored as artifacts for approvers and auditing.

**Approvers will be asked to approve the deployment of the plan.** Approvers should take the time to look at the generated plan and verify that it's going to do what it's expected to do. Also make sure any final code review has happened. **Once approved, deployment will begin.**

**Terragrunt will deploy the approved plan.** The previously generated plan will be used to deploy changes. If the remote state has been changed (e.g., if the environment has changed out from under you) this will get detected. You'll have to restart the build, generate a new plan, and re-deploy.

**On failure, you can retry.** If the deployment failed due to an issue like eventual consistency, you will need to restart the build, generate a new plan, and re-approve/re-deploy. Be sure to use the "Queue Build" option on the pull request rather than manually running the build again or the build won't be seen as associated with the PR.

**On success/completion, merge the pull request.** Once the code from the PR has been deployed, the pull request should immediately be merged. This will keep the `master` branch a 1:1 representation of what's deployed.

**Delete your feature branch.** Once the PR is merged, remove your feature branch. There's no need to keep them around and it can become a maintenance challenge later.

## Removing a Component

There isn't currently an automated way to handle _removing_ a component once it's deployed. Since each module is independently deployed, simply removing the module just means it won't be deployed again; it doesn't actually remove the associated infrastructure.

The process for removing a component is:

- Work with the infrastructure maintainers - you're going to submit a PR and need to have it (basically) immediately accepted. You'll also need to make there are no pending changes on the module you're going to be removing.
- Create a branch for the removal: `git checkout -b feature/remove-module`
- Manually run Terragrunt on the component to remove it: `terragrunt destroy path/to/module`
- Verify the plan for removal. When it looks good, approve it.
- Delete the module from source.
- Commit the change.
- Submit a pull request for the removal. Mark it as a _non-deployable_ change so it will get light validation but won't try to deploy anything.
- Accept the pull request into the repo immediately so no further changes are made to it.

## Base Component Creation / Cloud Prerequisites

**There are some things that need to be set up one time before you can use this repo to deploy.** These items are listed in [the environment deployment playbook](https://dev.azure.com/F-DC/Digital%20Nexus/_wiki/wikis/architecture/418/Environment-Deployment-Playbook). These items are not controlled by Terraform - things like the Terraform backend.

## Remote State

Remote state is stored in a single storage account but in different containers on a per-environment basis.

- Single storage account to make management generally easier.
- Different containers to allow different access policies for each logical environment. **State may store sensitive data like passwords passed as parameters.**

The containers are named by environment - `tfstate-dev`, `tfstate-prod`. Inside each container the state for the component is based on the relative path of the component from the root of this repo. For example, `35abf82e-a23b-49c4-8bae-88baead6f7d3/westus2/dev/cosmosdb/terraform.tfstate`.

**The containers must exist before deployment can happen.** They won't be created automatically.

Authentication with the `azurerm` backend is done via environment variables. [This is explained in the wiki here.](https://dev.azure.com/F-DC/Infrastructure/_wiki/wikis/Infrastructure/155/Azure-Authentication)

## Using VS Code

The workspace has a set of recommended extensions that can help you work with Terraform and Terragrunt. In the VS Code extensions window, "Show Recommended Extensions" or enter `@recommended` to see them as "Workspace Recommendations."

The Azure Terraform (`ms-azuretools.vscode-azureterraform`) extension is very Azure-specific and does not support all the features of the `hashicorp.terraform` extension. It is recommended you use `hashicorp.terraform` instead.

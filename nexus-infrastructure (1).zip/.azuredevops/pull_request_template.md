<!-- If this is a **deployable change** update this block and remove the other block. -->
```json
{
  "terraform": "1.2.5",
  "module": "35abf82e-a23b-49c4-8bae-88baead6f7d3/westus2/dev/cosmosdb"
}
```

<!-- If this is a **non-deployable change** use this block and delete the other one. -->
```json
{
  "deploy": false
}
```

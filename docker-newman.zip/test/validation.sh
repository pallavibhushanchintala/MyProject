imageName=$1
echo "Image to validate: " $imageName

echo "Creating reports folder."
mkdir -p reports

echo "Run Newman with customized JUnit report."
docker run --rm -v $(pwd):/etc/test/newman/ -v $(pwd)/reports:/etc/newman/newman/ $imageName run ../test/newman/validation.postman_collection.json --reporters 'junit,htmlextra'

echo "Ensure JUnit report is present."
cd reports
junitReportCount=$(ls -1 newman-run-report-*.xml 2>/dev/null | wc -l)
if [ $junitReportCount != 1 ]
then
    echo "Error: JUnit report not generated." 1>&2
    exit -1
fi

echo "Done."

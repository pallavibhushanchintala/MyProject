# Newman Container

This builds a customized Newman container that based on the [postman/newman:alpine](https://github.com/postmanlabs/newman/tree/develop/docker/images/alpine) image for running Postman test collections with the following add-ons:

- JUnit reporter
- [HtmlExtra reporter](https://www.npmjs.com/package/newman-reporter-htmlextra)
- `entrypoint.sh` script to ensure it can run in Kubernetes context

## Usage

This container doesn't contain any Postman collection as it's expected for each test suite to to build its own container based on this container and include the Postman collection and environment variables. If you want to test run this container on your local machine, you will need to use `-v` flag to map two volumes: one for the Postman collection, one for the reports generated report output.

```powershell
# Docker doesn't like Windows path separators.
$current = $pwd -replace '\\','/'

# Run the container and mount the locations you need.
&docker run --rm `
    -v $current/test:/etc/newman/test `
    -v $current/report:/etc/newman/report `
    digitalnexus.azurecr.io/digital-nexus/newman:alpine `
    run test/your_tests.postman_collection.json `
    --reporters htmlextra,junit `
    --reporter-htmlextra-export report/newman_htmlextra.html `
    --reporter-junit-report report/newman_junit.xml

# If you want to try the local test simulations, mount those.
&docker run --rm `
    -v $current/test:/etc/newman/test `
    -v $current/artifacts/log:/etc/newman/report `
    digitalnexus.azurecr.io/digital-nexus/newman:alpine `
    run test/validation.postman_collection.json `
    --reporters htmlextra,junit `
    --reporter-htmlextra-export report/newman_htmlextra.html `
    --reporter-junit-report report/newman_junit.xml
```

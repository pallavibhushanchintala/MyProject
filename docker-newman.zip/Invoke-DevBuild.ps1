﻿<#
.SYNOPSIS
    Runs a local dev build to test container changes.
.DESCRIPTION
    Builds and tests a local version of the container. Represents a smaller
    version of what happens in the matrix pipeline.
.EXAMPLE
    ./Invoke-DevBuild.ps1
#>
[CmdletBinding()]
Param(
)

$tag = "newman-local"
&docker build -t $tag --build-arg GIT_COMMIT=local --build-arg GIT_REPO=local .

New-Item "artifacts/log" -ItemType Directory -Force | Out-Null
$logDir = (Join-Path -Path $PSScriptRoot -ChildPath "artifacts/log") -replace '\\', '/'
$testDir = (Join-Path -Path $PSScriptRoot -ChildPath "test") -replace '\\', '/'
&docker run --rm `
    -v $testDir`:/etc/newman/test `
    -v $logDir`:/etc/newman/report `
    $tag `
    run test/validation.postman_collection.json `
    --reporters htmlextra,junit `
    --reporter-htmlextra-export report/newman_htmlextra.html `
    --reporter-junit-export report/newman_junit.xml

# Implementation

The Sonatype scan tasks are added to the three following templates under the [`azure-pipeline-templates` project](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates):

- [`build-dotnetcoreapplication.yml`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/build-dotnetcoreapplication.yml)
- [`build-dotnetcorelibrary.yml`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/build-dotnetcorelibrary.yml)
- [`build-apispecification.yml`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/build-apispecification.yml)

The scans results are routed to the Nexus Lifecycle by creating an application ID for each of the projects, that consists of the UAID plus the name of the repository that is being built:

```yaml
applicationId: $(uaid)_$(Build.Repository.Name)
```

# UAIDs and Domains

Each domain must have its own UAID stored in its own variable group in the Azure Library, the domain variable group must also be added to the azure-pipeline.yml file of each project.

**Example:**

```yaml
variables:
  - group: banking-domain
```

[Here is the list](../Domains.md) of the current domains and their UAIDs.

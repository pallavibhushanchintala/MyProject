# Continuous Integration and Deployment Pipeline Templates

There is a repo with templates for [common Azure DevOps build and deploy tasks and pipelines here](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates).

The README in that repository explains how to use them, and each template there is documented with usage instructions inside the template.

Azure DevOps also has documentation on how templates get used in pipelines to help you round out your understanding.

The templates use our Azure DevOps Custom Tasks - you can use these tasks outside the pipeline templates, too.

Operations on the AKS cluster are performed using the Azure DevOps [kubectl task](https://docs.microsoft.com/en-us/azure/devops/pipelines/tasks/deploy/kubernetes?view=azure-devops).
This Azure DevOps task utilizes a service connection to authenticate into AKS with cluster user credentials by default.
An optional `useClusterAdmin` task parameter is available to operate on the cluster with cluster admin credentials.

**Current Limitations** For security reasons, cluster user credentials are preferred when operating against an AKS cluster.
With [AAD integration](https://docs.microsoft.com/en-us/azure/aks/managed-aad) and [RBAC authorization](https://docs.microsoft.com/en-us/azure/aks/manage-azure-rbac) enabled on our AKS clusters,
the service principal associated with the service connection should be assigned the appropriate roles in Azure.

For developers operating on the cluster via *kubectl* from their development machines, interactive login `az login` to Azure is possible.
However, interactive login cannot be used for the service principal during the execution of Azure DevOps pipelines.

Microsoft's recommended solution is the [kubelogin](https://github.com/Azure/kubelogin) credential plugin, and the relevant flow is the [service principal login flow](https://github.com/Azure/kubelogin#service-principal-login-flow-non-interactive).
This plugin is in its initial releases and has not been incorporated into the Azure DevOps *kubectl* task at this time.

References:

* [Developer Community Feature Request](https://developercommunity.visualstudio.com/t/support-for-aks-managed-non-interactive-sign-in-wi/1182256)
* [GitHub Issue](https://github.com/Azure/kubelogin/issues/20)
* [Stack Overflow Question](https://stackoverflow.com/questions/54004007/azure-devop-pipelines-authentication-to-aks-with-azure-ad-rbac-configured)
* [Server Fault Question](https://serverfault.com/questions/963481/how-to-grant-a-service-principal-access-to-aks-api-when-rbac-and-aad-integration)

In the meantime, our Azure DevOps custom tasks and templates make use of the `useClusterAdmin` parameter when using the *kubectl* task in order to operate on the cluster with cluster admin credentials.

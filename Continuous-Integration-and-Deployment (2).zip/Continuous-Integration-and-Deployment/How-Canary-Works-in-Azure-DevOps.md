Canary deployment using Azure DevOps pipelines in Istio is actually a somewhat complex process. Understanding how it works can help you figure out what to look at when something goes sideways.

[[_TOC_]]

## Kubernetes Objects

You need to be familiar with several Kubernetes objects (including Istio objects) in order to put all the pieces together.

- `Pod`: One or more containers that are deployed as a set. When you deploy "two replicas" of a microservice, you'll get two `Pods` that each have:
  - The microservice container.
  - An Envoy sidecar container that helps Istio properly route traffic and enforce mTLS connections.
- `Deployment`: Controls the `Pods` that get deployed. It's just an easier way to control `Pods`. We don't generally deploy `Pods`, we deploy `Deployments`.
- `Service`: Exposes access to `Pods` to the Kubernetes network. This is also the base level of load balancing for Kubernetes. If you have two `Pods`, any callers will talk to the `Service` to get information from those `Pods` and the Kubernetes load balancing mechanism will handle traffic. A `Service` knows which `Pods` to target by matching on `labels` that are applied to the `Pods`.
- `VirtualService`: An Istio mechanism for more accurate load balancing. When Kubernetes load balances with a `Service`, it's very simple round-robin. Istio enhances this using `VirtualService` by allowing you to specify actual weights associated with pods. The `VirtualService` also handles exposing a `Service` through a `Gateway` (the Istio version of an `Ingress`). This works by interacting with the Envoy sidecar in each `Pod`.
- `TrafficSplit`: [The "Service Mesh Interface" (SMI) spec](https://github.com/servicemeshinterface/smi-spec) provides a service-mesh abstraction interface so you can control any service mesh (Istio, Linkerd, etc.) using a single mechanism. In Istio, a `TrafficSplit` roughly equates to a `VirtualService` but is far less flexible.

## Moving Pieces

- Istio SMI controller: Istio doesn't natively understand Service Mesh Interface constructs. If you want to deploy a `TrafficSplit` and get a `VirtualService` generated for you, you need an adapter. [We wrote a custom adapter](https://dev.azure.com/F-DC/Digital%20Nexus/_git/istio-smi-controller) because the [official adapter](https://github.com/servicemeshinterface/smi-adapter-istio) not only has been discontinued but doesn't support custom annotations. Our `VirtualService` instances need to expose `Services` to the outside world and `TrafficSplit` doesn't have the ability to natively understand that.
- Azure DevOps pipeline: The pipeline (and associated templates) [drive the AzDO `deployment` task with a `canary` strategy](https://docs.microsoft.com/en-us/azure/devops/pipelines/ecosystems/kubernetes/canary-demo?view=azure-devops&tabs=yaml).
- `KubernetesCanary` task: We have a [custom build task](https://dev.azure.com/F-DC/Infrastructure/_git/pipeline-task-kubernetes-canary) that is heavily based on the usual AzDO [`KubernetesManifest` task](https://docs.microsoft.com/en-us/azure/devops/pipelines/tasks/deploy/kubernetes-manifest?view=azure-devops). Our version of the task enables support for adding annotations to the `TrafficSplit` so it creates the correct `VirtualService` during canary.

## Load Balancing and Statistics

When a canary is created, you end up with _three_ instances of the service being deployed:

- The `stable` version, which is the thing that's already deployed. This can scale up or down as needed.
- The `baseline` version, which is a _copy_ of the `stable` version, but of a fixed size. This is like the "control" group of the canary experiment.
- The `canary` version, which is the _new_ version of the service. This is the same size (same number of `Pods`, etc.) as the `baseline` version. These are the same size so you can compare "apples to apples," statistically speaking. The same amount of resources will be allocated, etc.

Load balancing happens across all three of these. You can calculate how much is hitting stable like this:

```text
baseline = canary
stable = 100 - (baseline + canary)
```

Here's a table that helps show what traffic allocations you can expect:

| Azure DevOps Canary Percentage | Stable | Baseline | Canary |
| ------------------------------ | ------ | -------- | ------ |
| 25%                            | 75%    | 12.5%    | 12.5%  |
| 50%                            | 50%    | 25%      | 25%    |
| 75%                            | 25%    | 37.5%    | 37.5%  |
| 99%                            | 1%     | 49.5%    | 49.5%  |

If you end up allocating 100% of the traffic to the canary, that indicates you're done with the test (no more traffic on stable!) and it's time to promote the canary to be the new stable version of the service.

## The Process

The basic process is:

1. Generate the manifests for the objects to deploy. This is based on our [microservice Helm chart](https://dev.azure.com/F-DC/Digital%20Nexus/_git/microservice-helm-templates) that has the `Deployment`, `Service`, and other things needed for a service.
2. The default `Service` for the `Deployment` is cloned and set for `stable` traffic.
3. The `stable` components (`Service`, `Deployment`, etc.) are cloned as `baseline` with a fixed/specified size.
4. The manifests for the new items are deployed and tagged as `canary`. At this point there are _four Kubernetes `Service` entities_: the default one, that doesn't point at any particular `Deployment`; `stable` which only targets the `stable` deployment; `baseline` which only targets the `baseline` deployment; and `canary` which targets the `canary` deployment.
5. A `TrafficSplit` is deployed which points 100% of the traffic at the `stable` version of the service.
6. For each increment to allocate to canary (e.g., 25%, 50%, 75%)...
    1. Update the `TrafficSplit` to the new load balancing makeup.
    2. Run tests against the load balanced services.
    3. Analyze the results; abort if there are issues.
7. If the run is aborted:
    1. Redirect the `TrafficSplit` to the `stable` service.
    2. Delete the `baseline` and `canary` instances of things.
8. If the run succeeds:
    1. Redirect the `TrafficSplit` to 100% point to the `canary` service.
    2. Update the `stable` objects so they use all the new things from the `canary`.
    3. Redirect the `TrafficSplit` to 100% point to the `stable` service.
    4. Delete the `baseline` and `canary` instances of things.

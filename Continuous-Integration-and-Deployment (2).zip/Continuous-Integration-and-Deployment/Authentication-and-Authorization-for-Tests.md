For the purposes of testing (which includes, but is not limited to: integration testing, load testing, security scanning, and exploratory testing), we'll need to provide a mechanism for [authentication](../Identity-and-Access-Management/Microservice-Authentication.md) such that tests may access services and be properly [authorized](../Identity-and-Access-Management/Microservice-Authorization.md) to accomplish those tests.

[[_TOC_]]

## General Concerns

Not specific to any one test framework, there are general concerns to consider as we determine the right way to authenticate during testing.

### Standardization

Where possible, we want to try to standardize the way we pass credentials and endpoints into the test mechanisms so there aren't 100 different ways to try to remember to do things. Given that, we need to consider:

- Naming conventions and built-in variable names for test systems: We don't want to clash with anything.
- Disambiguation from other concepts in test systems: We don't want the names or purposes of things to be confusing.

To address this, you'll see standards here around:

- Location for local `.env` files.
- Naming for local `.env` files.
- Naming for the environment variables used in local and automated testing.
- Apigee test applications (which also follow the [Apigee guidelines](../Coding-Guidelines/Apigee-Guidelines.md)).

### Application Authentication vs. User Authentication

Some tests will need to run _as an application_ while others need to run _as a user_. As we design our test authentication systems, we need to consider both aspects.

> :warning: **The Day One release only supports application authentication.** The [Day One authentication strategy](../Identity-and-Access-Management/Day-One/Proposal-Microservice-Authentication-Authorization-Day1.md) only allows for `client_credentials` token support - authentication as an application. We'll not be fleshing out the complete test authentication mechanism until user credentials are also supported; however, design decisions we make need to ensure we don't _stop_ user authentication from working.

### Do NOT Check In Credentials

Some test platforms (e.g., Postman) need a "default value" defined for a variable that then is _overridden_ by a passed-in value at runtime. **Do not check in credentials.** Where there are secrets required (like `CLIENT_SECRET` for a `client_credentials` token), either leave the default value _blank_ or use some arbitrary text like `placeholder`.

### Local Test Execution

There is a need to allow local test execution - executing the tests from a local workstation and either targeting a locally-running copy of a service or a remote instance of a service. The important consideration here is tied to the above note that we should **never check in credentials.** It's very easy for a developer to set up their own runtime environment "just temporarily" with some real credentials and then accidentally commit that information. The local test execution mechanism needs to easily keep credentials separate from the code, [similar to how `dotnet user-secrets`](https://docs.microsoft.com/en-us/aspnet/core/security/app-secrets) allows for development time secrets.

**We store cross-test user secrets as `.env` files.** A "dot-env" file (`.env`) is a very simple file that stores key/value pairs used to set environment variables. It originated [with Node.js](https://github.com/motdotla/dotenv) as a way to [work with 12-Factor app configuration](https://12factor.net/config) at development time but has grown in popularity with support in [Linux shells](https://direnv.net/), [Python](https://pypi.org/project/python-dotenv/), [Ruby](https://github.com/bkeepers/dotenv), [Haskell](https://hackage.haskell.org/package/dotenv), and more.

**Never check in `.env` files.** The point of these is to be per-user/per-environment and are not part of the product source.

**Store your `.env` files in your user home folder (`~`).** For example, on MacOS this is `/Users/yourusername`; on Windows it's `C:\Users\yourusername`. By using this as a standard location, we can set up interactive execution configurations (like in VS Code `launch.json`) and things should "just work" across users.

To start, we'll use a single file `dsl-integration-test.env`. That file will look _similar_ to this:

```text
CLIENT_ID=insert-your-test-client-id-here
CLIENT_SECRET=insert-your-test-client-secret-here
TOKEN_ENDPOINT=url-to-token-endpoint
```

You'll need to plug in your test application client ID and client secret in your `.env` file. Why didn't we just put that in here for you to copy paste? **Never ever check in credentials.** Plus, it may be that each _user_ needs a separate "application" for interactive testing purposes. That's not something we can cover here.

In PowerShell you can add this command to your PowerShell profile to enable `Set-DotEnv` to read a `.env` file into the local environment. (You can get this and many other commands from [Travis's PowerShell profile](https://github.com/tillig/PowerShellProfile).)

```powershell
<#
.Synopsis
   Parses a .env file and loads it into the current environment.
.PARAMETER File
   The file that should be parsed into the environment.
.DESCRIPTION
   Reads a standard .env file and brings the values into the current environment.

   - Each line in an env file should be in VAR=VAL format.
   - Lines beginning with # are processed as comments and ignored.
   - Blank lines are ignored.
   - There is no special handling of quotation marks. This means that they are part of the VAL.
.EXAMPLE
   Set-DotEnv ./terraform.env
#>
function Set-DotEnv {
    [CmdletBinding(SupportsShouldProcess = $True)]
    Param
    (
        [Parameter(Mandatory = $True,
            ValueFromPipeline = $True,
            ValueFromPipelineByPropertyName = $True,
            Position = 0)]
        [ValidateNotNullOrEmpty()]
        [string]
        $File
    )

    Process {
        If ( -not (Test-Path $File)) {
            throw "Unable to find file $File"
        }

        Get-Content $File |
        ForEach-Object { $_.Trim() } |
        Where-Object { -not $_.StartsWith('#') -and -not [string]::IsNullOrEmpty($_) } |
        ForEach-Object {
            $kvp = $_ -split "=", 2;
            If ($PSCmdlet.ShouldProcess("$($kvp[0])", "set value $($kvp[1])")) {
                [Environment]::SetEnvironmentVariable($kvp[0], $kvp[1]) | Out-Null
            }
        }
    }
}
```

In VS Code, several `launch.json` configurations allow you to specify an `envFile` that will automatically be read and parsed for the interactive runtime/debug environment. Here's an example of a Java launch task:

```json
{
  "configurations": [
    {
      "envFile": "~/dsl-integration-test.env",
      "mainClass": "Sample.App",
      "name": "Launch App",
      "projectName": "Sample",
      "request": "launch",
      "type": "java"
    }
  ],
  "version": "0.2.0"
}
```

Note in that example we used `~/dsl-integration-test.env` as the `envFile` - by consistently storing our `.env` files in our home folders and using a standard naming scheme, we can provide ready-to-go launch configurations for interactive execution.

Docker allows you to use a `.env` file [in `docker run` commands via the `--env-file` parameter](https://docs.docker.com/engine/reference/commandline/run/#set-environment-variables--e---env---env-file) so this makes the `.env` format usable both in an IDE and in packaged/built test containers.

**We have [a PowerShell module for provisioning test tenants and applications](https://dev.azure.com/F-DC/Digital%20Nexus/_git/fiserv-services-operations)** that can be used on a per-developer basis to create these items for local test runs.

### Data Population and Test Tenants

In integration testing, we create a new test tenant in which to verify functions and subsequently tear down that tenant when testing is over. This is done for a few reasons:

1. We can exercise our APIs to ensure we have the right API for manipulating our data. If we can't do data population or setup via our APIs it shows we have a missing API.
2. We keep test data isolated from real tenants. There's no chance to accidentally swap in a real tenant ID somewhere.
3. We keep test data isolated from other tests. We won't have tests arbitrarily failing because one set of tests (or a developer working interactively) changed some data from its expected format.

Since we create the tenant at test time, we don't necessarily know the tenant ID that needs to be in an access token until the tenant is provisioned. It's not a value we can hard-code into a build variable. The tenant ID claim in the token is used by the services to determine which tenant the application should be able to access. Other parameters, like user IDs, are assumed to be members of that tenant.

Since the tenant ID is associated with the client application when working with `client_credentials` grants, it implies that we not only need to provision a new tenant for testing but _also an integration test application_.

**We have [a PowerShell module for provisioning test tenants and applications](https://dev.azure.com/F-DC/Digital%20Nexus/_git/fiserv-services-operations)** that can be used in the build pipeline.

## Apigee

### Bootstrap Applications

We have some "bootstrap" applications that are associated with the root/bootstrap tenant. These applications can be used to call the `/directory/v1/tenants` endpoint using a `client_credentials` token so we can provision test tenants. These can be used in an automated environment (build/deploy pipeline) in combination with [our PowerShell module](https://dev.azure.com/F-DC/Digital%20Nexus/_git/fiserv-services-operations) to provision test tenants/apps.

**These are not the test tenants/apps you use to _run_ your tests.** These are for _provisioning_ the test tenants/apps you'll use.

For the [Development subscription](../Infrastructure-Management-and-Security/Azure-Subscription-Details.md):

- Apigee organization: `firstdatanp`
- Apigee environment: `test`
- Application: [`dsl-bootstrap` (`DSL - Bootstrap Application`)](https://apigee.com/organizations/firstdatanp/apps/details/0be6b3bc-3cd9-41a7-b45b-4da60ed1e6d9)
- Client ID: `RL4ffFjnp6TAGkY4WSE5yjuq3qYHf9TH`
- Client secret: (look this up in the Apigee portal)
- Token lifetime: 3600000 (one hour)
- Tenant ID: `b7ac4318-6621-442f-a1c1-2e8aea509c00`

### Test Applications

The [Apigee guidelines](../Coding-Guidelines/Apigee-Guidelines.md) include specific guidance around naming and tagging for test applications. A quick overview:

| Application                      | Format                             | Example |
| -----------                      | ------                             | ------- |
| Name                             | `dsl-integration-test-test-run-id` | `dsl-integration-test-55aa6e69-e7e9-45b2-b731-3649a45859f1` |
| Display Name                     | `DSL - Integration Test (test-run-id/tenant-id)` | `DSL - Integration Test (55aa6e69-e7e9-45b2-b731-3649a45859f1/4d468836-c1e8-4507-8504-36646486e5e7)` |
| Attribute: `TenantId`            | `tenant-id`                        | `4d468836-c1e8-4507-8504-36646486e5e7` |
| Attribute: `AccessTokenLifetime` | `time-in-ms`                       | `360000` |
| Attribute: `TestRunId`           | `test-run-id`                      | `55aa6e69-e7e9-45b2-b731-3649a45859f1` |

See the [Apigee guidelines](../Coding-Guidelines/Apigee-Guidelines.md) for a complete overview of all the guidelines. You can [look at the `New-FiservTestRun` command code](https://dev.azure.com/F-DC/Digital%20Nexus/_git/fiserv-services-operations?path=%2Fsrc%2Ffunctions%2FNew-FiservTestRun.ps1&version=GBmain&_a=contents) to see exactly how a test application gets created.

## Load Tests: Gatling

Gatling tests are executed during automation by deploying a Kubernetes `Job`. Environment variables will be used to provide configurable settings and will be retrieved inside the test using the Scala `Properties.envOrNone("NameOfProperty")` or `Properties.envOrElse("NameOfProperty", "DefaultValue")` methods. We use plain environment variables instead of `JAVA_OPTS` for a few reasons:

- It provides easier integration for local/interactive testing than trying to create `JAVA_OPTS`.
- It provides easier integration for Helm charts and automation deployments than trying to create `JAVA_OPTS`.
- It's language/test type agnostic - we won't be using environment variables in one spot but Java system properties somewhere else.

As an example, if we wanted to pass in a client ID to a Gatling test, we'd set a `CLIENT_ID` environment variable and read that:

```scala
val clientId: Option[String] = Properties.envOrNone("CLIENT_ID")
```

Unfortunately, Gatling doesn't have any real OAuth2 support built-in so we'll need to build that. A reasonable strategy for this is [outlined in this blog article](https://devqa.io/gatling-oath2-authentication/).

To handle authentication in Gatling tests:

- Test execution should provide environment variables named:
  - `CLIENT_ID` (string)
  - `CLIENT_SECRET` (string)
  - `TOKEN_ENDPOINT` (string/URL)
- Custom code will read and validate the presence of these variables.
- Custom code will execute the token retrieval and renewal operations.
- Load tests will include the access token retrieved as a header during testing.

When running the tests as part of the Kubernetes `Job`, the environment settings will be added to the job at deploy time so they're available in the container.

When running the tests locally the developer will be required to provide the appropriate environment variables for the runtime. We can enable this out-of-the-box for VS Code by configuring the appropriate `launch.json` as noted earlier. For other runtime environments, use the `.env` file to bring the values in.

To start, we'll end up with the OAuth2 token retrieval code as part of each Gatling project. In the future, we should create a shared library that can be used so we don't have to copy/paste each time.

## Integration Tests: Postman

Postman tests don't directly consume system environment variables. Instead, providing a variable input to a Postman test (running via the Newman CLI) requires three steps:

1. Create a Postman environment for your tests. Usually we have `Development` and `Production` environments for each test collection.
2. Create a variable in that environment with a specific name like `client_id`.
3. When running the Newman CLI, provide a `-e` for your full Postman environment and a `--env-var` for each override.

For example:

```powershell
newman run banking-v1-accounts.postman_collection.json `
  -e banking-v1-accounts.Development.postman_environment.json `
  --env-var "CLIENT_ID=insert-client-id-here" `
  --env-var "CLIENT_SECRET=insert-client-secret-here"
```

Note that [Postman doesn't have the ability to read from the system environment](https://github.com/postmanlabs/postman-app-support/issues/1603) nor does it have [the ability to read external files](https://github.com/postmanlabs/postman-app-support/issues/7210). This isn't as much a problem with `newman` and the CLI, but if you want to use the main Postman app to build and try out tests, it's very limiting.

To handle authentication in Postman tests:

- All Postman _environments_ should define the following parameters:
  - `CLIENT_ID` - default/initial value `client_id`
  - `CLIENT_SECRET` - default/initial value `client_secret`
  - `endpoint_token` - set the default value to a real dev or prod token endpoint (based on the environment)
- Custom code will be set up to run as a pre-request script:
  - Read and validate the presence of these variables.
  - Execute the token retrieval/renewal operation. [Here's an example of how to do that.](https://allenheltondev.medium.com/how-to-automate-oauth2-token-renewal-in-postman-864420d381a0)
  - Set the token as `client_credentials_access_token` in the environment to allow it to be differentiated from user credentials. If there are other values that need to be stored in the environment related to the token, prefix with `client_credentials_` to ensure we're able to accommodate user tokens, too.
- Naming conventions should indicate:
  - `CAPITAL_LETTERS` for things that are expected to always come from the container environment.
  - `lowercase_letters` for things that can be swapped out but likely default as part of the Postman environment file.

When running in `newman` CLI, provide the required overrides on the command line with `--env-var`. This is how the automated processes will work, but you can also use this mechanism from a dev machine.

When running interactively with the Postman app, you can [set the environment so it doesn't automatically persist changes](https://blog.postman.com/how-to-use-api-keys/). This way "real values" don't make it into the environment and get accidentally committed. Unfortunately, due to the previously mentioned limitations around file and system environment access, to run Postman in an interactive scenario you'll need to copy/paste the values into the "current value" field in the Postman environment. When exporting/saving environment data, Postman only exports the original values so we know the "current value" (which may hold sensitive data) won't accidentally go into source control.

We'll need to copy/paste the custom code into each integration test collection. There is not a way to share the code via file, even if we try faking it with [this tip about reusing helper functions via `eval`](https://medium.com/distant-horizons/testing-apis-with-postman-10-common-challenges-solutions-c4674c78528d) and the [access to certain external libraries](https://learning.postman.com/docs/writing-scripts/script-references/postman-sandbox-api-reference/#using-external-libraries).

> :bulb: **It may be worth switching to Pester/PowerShell or some other tool after Day One release.** We started our integration tests with a very heavy SpecFlow and C# solution. We later migrated to Postman and Newman because writing tests interactively there is pretty easy and we had very few tests per API. We chose not to use SoapUI due to the reasonable weight that also brought with it. However, as time goes on it seems we may need a balance between the capabilities of a full programming language and the easy reading/scripting of a simpler tool. It seems like Pester testing with a PowerShell execution engine might fit that bill nicely. No research has been done on this - or on other tools that also might do the job - but it's something to consider. We could fairly easily create a shareable PowerShell library to augment Pester with some convenience methods to ease REST API testing.

## Security Scanning

### OWASP Zed Attack Proxy (ZAP)

> :bulb: **At the time of this writing, ZAP scanning starting to be rolled out in the CI pipeline for microservices.** It is currently only run just after build against a local version of the service, not against a deployed version in Kubernetes. There may be value in enhancing this to run against services deployed in the cluster _through Apigee_ since some of the OWASP mitigations may be in layers like Apigee and Istio rather than part of the microservice application code.

ZAP in a REST API scanning automation scenario is generally executed [via a Docker image](https://www.zaproxy.org/docs/docker/api-scan/) that is provided an OpenAPI specification and an endpoint. This is very different than the "interactive web site mode" that most examples show and means some of the examples need to be adjusted or may not work at all.

ZAP does not provide out-of-the-box OAuth2 support - you have to write that yourself. [This blog article](https://www.devonblog.com/continuous-delivery/owasp-zap-for-apis-using-custom-script-based-authentication/) shows how you can do that, though it also assumes a "ZAP server" is running somewhere and the API for that server is accessible. Likely this isn't something we'll have as we run a scan via Docker, but it may provide some ideas as to how to get things working.

ZAP isn't like integration tests where some tests are for apps and some tests are for users; to differentiate between app and user scan results, we'd actually run two full scans with two different sets of credentials. When we write our scripts to authenticate, that means we'll probably need to have some sort of intelligence built in to handle different scenarios - anonymous, app, user.

> :warning: **Speculation incoming!** Here's where "we don't know what we don't know." Actually getting a workable, concrete design with a recommendation is going to require a POC where we test options, dive in, and see what's actually available. However, here are some initial places to start looking:
>
> - `zap-api-scan.py` script offers some command-line parameters that may help:
>   - `-z` allows you to pass in config values. That may be a way to provide credentials.
>   - `--hook` allows you to [specify a Python script that handles ZAP events](https://www.zaproxy.org/docs/docker/scan-hooks/). The `zap_started` event allows you to run some script before executing a scan, and that may be where we read config (or environment? or?) for credentials and do the authentication.
> - The [`zap-api-scan.py` script source](https://github.com/zaproxy/zaproxy/blob/main/docker/zap-api-scan.py) shows that basically what's happening in the Docker image is that a ZAP server is started and various calls are marshaled between the Python script command line parameters and API calls to that server. Reading through this may help provide some ideas as to how to either hook in at a different level or possibly use an external script to poke at the ZAP API and get the desired results.
> - Since we'll be running this from Docker, don't forget you can put environment variables into the Docker container at runtime. If we're not passing credentials via `-z` command line parameters, environment variables could be an option.

### Fortify WebInspect

**At the time of this writing, Fortify WebInspect scanning is not in place in the CI/CD pipeline for microservices because it's not required for REST APIs.** We did some research on how to integrate WebInspect into the CI/CD pipelines for microservices and it was non-trivial. Part of the problem is how it's very much geared toward UI-based web applications and not services. On asking GCSS about this, we found WebInspect was not a requirement for REST API services.

[Here's the Fortify WebInspect documentation](https://www.microfocus.com/documentation/fortify-webinspect/2020/) for future reference, should this change. There's a lot and it's not obvious how we get from this to actually getting scans in place. There's no way to guess - without some actual Fortify WebInspect experience - where we'll be able to plug in credentials in a secure fashion. It may be easy, like running the scan from a Docker container and providing environment variables; or it may be far more cumbersome, like having to set up a lot of stuff in a big UI and not really having any notion of being able to "check in the scan definition."

## Research: Steps to Make Test Authentication Happen

In developing the strategy for integration test authentication, we needed to define the basic steps and order required for an integration test where we provision a test tenant and do data population.

### One-Time Setup

We only have to do these once as a prerequisite to _any_ integration testing.

1. **Create an Apigee developer account we can use for automation.** This service account will be responsible for interacting with the Apigee API for creating and deleting integration test applications. This may also be the same developer used during deployment pipelines for pushing API proxy updates.
2. **Create a "bootstrap" application in Apigee** that has the ability to provision a new tenant. This simulates the Fiserv admin who might provision a new tenant for onboarding. This application should be owned by the automation account.

### Steps for Each Pipeline Run

> :bulb: **We have [a PowerShell module for provisioning test tenants and applications](https://dev.azure.com/F-DC/Digital%20Nexus/_git/fiserv-services-operations)** that can automate a lot of this. Check out the `New-FiservTestRun` and `Remove-FiservTestRun` commands in there.

1. Get a `password` grant Apigee API token for the automation developer. We'll call this the "automation dev token."
2. Use the automation dev token to query the Apigee API for the client ID and client secret for the bootstrap application. Doing this means we can rotate those values as needed and we don't need to keep them in a separate secret store location.
3. Get a `client_credentials` grant Fiserv token for the bootstrap application. We'll call this the "tenant provisioning token."
4. Use the tenant provisioning token to call the Fiserv API to provision a new test tenant.
5. Use the automation dev token and the Apigee API to query for the list of Fiserv API products. These are required so you can grant permissions to an integration test application.
6. Use the automation dev token and the Apigee API to create a temporary integration test application associated with the test tenant. Assign it to the set of API products found in the previous query. The output of this will yield information about the integration test application including the client ID and client secret.
7. Provide the client ID and client secret for the temporary integration test app to test suites so they can do data population and integration testing as needed. It's the responsibility of the test suites to use the information to get DSL tokens.
8. Wait for the test suites to complete.
9. Use the automation dev token to remove the temporary integration test application from Apigee.
10. Use the tenant provisioning token to remove the test tenant, which should also purge any remaining test data, etc. from the system.

While the focus here is on `client_credentials` testing, it does not preclude end user testing. The integration test application can be used as a "demo client" that can simulate an online banking platform. The test scripts would be responsible for provisioning test users, getting individual user tokens for those test users, etc. On test tenant teardown, all those test users should also be cleaned up.

### Changes to Make to Apigee

The initial work in Apigee was primarily manual. There are some things we need to do inside Apigee to make automation work better with it.

- **Create a naming convention for Apigee objects**: Our initial set of apps, products, and proxies use `Sentence Case With Spaces` like `DSL - Banking` for the identifying names (not _display names_ but actually the identifier _name_ values). These values need to be used in URI segments so Apigee recommends using `snake_case` or `kebab-case` with URL-safe values to avoid encoding problems. Recommend `kebab-case` as many other products already use this.
- **Create a display name convention for Apigee objects**: A display name convention makes searching via the UI simpler. A readable prefix like `DSL -` is good (e.g., consistent prefix like `DSL - Display Name Here`).
- **Create a key naming convention for attribute key/value pairs**: We use key/value attributes for things like access token lifetime and tenant ID. The built-in attribute pairs `DisplayName` and `Notes` are used in Apigee for those corresponding fields in the UI. Recommend either using `PascalCase` like this to remain consistent with Apigee defaults or `kebab-case` to be consistent with object naming convention.
- **Determine a common attribute key/value pair for DSL objects**: The Apigee API doesn't allow searching by substring against display name or identifier. The UI does this by loading all the applications (or proxies, or products) and manually doing the substring filter on the client. However, the API _does_ allow query by attribute. If we create a standardized attribute pair, like `ProductGroup=dsl`, we can more easily target automation queries for things in the Apigee API.
- **Deploy all Apigee objects from an automation account**: The Apigee API allows you to query for all things owned by a particular email/user. Ensuring everything is "owned" by the automation account will make querying and manipulation easier.

Once we've determined these things, we should redeploy anything in Apigee that doesn't meet the criteria so it's all consistent. **This would be easier if there were automation around all aspects of Apigee management**, which, at the time of this writing, there is not.

> :bulb: The items here resulted in the creation of the [Apigee guidelines](../Coding-Guidelines/Apigee-Guidelines.md) and the test application guidelines noted earlier.

> :warning: This document is for discussion purposes at this point and is subject to change.

There are several concerns relating to development practices, infrastructure security and fault domains that encourage the use of multiple delivery environments:

- Corporate policies dictate that "lower" and "upper" environment classifications are not allowed to communicate with each other. Logical separation within Kubernetes is technically feasible, but it comes with complications as we would need to run duplicate services for each environment class and this would dramatically complicate routing within the service mesh. These policies are the defacto standard within Fiserv and most applications and operation teams attempt to adhere to these polices, this creates a lot of friction when integrating with other applications.

- There is a need for a development environment where a broader range of developers can interact with data, peripheral services and infrastructure itself. When operating in an "upper" region we must treat all data and access to that system as production-level, which can hamper development and troubleshooting. In addition, sometimes it's useful to have a lower environment to use as a testbed for systemic changes, such as upgrading Istio or Kubernetes.

- When availability is the paramount driver there are benefits in operating multiple clusters as independent fault domains. Further, this allows us to (more easily) sequence deployments across regions to reduce risk associated with an update. Using a multi-cluster service mesh does increases risk of a bad change impacting multiple clusters.

For these reasons it is desired that we operate more than one environment for DSL services and _our CD process must accommodate this in an automated fashion_. Drift between services and infrastructure for these environments should not be accommodated- outside of the sequenced deployment cycle.

[[_TOC_]]

## Environments

Two primary environment types will be used for DSL services and deployments should be sequenced across these environments for process controls and stability purposes. The following table outlines each environment and the sequence changes will be made to these environments.

| Environment Name      | Region     | Sequence | Entry Gate                                            |
| --------------------- | ---------- | -------- | ----------------------------------------------------- |
| dc-centralus-test-dsl | Central-Us | 1        | Pull Request Approval (1)                             |
| dc-eastus-test-dsl    | East-Us    | 2        | Successful Canary in prior                            |
| dc-centralus-prod-dsl | Central-Us | 3        | Successful Canary in prior; ServicePoint approval (2) |
| dc-eastus-prod-dsl    | East-Us    | 4        | Successful Canary in prior; 24 hour delay (3)         |

It should be noted that we may end up with additional environments withing production, such as a west coast or non-US locations.

Notes:

(1) - Besides the traditional review approval process, entry is also gated based on passing all code hygiene and relevant security scans.
(2) - ServicePoint approval is a mandatory corporate process for all changes into a production environment.
(3) - A delay between active/active environments is desired to provide "baking time" to better identify regressions/defects prior to impacting additional clusters.

## Process

The following steps outlines the logical flow used to deliver DSL services to production. This is an abbreviated example, the official process for the different types of deliverables is outlined in detail in the [Continuous Integration and Deployment](https://dev.azure.com/F-DC/Digital%20Nexus/_wiki/wikis/architecture/431/Continuous-Integration-and-Deployment) documentation.

1. Developers request a change through a [pull request](https://docs.microsoft.com/en-us/azure/devops/repos/git/pull-requests?view=azure-devops) approval process.
2. Changes reviewed and scanned for security and quality.
3. Current environment context is set to "1".
4. Changes are deployed to the environment, integration tests are executed and the temporary service is destroyed.
5. Changes are deployed as a canary into the environment.
6. When the canary deployment completes the environment target is changed to the next environment in the sequence.

## Stage Gates

Prior to changing a production environment an approval must be granted through ServicePoint. Note that this is not the same as adding an audit record in ServicePoint, this is an approval step. For those familiar with development processes it is evident that this will not be a viable process with executive-level approvals but the working assumption is that a non-executive approver (or automation) can be employed to approve changes.

### Initial Production Entry Gate

Here is how we will satisfy the change approval requirement for entry into the production environment:

1. When a change completes the roll-out through non-production environments that changes is considered eligible for production deployment.
2. The CD Pipeline should pause at this point to initiate a change request [using the built-in ServiceNow change management](https://docs.microsoft.com/en-us/azure/devops/pipelines/release/approvals/servicenow?view=azure-devops) process.
3. Upon approval, the CD process continues.
4. If rejected the CD process terminates.

> :warning: When the CD process terminates because of a rejection we will have an inconsistency between our environments. Resolution will be to fix-forward by restarting the process.

For approvals, it should be noted that our intent is to automate the vast majority of approval requests within ServicePoint.

Approvals for standard changes should be fully automated if the initial pull request includes all required parties and required security scans are enforced through common pipelines. As an example, if the change is peer-reviewed, security-reviewed, validated through a test deployment w/ automated integration tests, scanned by Fortify and rolled-out through a canary process, there should be no need to manually approve are set.

See [Approval Types and Enforcement](https://dev.azure.com/F-DC/Digital%20Nexus/_wiki/wikis/architecture/641/Multi-Environment-Delivery-Process?anchor=approval-types-and-enforcement&_a=edit) for more details on how approvals will be handled.

### Subsequent Environment Deployment Gate

To provide a cushion for detection of errors after the initial production environment deployment, we will add "wait time" between each successive environment deployment. This wait time should be factored into the canary deployment itself with a default of 24 hours.

## Approval Types and Enforcement

In general, approval types used for gating production changes falls into one of the following categories:

- **Automated**. These approvals are intended to be automated within ServicePoint. This approval type requires that code repositories have pull-request approvers which include all necessary stakeholders, CI/CD processes cover all mandated security scans, integration tests are run alongside code deployment and the change is released through a canary deployment process.
- **Manual**. Used for approvals which cannot meet the above requirements.

In all cases, the approvals will be submitted through ServicePoint through integrations in our CI/CD pipelines. For enforcement, an approval type should be set on each pipeline used for a given code repository. The approval type will be included as part of that automated request to ServicePoint to allow the system to determine whether (or not) the manual approval step is required.

## Business Commitment

In general it is better to release more frequently and with smaller change sets. This will increase efficiency, reduce time to market and reduce the likelihood of making mistakes "because our head isn't in the game" anymore. As such we desire that the majority of approvals are automated.

For manual approvals we should should strive to complete these in no more than twenty-four hours.

Our request is that changes are approved no later than twenty-four hours after requested.

## Implementation

TBD, describe components used and updates required for Terraform (more environments), DevOps build agents (one per env, I believe), AzDo pipeline template changes, etc.

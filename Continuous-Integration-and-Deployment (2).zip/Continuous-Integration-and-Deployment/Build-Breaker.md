# Resources

- [Fiserv Fortify Downloads](https://fortify.1dc.com/downloads.html)
- [Build-Breaker API Overview](https://fiservcorp.sharepoint.com/sites/AppSec/SitePages/Build-Breaker-API-Overview.aspx)
- [Build-Breaker API Integration](https://fiservcorp.sharepoint.com/sites/AppSec/SitePages/Build-Breaker-API-Integration.aspx)
- [Build-Breaker 2.0 API Firewall Request Details](https://fiservcorp.sharepoint.com/sites/AppSec/SitePages/Build-Breaker-API-Firewall-Request-Details.aspx?xsdata=MDV8MDF8fDc1ODExMWRlNzAzMTQ2NWM1Y2IyMDhkYWRlZGJhMjQ5fDExODczYTFmNGM4ZDQ1MGQ4ZGZiZTM3YTJlMjU1N2Y4fDB8MHw2MzgwNjczMzIxMjgyNjc0NDJ8VW5rbm93bnxWR1ZoYlhOVFpXTjFjbWwwZVZObGNuWnBZMlY4ZXlKV0lqb2lNQzR3TGpBd01EQWlMQ0pRSWpvaVYybHVNeklpTENKQlRpSTZJazkwYUdWeUlpd2lWMVFpT2pFeGZRPT18MXxNVFkzTVRFek5qUXhNakl5TURzeE5qY3hNVE0yTkRFeU1qSXdPekU1T2pBd09UbGlNMlUyWTJZM1pUUXdPRFU0TkdSbU5XRTVNalF4TkdFNE5UazFRSFJvY21WaFpDNTBZV04yTWc9PXw4M2Y5ZDI2YTQ4ZDk0NjBkNWNiMjA4ZGFkZWRiYTI0OXw0ZmE0OWEyYWVlNzU0NjVmYTcyNjZhODI5ZmEwY2E5Zg%3D%3D&sdata=NVB1bG9DRGFlRXlmYlBtSFJTNDNRdkZsYmo1b0cyMFdqLzNBZS9Ua2t1dz0%3D)

# Implementation

The Build Breaker implementation introduces a new [`job` template](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/deploy/job-buildbreaker.yml) that takes care of the following tasks:

- Download and uncompress the executable for the Build Breaker.
- Execute the call to the Build Breaker endpoint.

The Build Breaker template should be added as the first stage of the deployment pipeline. Here is an example of the standard yaml configuration that can be used:

```yaml
  - stage: check_security_findings_threshold
    displayName: "Check security findings threshold"
    jobs:
      - template: "deploy/job-buildbreaker.yml@templates"
```

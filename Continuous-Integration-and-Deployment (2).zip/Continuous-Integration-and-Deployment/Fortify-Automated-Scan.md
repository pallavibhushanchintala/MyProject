[[_TOC_]]

# Resources

- [Fiserv Fortify Downloads](https://fortify.1dc.com/downloads.html)
- [Fortify Portal Ping SSO](https://fdc-fedsso-int.firstdata.com/idp/wL9o9/resumeSAML20/idp/SSO.ping)
- [Micro Focus Fortify Static Code Analyzer Installation Guide](https://www.microfocus.com/documentation/fortify-static-code-analyzer-and-tools/1810/SCA_Install_18.10.pdf)
- [Micro Focus Fortify Static Code Analyzer Output Options Documentation](https://www.microfocus.com/documentation/fortify-static-code-analyzer-and-tools/2210/SCA_Help_22.1.0/index.htm#cli/OutputOpts.htm?TocPath=Command-Line%2520Interface%257C_____3)

# Implementation

The Fortify SCA automated scan implementation introduces a new [`job` template](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/job-fortify.yml) that takes care of the following tasks:

- Download and install the Fortify SCA application.
- Scan the code of the repository that is being built.
- Upload the scan result to the Fortify Portal.

The new Fortify scan template is added to the three following templates under the [`azure-pipeline-templates` project](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates):

- [`build-dotnetcoreapplication.yml`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/build-dotnetcoreapplication.yml)
- [`build-dotnetcorelibrary.yml`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/build-dotnetcorelibrary.yml)
- [`build-apispecification.yml`](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/build-apispecification.yml)

The template makes use of a set of variables defined in the Azure Library, each domain will require its own `variables group` to be created with the following entries:

- `fortify_email`: email address to pass along with the scan result.
- `fortify_token`: token utilized for authenticating against the Fortify Portal.
- `uaid`: Unique identifier for the domain.

[`Here`](https://dev.azure.com/F-DC/Digital%20Nexus/_library?itemType=VariableGroups&view=VariableGroupView&variableGroupId=58&path=banking-domain) is an example for the `Banking domain`.

Since the Fortify SCA application can only scan .NET applications from a Windows environment, a new self-hosted windows agent was built. We can make use of this new agent from the [`job` template](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/job-fortify.yml&version=GBmaster&line=16&lineEnd=16&lineStartColumn=7&lineEndColumn=33&lineStyle=plain&_a=contents) by using the variable `agentPool_windows` configured under the [`dsl-commercial-centralus`](https://dev.azure.com/F-DC/Digital%20Nexus/_library?itemType=VariableGroups&view=VariableGroupView&variableGroupId=43&path=dsl-commercial-centralus) variable group in the Azure Pipelines library.

The Fortify SCA scanner makes use of the domain `UAID` and the application `Version` for successfully uploading the scan results to the Fortify portal, the later corresponds to the name of the repository that is being scanned and it needs to be previously configured in the Fortify portal.

## Fortify Scan Configuration

You can configure certain aspects of the Fortify SCA scan by including a `.fortify.json` file in the root of your project. An example file looks like this:

```json
{
  "exclude_fingerprints": [
    "06DD97E9C0EFDE10E7D4268895374242",
    "0700EBB04BD269142F312AD0C4A071C8",
  ],
  "exclude_patterns": [
    "test",
    "gulpfile.js"
  ]
}
```

### Ignoring Files

Projects may have files or directories that do not require to be scanned, for example the ones used for testing or used only during pipeline execution. Add the file or folder names to the `.fortify.json` file in an `exclude_patterns` section. The patterns here are passed directly to the Fortify analyzer. [You can see some examples here.](https://www.microfocus.com/documentation/fortify-static-code-analyzer-and-tools/2210/SCA_Help_22.1.0/index.htm#cli/SpecifyFilesDirs.htm)

### Ignoring False Positives

You can ignore a false positive result in the build by ignoring the issue "fingerprint". Fingerprints are unique IDs that identify a Fortify SCA vulnerability. By specifying these in the `exclude_fingerprints` section of the file, the build will omit the error in its results. The fingerprint of a specific vulnerability can be retrieved from the `scan_result.txt` file, located in the `Fortify` folder of the pipeline artifacts.

As an example:

```text
[280A416B19ECEAA3829B5B58E6595BBC : critical : Key Management : Hardcoded Encryption Key : configuration ]
```

The fingerprint ID is: `280A416B19ECEAA3829B5B58E6595BBC`

Note that ignoring the fingerprint in the build does not automatically suppress it in the Fortify SCA portal, it simply allows the build to finish without warning about it.

To suppress a false positive:

1. File the [ServicePoint ticket to suppress the issue](https://fiservservicepoint.fiservapps.com/sc_req_item.do?sys_id=d262f8c71bc11514b4536314b24bcbe7&sysparm_record_target=sc_req_item&sysparm_catalog=e0d08b13c3330100c8b837659bba8fb4&sysparm_catalog_view=catalog_defaul). This will stop the issue from showing up in the Fortify SCA portal as a problem.
2. Add the fingerprint to the `exclude_fingerprints` section of the file. The fingerprint should match the `Instance ID` of the vulnerability in the Fortify SCA portal. You can find the ID in the portal in the "Info" tab of the reported vulnerability, under the "Metadata" section.

## Fortify Access Token

An access token must be provided when uploading scan results to the Fortify portal. Each domain should have a token saved in its own [Azure Pipeline variable library](https://dev.azure.com/F-DC/Digital%20Nexus/_library?itemType=VariableGroups) as a secret variable named `fortify_token`. This token needs to be updated at least every 60 days with a new one. Anyone with a Fortify portal account is able to replace the token.

To get a new token, go to the [Token Management page](https://fortify.1dc.com/ssc/html/ssc/admin/tokens) in the Fortify portal and create a new token of type `ScanCentralCtrlToken`. Replace the value of `fortify_token` with the newly generated token. Note that the portal will provide two values for the token - we need to use the one that is unencrypted.

## Results and Reports

After successfully completing a Fortify SCA scan, the results and a generated report will be [published](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/job-fortify.yml&version=GBmaster&line=123&lineEnd=123&lineStartColumn=21&lineEndColumn=47&lineStyle=plain&_a=contents) as an Azure pipeline artifact under the name `fortify`.

Three documents will be available:

- `scan_result.txt`: Simple text report that contains a list of all the security findings. Used by the [Summarize Fortify SCA findings](https://dev.azure.com/F-DC/Digital%20Nexus/_git/azure-pipeline-templates?path=/build/job-fortify.yml&version=GBmaster&line=128&lineEnd=128&lineStartColumn=23&lineEndColumn=53&lineStyle=plain&_a=contents) task in order to display results during the Azure pipeline execution.
- `scan_result.fpr`: A package of the Fortify SCA analysis results that includes the `FVDL` file as well as extra information such as a copy of the source code used in the scan, the external metadata, and custom rules. [Micro Focus Fortify Audit Workbench](https://www.microfocus.com/documentation/fortify-static-code-analyzer-and-tools/1810/AWB_Guide_18.10.pdf) is automatically associated with the `.fpr` file extension. Also this is the file used by the [`BIRTReportGenerator`](https://www.microfocus.com/documentation/fortify-static-code-analyzer-and-tools/2210/SCA_Help_22.1.0/index.htm#Utilities/GenBIRTReports.htm?Highlight=BIRTReportGenerator) tool in order to generate the reports.
- `scan_report.pdf`: The report generated for the scan using the "Developer Workbook" template. It contains the same information displayed in the Fortify SCA portal for the executed Fortify SCA scan.

# Fortify Alerts

Alerts can be configured in the [Alerts page](https://fortify.1dc.com/ssc/html/ssc/admin/templatesalerts) of the Fortify portal. It's up to each individual to configure their own alerts and customize them as desired. Some useful alert types are:

| Type                              | Name                                | Criteria |
| ----                              | ----                                | -------- |
| Event                             | Uploaded Artifact Requires Approval | Apply to all application versions |
| Event                             | Analysis Result Upload Failed       | Apply to all application versions |
| Threshold - Performance indicator | Critical Priority Issues            | Alert when `>=1`, apply to [all UAIDs/versions under DBP](../Domains.md) |
| Threshold - Performance indicator | High Priority Issues                | Alert when `>=1`, apply to [all UAIDs/versions under DBP](../Domains.md) |

You may want to experiment with the "Reset after triggering" option for alerts. It will alert you more often, but the alerts will keep you notified about existing issues so they won't get lost/forgotten.

# UAIDs and Domains

Each domain must have its own UAID stored as `uaid` in its own variable group in the Azure Pipelines Library. The domain variable group must also be added to the `azure-pipelines.yml` file of each project.

**Example:**

```yaml
variables:
  - group: banking-domain
```

[Here is the list](../Domains.md) of the current domains and their UAIDs.

[[_TOC_]]

## Basic Inventory

As of September 2021, this is a basic inventory of tools being used in build and deploy pipelines. This was gathered as part of an effort by the security team to create a fixed list that can be cached or provided by a different source during builds so the build agents can be locked down with no internet access. Ostensibly the risk being mitigated here is some nature of build chain poisoning where we would inadvertently get a tool or tool version that has some malicious code in it and execute that during the build cycle.

Locally installed on build agents:

- .NET
- Bash
- Curl
- Docker
- Fortify on Premise SCA
- Git
- Graphviz
- Helm
- Jq
- kubectl
- Sonatype Nexus Lifecycle
- Node.js
- NuGet
- PowerShell
- Spectral
- Terraform
- Terragrunt
- TFLint

Executed via `npm` or `npx`:

- apigeetool
- openapi2apigee

Executed from inside a Docker container (container gets pulled and the tool is inside there, not installed on the agent):

- CodeClimate
- k6
- OWASP ZAP Scanner
- Clair Scanner

## Minimum Tool Install

Under the assumption a subset of tools can be provided as pre-installed but _tool installer tasks still work_, we can [look at the set of tools found on Microsoft hosted agents](https://github.com/actions/virtual-environments/blob/main/images/linux/Ubuntu1804-README.md) and curate a subset of tools we should expect to be installed on the agent.  The actual list of installed software for Microsoft hosted agents is regularly updated, so the list here can be used as a starting point but not the final, never-changing list. These tools may not only be used by our build pipelines directly, but by things invoked by the pipelines (e.g., downloading pipeline artifacts may invoke `unzip` to expand the artifact; or `npm` may install a package that has a native compilation aspect to it.)

**This list was gathered October 28, 2021.**

- Language and Runtime
  - Bash 4.4.20(1)-release
  - GNU C++ 7.5.0, 9.4.0, 10.3.0
  - Mono 6.12.0.122 (apt source repository: `https://download.mono-project.com/repo/ubuntu stable-bionic main`)
  - MSBuild 16.6.0.15201 (from /usr/lib/mono/msbuild/15.0/bin/MSBuild.dll)
  - Node 14.18.1
- Package Management
  - Helm 3.7.1
  - Npm 6.14.15
- Project Management
  - Gradle 7.2
  - Maven 3.8.3
  - Sbt 1.5.5
- Tools
  - Docker Compose v2 2.0.0
  - Git 2.33.1 (apt source repository: ppa:git-core/ppa)
  - jq 1.5
  - Kubectl 1.22.2
  - Kustomize 4.4.0
  - nvm 0.39.0
  - OpenSSL 1.1.1 11 Sep 2018
- CLI Tools
  - Azure CLI (azure-cli) 2.29.0 ([installation method](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt))
  - Azure CLI (azure-devops) 0.20.0
- Java
  - 8.0.292+1 (default) / Adopt OpenJDK / JAVA_HOME_8_X64
  - 11.0.11+9 / Adopt OpenJDK / JAVA_HOME_11_X64
  - 12.0.2+10 / Adopt OpenJDK / JAVA_HOME_12_X64
- .NET Core SDK
  - 2.1.302 2.1.403 2.1.526 2.1.617 2.1.701 2.1.818 3.1.120 3.1.202 3.1.302 3.1.414 5.0.104 5.0.208 5.0.303 5.0.402
- Cached Tools
  - Go
    - 1.13.15
    - 1.14.15
    - 1.15.15
    - 1.16.9
    - 1.17.2
  - Node.js
    - 10.24.1
    - 12.22.7
    - 14.18.1
  - Environment Variables
    - GOROOT_1_13_X64 / /opt/hostedtoolcache/go/1.13.15/x64 / x64
    - GOROOT_1_14_X64 / /opt/hostedtoolcache/go/1.14.15/x64 / x64
    - GOROOT_1_15_X64 / /opt/hostedtoolcache/go/1.15.15/x64 / x64
    - GOROOT_1_16_X64 / /opt/hostedtoolcache/go/1.16.9/x64 / x64
    - GOROOT_1_17_X64 / /opt/hostedtoolcache/go/1.17.2/x64 / x64
- PowerShell Tools
  - PowerShell 7.1.5
  - Modules
    - Pester 5.3.1
    - Az PowerShell Modules 6.4.0 3.1.0.zip 4.4.0.zip 5.9.0.zip
- Installed apt packages
  - binutils 2.30-21ubuntu1~18.04.5
  - build-essential 12.4ubuntu1
  - coreutils 8.28-1ubuntu1
  - curl 7.58.0-2ubuntu3.16
  - dnsutils 1:9.11.3+dfsg-1ubuntu1.15
  - dpkg 1.19.0.5ubuntu2.3
  - iputils-ping 3:20161105-1ubuntu3
  - jq 1.5+dfsg-2
  - libc++-dev 6.0-2
  - libc++abi-dev 6.0-2
  - libcurl3 7.58.0-2ubuntu3.16
  - locales 2.27-3ubuntu1.4
  - net-tools 1.60+git20161116.90da8a0-1ubuntu1
  - pkg-config 0.29.1-0ubuntu2
  - sudo 1.8.21p2-3ubuntu1.4
  - unzip 6.0-21ubuntu1.1
  - wget 1.19.4-1ubuntu2.2
  - zip 3.0-11build1

## Why a Fixed Inventory Won't Work

While locking down the set of tools, versions, and sources is an interesting concept in theory and might work in a small build system from a decade or more ago, the state of building software today doesn't quite as easily lend itself to total lockdown. There are trade-offs to consider that aren't entirely related to security.

### Bad Separation of "Dependency" from "Build Tool" Concepts

When we build software, the software product itself has _dependencies_ like `npm` packages for Node.js or NuGet packages for .NET projects. Things like Nexus Repository exist to help us allow or block various dependencies and versions from becoming part of the deployed product. We are already using Nexus Repository for this purpose.

However, different frameworks have the notion of a "tool dependency" or "developer dependency" (e.g., `devDependencies` in Node.js or global tools in .NET) where a package is referenced for the purposes of building the project, generating code, running unit tests, etc. but is not actually part of the built/deployed _product_. These are controlled by individual projects, not by the build agent, and these individual projects have the need to be able to move independently with tools and tool versions.

**Nexus Repository can cover tool/developer dependencies** as long as we have the ability to get those dependencies regularly and rapidly updated.

### We Can't Control Docker Containers

Some tools, like Clair Scanner, only exist in Docker containers. We pull the container and execute the tool as containerized. It's not something you can install without taking on the ownership of a dedicated Clair server farm including the regular upkeep and maintenance of a persistent database that pulls the latest security issues to scan for.

We don't control what's in these containers. If the Clair Scanner container happens to have a malicious version of Clair Scanner in it or if the container itself has some nature of malicious binary, there's no way to know or control it.

**If it is determined that we cannot use containerized tools** then there are management decisions to make:

- Should we stop using that tool? If so, what's the replacement? This will be a commitment of development and possibly Cloud Ops + Cyber Security time to evaluate tools and come to consensus over replacements.
- Do we take full ownership of the tool? If so, that means a non-trivial investment of development time and effort.
  - We build the container, from scratch, ourselves, including any OS patches and updates. This must be done regularly to ensure the security of the OS.
  - We maintain the latest versions of the tool in that container we built.
  - We provide support for the container when it doesn't function as expected. We no longer can get support for container malfunctions from the originating project.

### We Need OS Updates

As part of building our containers, we are responsible for scanning and patching the container OS/binaries. When needed, we'll apply updates to the container to ensure no vulnerabilities exist. We use Clair Scanner to test for vulnerable OS issues.

Depending on the underlying operating system, we need access to standard `apk` (Alpine) and `apt` (Ubuntu, Debian) repositories for Linux. This is the only way to consistently get the latest OS updates into the container that are required.

There is not a specific list of libraries to which we need access. In some cases, we need to add libraries to enable support for cloud operations. For example, in Alpine we need to add the `icu-libs` package in order to get .NET to support localization.

Further, we build custom versions of existing tool containers. For example, we have a custom Fluentd container where we start with the base Fluentd container and add patches and plugins to make Fluentd work with Splunk. We don't control the OS or the patch level of the OS of the base Fluentd container. Thus, there isn't an opportunity to allow/block specific repositories based on individual operating system versions or types. While we may not allow _our products_ to go live on, say, Ubuntu, we can't necessarily control whether other tools we use - Fluentd, ElasticSearch, Kayenta, etc. - use those "blocked" operating systems.

**If it is determined that we may not get operating system updates during the build process** then there are management decisions to make:

- Do we stop scanning for operating system vulnerabilities in containers? If so, is Cyber Security OK with that? If not, what's the answer for applying appropriate OS patches in the build pipeline? This is a question for Cloud Ops and Cyber Security - development can't answer it.
- For tools we use but do not currently own (e.g., Fluentd, ElasticSearch) do we take full ownership of the tool? If so, that means a non-trivial investment of development time and effort.
  - We build the container, from scratch, ourselves, including any OS patches and updates. (This may be a Catch-22 if we can't access operating system updates from build agents.) This must be done regularly to ensure the security of the OS.
  - We maintain the latest versions of the tool in that container we built. We no longer get automated updates from the original source.
  - We provide support for the container when it doesn't function as expected. We no longer can get support for container malfunctions from the originating project.

### We Don't Control Build Tasks

Azure DevOps (and GitHub Actions) provide a series of build tasks that you can use as the fundamental building blocks for your pipelines. They may run shell scripts, they may execute common actions with tools, etc.

There are two types of build tasks that we use that need to be addressed:

- **Tool installer tasks**, which intentionally install a specific tool with a specific version.
- **Indirect tool retrieval tasks**, where you execute a logical operation but a tool may be downloaded in the background passively.

From a more precise perspective a _tool installer task_ will:

- Retrieve the list of the available releases for a tool from the official source. We do not have control over this source, but generally it is based on the GitHub API for releases. **We do not have control over this location.**
- Download the appropriate tool/version based on the build agent operating system, processor architecture, and specified version information (e.g., a specific version or 'latest'). The location of the binary is based on the list of retrieved sources. **We cannot override how this is calculated.**
- Place the tool in an accessible location for the build.
- Update the path and other environment variables to ensure that, when the tool is called from a script, the correct version of the tool will be located.

There are several tool installer tasks, from `NuGet` to `kubectl`. This is also the process that occurs when you choose to install a specific .NET SDK or Java version.

**Tool installer tasks are really important.** There are a few reasons:

- **We don't always control required tool versions.** For example, when building a custom build task for Azure DevOps, the runtime on the standard build agent uses Node 10 - so we need to build and test the tasks using Node 10. However, for our own Node apps we'd use something much newer than that.
- **Bugs and compatibility issues are found all the time.** For example, we have found that certain versions of NuGet aren't compatible with authentication to Azure Artifacts repositories (which we use for consuming our own libraries). Being able to upgrade (or downgrade) the version of NuGet being used for package restore to troubleshoot that issue (without affecting the whole build image or other builds) is important.
- **Fixes are released constantly.** For example, we use the Spectral linter to ensure our OpenAPI specifications are consistent and adhere to our standards. Spectral actually releases a new version fairly regularly and we want that version because it adds more support for better rules and consistency. Being able to say "get the latest" without actually pinning a version is valuable to ensure we're always using the latest set of rules available; but also being able to pin a specific version is valuable if we encounter something that needs to be fixed.
- **Not all projects are on the same versions of everything.** While we try to maintain consistency, there is a lot of value in having per-project flexibility to update things like the .NET SDK as new versions and patches come out. From performance improvements to bug fixes to new language features, being able to pin versions or specify the latest helps us do R&D work to determine the next steps for our projects or ways we can improve our developer experience/velocity.

An _indirect tool retrieval task_ is less clear. A good example of this is the [`KubernetesManifest` task](https://github.com/microsoft/azure-pipelines-tasks/tree/master/Tasks/KubernetesManifestV0). This task is used to execute templating or deployment of a Kubernetes manifest. As part of its dependencies, it [references an internal common library of Kubernetes utilities](https://github.com/microsoft/azure-pipelines-tasks/blob/93113ec8022adf5e60a8b108056735d5db8b0855/Tasks/KubernetesManifestV0/package.json?_pjax=%23js-repo-pjax-container%2C%20div%5Bitemtype%3D%22http%3A%2F%2Fschema.org%2FSoftwareSourceCode%22%5D%20main%2C%20%5Bdata-pjax-container%5D#L17) and if you ask it to perform a task for which it doesn't find the underlying tool it needs, [it goes behind the scenes to download the tool without asking](https://github.com/microsoft/azure-pipelines-tasks/blob/master/Tasks/KubernetesManifestV0/src/utils/installers.ts).

We do not have an inventory of the tools that may be downloaded behind the scenes or the tasks that do this sort of passive download. However, it's fairly clear that the tasks are built with the fundamental notion that internet access _from the build agent_ will allow for this sort of download.

**If it is determined that we are not allowed to use tool installer and/or indirect tool retrieval tasks** then there are management decisions to make:

- If we aren't allowed to use tool installers...
  - Is it valuable to stay pinned on certain tool versions that will become stale? A consistent result from our Microsoft coding assessments is that we remain too long on stale technology and code, making it hard for us to continue developing and iterating on our products. This will be a long term development cost incurred in the form of technical debt.
  - How do we troubleshoot issues where the tool itself may be part of the problem in the build pipeline? This is something the Cloud Ops and Cyber Security departments will have to answer; the development team will not be able to solve this.
  - How will we do R&D using new tools? This is something the Cloud Ops and Cyber Security departments will have to answer; the development team will not be able to solve this.
- If we do allow for installing tools, but only from specific internal/approved sources...
  - Who will maintain the custom build task library? We will have to fork all tool installer tasks that we use and create a completely custom stack that references our own list of approved versions of each tool. This will need to be published to the Azure DevOps Marketplace (privately) and consumed by any AzDO agents that need the tasks. We will not be able to use the built-in tasks anymore or get support when they misbehave. This is a dedicated development effort that will be assumed and will have a non-zero cost. Further, if/when we move from Azure DevOps to GitHub Actions, the tasks will need to be rewritten to target the new platform.
  - Who will inventory all the _passive_ installer tasks so we know what we can/can't use? For the things we need to continue using, we'll need to fork and maintain our own versions of those tasks, too, just like we will have to with standard tool installers. (See above.) This is a dedicated development effort that will be assumed and will have a non-zero cost.
- What is the process for getting new tools added to the appropriate sources or build agent images? What's the turnaround time for that? Is it hours or days? Given these sorts of issues used to be resolved within minutes (by updating a build template), is management willing to incur the extra delay time in development to allow for this process?

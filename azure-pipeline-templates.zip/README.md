# Azure DevOps Pipeline Templates

This repo contains task and pipeline templates used to build standardized Azure DevOps build and deploy pipelines.

The templates make use of Fiserv extensions for Azure DevOps that have custom tasks. If you take them to a different org, you'll need the extensions, too. See the `pipeline-task-*` repos in this project.

## Getting Started

In your `azure-pipelines.yml` add the following near the top:

```yaml
resources:
  repositories:
    - repository: templates
      ref: 'refs/heads/master'
      type: git
      name: "Digital Nexus/azure-pipeline-templates"
```

To use these templates from another (non `F-DC`) Azure DevOps organization, you'll need to configure a [service connection](https://docs.microsoft.com/en-us/azure/devops/pipelines/library/service-endpoints?view=azure-devops#sep-tfsts) of type `Azure Repos/Team Foundation Server` with access to the project and include that in YAML:

```yaml
resources:
  repositories:
    - repository: templates
      name: "Digital Nexus/azure-pipeline-templates"
      endpoint: digitalChannelsServiceConnection # Azure DevOps service connection
```

For the `ref` value, you can either pick a tag (e.g., `refs/tags/v39`) or pin to a branch like `refs/heads/master`. **It is recommended you pin to master** to avoid having to update as the build improves. If you find something breaks underneath you, you can pin to a tag while you work on a fix.

Once you have the repository defined, you can reference tasks like this:

```yaml
steps:
- template: build/task-authenticateazurenuget.yml
  parameters:
    nugetSourceName: "Digital Nexus"
```

The `template` value is a combination of the path to the YAML file in this repo (`build/task-authenticateazurenuget.yml`) and the name of the repository as defined above (`templates`). Parameters are passed to the template in a list as shown.

[Azure DevOps documentation contains more detail](https://docs.microsoft.com/en-us/azure/devops/pipelines/process/templates) showing how templates work and some of the more complex usage scenarios.

## Finding Templates

Templates in this repo follow a naming/folder convention:

- Folder: The `build` folder contains templates interesting in a build/CI pipeline; the `deploy` folder contains templates interesting in a deploy/CD pipeline.
- File name: YAML files are named like `templateType-OS-name.yml` where:
  - `templateType` indicates what sort of template it is - `build` for a complete end-to-end pipeline definition; `job` for an Azure DevOps `job` that has multiple steps that need to run together; and `task` for a single task that can be used anywhere in a pipeline.
  - `OS` is the operating system of the agent required for the template. Some tasks are agnostic of OS and don't include this; other tasks require a particular OS and won't run on agents with a different OS.
  - `name` explains what the task does.

As an example:

- `build/build-dotnetcoreapplication.yml` is a complete CI build pipeline definition for a standard .NET Core application.
- `build/task-authenticateazurenuget.yml` is a task to authenticate to a NuGet/Azure Artifacts feed using the build service principal.

## Using Templates

Each template has documentation at the top that explains how to use the template. This includes information about the parameters as well as example usage.

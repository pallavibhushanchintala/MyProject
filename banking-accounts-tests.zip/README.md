# Accounts Service: Integration and Load Tests

Integration tests, load tests, and data population to support the banking accounts service.

## Development Setup

You will need:

- [Node.js](https://nodejs.org) - any fairly recent version is fine.
- [Postman](https://www.postman.com/downloads/)

## Build

```powershell
npm install
npm run build
```

**It does not create the Docker containers.** If you want to build the Docker containers locally, you can do that after a build:

```powershell
# Authenticate with the container registry if you haven't already - this
# is a separate step than just logging into your Azure account. Note this
# is in the commercial tenant so you need to MFA and sign in there.
az acr login -n acrdsl1centralus

# Build the containers.
docker build -t "accounts-service-integration" artifacts/package/integration-test
docker build -t "accounts-service-load" artifacts/package/load-test

```

VS Code has tasks set up for building these containers if you want to test them out.

## Integration Tests - Postman

The `integration-test` folder contains the test collection and environment files:

- `*.postman_collection.json`: The actual integration tests. These use the environment files to update assertions.
- `*.postman_environment.json`: The environment files with different assertions and data for executing the tests.

Environments:

- `Development`: Assertion data matches the data in the internal stubs for the account service.
- `Production`: Assertion data matches the import file uploaded during testing.

There is a `client_credentials` folder inside the collection to indicate the tests run as an "application" rather than as a specific user. The execution context/token is slightly different for the two scenarios so testing both ways will be interesting when that's supported.

To work with the Postman tests you need to:

1. Open Postman.
2. If you have already worked with the tests, delete the environments and test collection from your Postman app.
3. Import the environments and test collection from the `src/postman` folder.
4. Update and/or run the tests as needed.
5. Export any changes to the environments and test collection back to the `src/postman` folder.

If you don't want to install Postman and you just want to run the tests, you can build the integration test container (see the build instructions above) and run them from there. The container uses the [`newman` CLI](https://learning.postman.com/docs/running-collections/using-newman-cli/command-line-integration-with-newman/) to run the tests and the collection/environment are already in the container.

```powershell
# Run the tests in a Development environment.
docker run --rm accounts-service-integration `
  run banking-v1-accounts.postman_collection.json `
  -e banking-v1-accounts.Development.postman_environment.json
```

## Load Tests - k6

The load tests are written in Javascript for the k6 runner. The build will compile/validate the tests using ESLint.

If you want to run the load tests, you will need to have a set of application credentials you can use for authentication, and those need to be in the environment as `CLIENT_ID` and `CLIENT_SECRET`.

**Do not check credentials in to this repo.**

Instead, what you can do (and how the VS Code tasks are set up):

- Use the [Fiserv.Dsl.Operations PowerShell module](https://dev.azure.com/F-DC/Digital%20Nexus/_git/fiserv-dsl-operations) command `New-DslTestRun` to create a test tenant and client application. **Do not use a bootstrap application or the bootstrap tenant.**
- Create a file `client_credentials.env` in your home directory.
- Inside the file, set the `CLIENT_ID` and `CLIENT_SECRET` variables with your client app info.
- When running the Docker command to launch the k6 tests, include `--env-file` and point it to your `client_credentials.env`.

A `client_credentials.env` file is a simple dot-env file like:

```text
CLIENT_ID=YourClientIdHere
CLIENT_SECRET=YourClientSecretHere
API_ENDPOINT=http://host.docker.internal:<Service-Port>
```

Running the k6 tests looks like:

```powershell
docker run `
  --env-file "${env:HOME}/client-credentials.env" `
  --rm `
  accounts-service-load
```

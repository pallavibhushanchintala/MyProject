import http from 'k6/http';
import encoding from 'k6/encoding';
import { check, fail, JSONArray, JSONObject, sleep } from 'k6';
import { Options } from 'k6/options';

/**
 * Options for configuring a k6 load test.
 * https://k6.io/docs/using-k6/k6-options/reference
 */
export const options = {
  vus: 10,
  duration: '1m',
  thresholds: {
    // Set thresholds, if applicable
    // https://k6.io/docs/using-k6/thresholds
    checks: ['rate>0.99'] // all checks should succeed
  }
} as Options;

const minPauseDurationSeconds = 1;
const maxPauseDurationSeconds = 10;

/**
 * Configuration that drives the test.
 */
interface TestConfiguration {
  /**
   * API endpoint for the service.
   */
  apiEndpoint: string;

  /**
   * Dictionary of name/value pairs to include as headers for service requests.
   */
  headers: Record<string, string>;

  /**
   * ID of the account created for exercising operations.
   */
  accountId: string;

  /**
   * ID of the user created for exercising operations. This user can access the
   * created account.
   */
  userId: string;
}

/**
 * A k6-defined function that sets up expected entities for a load testing run.
 *
 * @returns {Object} A collection of properties to be used when executing a load
 * test.
 */
export function setup(): TestConfiguration {
  const accessToken = getAccessToken();
  const headers = {
    Authorization: 'Bearer ' + accessToken,
    Accept: 'application/json;charset=utf-8',
    'Content-Type': 'application/json'
  };
  let apiEndpoint = 'https://prod.api.fiservapps.com/dsl/';
  if (`${__ENV.API_ENDPOINT}` !== 'undefined') {
    apiEndpoint = `${__ENV.API_ENDPOINT}`;
  }

  const accountId = createAccount(apiEndpoint, headers);
  const userId = createUser(apiEndpoint, accountId, headers);
  // Sleep 30 seconds to ensure user is propagated to account record
  sleep(30);

  return {
    apiEndpoint: apiEndpoint,
    accountId: accountId,
    userId: userId,
    headers: headers
  };
}

/**
 * The default function to be executed by each virtual user in the load test.
 *
 * @param {TestConfiguration} config - Test configuration.
 */
export default function (config: TestConfiguration): void {
  getAccounts(config);
  pause();
  getAccountById(config);
  pause();
  getBalancesByAccountId(config);
  pause();
  getProductsByAccountId(config);
  pause();
  getTransactionsByAccountId(config);
}

/**
 * Creates an account for use during the load test.
 *
 * @param {string} apiEndpoint - The base endpoint to the API under test. ex:
 * https://my-api-endpoint
 * @param {Record<string, string>} headers - The headers to be used for the API
 * call.
 * @returns {string} - The identifier of the account that was created.
 */
function createAccount(
  apiEndpoint: string,
  headers: Record<string, string>
): string {
  const payload = {
    alternateIdentifiers: [
      {
        id: '111222333',
        scheme: 'RTN'
      }
    ],
    accountType: 'checking',
    asset: true,
    currency: 'USD',
    number: '1234567890',
    status: 'active'
  };
  const res = http.put(
    apiEndpoint + '/supplier/banking/v1/accounts',
    JSON.stringify(payload),
    { headers: headers }
  );
  if (!check(res, { 'created account': (r) => r.status === 200 })) {
    fail('Failed to create account.');
  }

  const json = <JSONObject>res.json();
  if (json === null) {
    fail('Failed to create account.');
  }

  return <string>json.id;
}

/**
 * Creates a user for use during the load test.
 *
 * @param {string} apiEndpoint - The base endpoint to the Users API. ex: https://my-api-endpoint
 * @param {string} accountId - The account identifier to use when creating the user.
 * @param {Record<string, string>} headers - The headers to be used for the API call.
 * @returns {string} - The identifier of the user that was created.
 */
function createUser(
  apiEndpoint: string,
  accountId: string,
  headers: Record<string, string>
): string {
  const payload = {
    accounts: [accountId],
    alternateIdentifiers: []
  };
  const res = http.put(
    apiEndpoint + '/supplier/banking/v1/users',
    JSON.stringify(payload),
    { headers: headers }
  );
  if (!check(res, { 'created user': (r) => r.status === 200 })) {
    fail('Failed to create user.');
  }

  const json = <JSONObject>res.json();
  if (json === null) {
    fail('Failed to create user.');
  }

  return <string>json.id;
}

/**
 * Obtains a JWT access token for API calls. The client ID, client secret and,
 * optionally, the OAuth endpoint are retrieved from environment variables.
 *
 * @returns {string} The JWT access token for use in making API calls during the
 * load test.
 */
function getAccessToken() {
  if (
    `${__ENV.CLIENT_ID}` === 'undefined' ||
    `${__ENV.CLIENT_SECRET}` === 'undefined'
  ) {
    throw 'Client ID and/or Client Secret not set.';
  }

  let tokenEndpoint = 'https://prod.api.fiservapps.com/dsl/oauth2/token';
  if (`${__ENV.TOKEN_ENDPOINT}` !== 'undefined') {
    tokenEndpoint = `${__ENV.TOKEN_ENDPOINT}`;
  }

  const creds = encoding.b64encode(`${__ENV.CLIENT_ID}:${__ENV.CLIENT_SECRET}`);
  const res = http.post(tokenEndpoint, 'grant_type=client_credentials', {
    headers: {
      Authorization: 'Basic ' + creds,
      Accept: 'application/json;charset=utf-8',
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  });
  if (!check(res, { 'got access token response': (r) => r.status === 200 })) {
    fail('Failed to get access token.');
  }

  const json = <JSONObject>res.json();
  if (json === null) {
    fail('Failed to get access token.');
  }

  return json.access_token;
}

/**
 * Exercises the GET /consumer/banking/v1/accounts/{id} route to verify
 * functionality.
 *
 * @param {TestConfiguration} config - The configuration properties returned by
 * the {@link setup} function.
 */
function getAccountById(config: TestConfiguration): void {
  const res = http.get(
    config.apiEndpoint +
      '/consumer/banking/v1/accounts/' +
      config.accountId +
      '?userId=' +
      config.userId,
    { headers: config.headers }
  );
  check(res, {
    'retrieved accounts': (r) => r.status === 200,
    'account ID matches': (r) => {
      const json = <JSONObject>r.json();
      if (json === null) {
        fail('Failed to retrieve account.');
      }

      return json.id === config.accountId;
    }
  });
}

/**
 * Exercises the GET /consumer/banking/v1/accounts route to verify
 * functionality.
 *
 * @param {TestConfiguration} config - The configuration properties returned by
 * the {@link setup} function.
 */
function getAccounts(config: TestConfiguration): void {
  const res = http.get(
    config.apiEndpoint +
      '/consumer/banking/v1/accounts?userId=' +
      config.userId,
    { headers: config.headers }
  );
  check(res, {
    'retrieved accounts': (r) => r.status === 200,
    'has account': (r) => {
      const json = <JSONArray>r.json();
      if (json === null) {
        fail('Failed to get accounts.');
      }

      return json.length === 1;
    },
    'account ID matches': (r) => {
      const json = <JSONArray>r.json();
      if (json === null || json.length < 1) {
        fail('Failed to get accounts');
      }

      const account = <JSONObject>json[0];
      return account.id === config.accountId;
    }
  });
}

/**
 * Exercises the /consumer/banking/v1/accounts{id}/balances route to verify
 * functionality.
 *
 * @param {TestConfiguration} config - The configuration properties returned by
 * the {@link setup} function.
 */
function getBalancesByAccountId(config: TestConfiguration): void {
  const res = http.get(
    config.apiEndpoint +
      '/consumer/banking/v1/accounts/' +
      config.accountId +
      '/balances?userId=' +
      config.userId,
    { headers: config.headers }
  );
  check(res, {
    'retrieved balances': (r) => r.status === 200
  });
}

/**
 * Exercises the /consumer/banking/v1/accounts{id}/products route to verify
 * functionality.
 *
 * @param {TestConfiguration} config - The configuration properties returned by
 * the {@link setup} function.
 */
function getProductsByAccountId(config: TestConfiguration): void {
  const res = http.get(
    config.apiEndpoint +
      '/consumer/banking/v1/accounts/' +
      config.accountId +
      '/products?userId=' +
      config.userId,
    { headers: config.headers }
  );
  check(res, {
    'retrieved products': (r) => r.status === 200
  });
}

/**
 * Exercises the /consumer/banking/v1/accounts{id}/transactions route to verify
 * functionality.
 *
 * @param {Object} config - The configuration properties returned by the
 * {@link setup} function.
 */
function getTransactionsByAccountId(config: TestConfiguration): void {
  const res = http.get(
    config.apiEndpoint +
      '/consumer/banking/v1/accounts/' +
      config.accountId +
      '/transactions?userId=' +
      config.userId,
    { headers: config.headers }
  );
  check(res, {
    'retrieved transactions': (r) => r.status === 200
  });
}

/**
 * Sleeps for a randomized amount between the minimum and maximum pause
 * durations.
 */
function pause(): void {
  const waitTime = Math.floor(
    Math.random() * (maxPauseDurationSeconds - minPauseDurationSeconds + 1) +
      minPauseDurationSeconds
  );
  sleep(waitTime);
}

# Fluentd Plugins Container

This project builds a Docker container based on the `fluentd-elasticsearch` image and adds the `fluent-plugin-splunk-hec` plugin. `fluent-plugin-splunk-hec` is the Fluentd output plugin for sending events to Splunk via HEC. `fluentd-elasticsearch` is a pre-configured container that sends logs to ElasticSearch. The resulting image is used as a foundational piece that gets laid down so applications can use to pipe the logs to both ElasticSearch and Splunk.

- [fluent-plugin-splunk-hec](https://github.com/splunk/fluent-plugin-splunk-hec)
- [fluentd-elasticsearch Helm chart](https://github.com/kokuwaio/helm-charts/tree/main/charts/fluentd-elasticsearch)
- [fluentd_elasticsearch/fluentd Docker repo](https://github.com/monotek/fluentd-elasticsearch/blob/master/Dockerfile)
- [nexus-infrastructure-charts](https://dev.azure.com/F-DC/Digital%20Nexus/_git/nexus-infrastructure-charts)

## Usage

The container works just like `quay.io/fluentd_elasticsearch/fluentd` but has Splunk support built in. It is intended to be deployed using the standard [`kiwigrid/fluentd-elasticsearch` Helm chart](https://kiwigrid.github.io) with this image replacing the stock image.

This example filters out logs based on `applog` value in the message and sends filtered events to Splunk HEC using the HEC token. The `values.yaml` overrides the `outputConf` section to send events to both ElasticSearch and Splunk.

A simple `values.yaml` to override the image might look like this:

```yaml
image:
  repository: acrdsl1centralus.azurecr.io/digital-nexus/fluentd
  tag: 1.0.0

configMaps:
  useDefaults:
    # Indicate we want a custom output.conf
    outputConf: false

# Replace the output.conf with our dual ElasticSearch/Splunk configuration.
extraConfigMaps:
  output.conf: |-
    # handle timeout log lines from concat plugin
    # <match **>
    #   @type relabel
    #   @label @NORMAL
    # </match>

    <match **>
      @type copy
      <store>
        @type relabel
        @label @SPLUNK
      </store>
      <store>
        @type relabel
        @label @NORMAL
      </store>
    </match>

    <label @SPLUNK>
      <filter **>
        @type grep
        <regexp>
          key log
          pattern /"audit":"true"/
        </regexp>
      </filter>
      <match **>
          @type splunk_hec
          hec_host 10.10.10.10
          hec_port 5000
          hec_token 77777777-7777-7777-7777-777777777777
          index Kubernetes
          protocol https
          sourcetype _json
          insecure_ssl true
      </match>
    </label>

    <label @NORMAL>
      <match **>
        @id elasticsearch
        @type "#{ENV['OUTPUT_TYPE']}"
        @log_level "#{ENV['OUTPUT_LOG_LEVEL']}"
        include_tag_key "#{ENV['OUTPUT_INCLUDE_TAG_KEY']}"
        hosts "#{ENV['OUTPUT_HOSTS']}"
        path "#{ENV['OUTPUT_PATH']}"
        scheme "#{ENV['OUTPUT_SCHEME']}"
        ssl_verify "#{ENV['OUTPUT_SSL_VERIFY']}"
        ssl_version "#{ENV['OUTPUT_SSL_VERSION']}"
        type_name "#{ENV['OUTPUT_TYPE_NAME']}"
        logstash_format "#{ENV['LOGSTASH_FORMAT']}"
        logstash_dateformat "#{ENV['LOGSTASH_DATEFORMAT']}"
        logstash_prefix "#{ENV['LOGSTASH_PREFIX']}"
        logstash_prefix_separator "#{ENV['LOGSTASH_PREFIX_SEPARATOR']}"
        log_es_400_reason "#{ENV['OUTPUT_LOG_400_REASON']}"
        reconnect_on_error "#{ENV['OUTPUT_RECONNECT_ON_ERROR']}"
        reload_on_failure "#{ENV['OUTPUT_RELOAD_ON_FAILURE']}"
        reload_connections "#{ENV['OUTPUT_RELOAD_CONNECTIONS']}"
        request_timeout "#{ENV['OUTPUT_REQUEST_TIMEOUT']}"
        <buffer>
          @type "#{ENV['OUTPUT_BUFFER_TYPE']}"
          path "#{ENV['OUTPUT_BUFFER_PATH']}"
          flush_mode "#{ENV['OUTPUT_BUFFER_FLUSH_MODE']}"
          retry_type "#{ENV['OUTPUT_BUFFER_RETRY_TYPE']}"
          flush_thread_count "#{ENV['OUTPUT_BUFFER_FLUSH_THREAD_TYPE']}"
          flush_interval "#{ENV['OUTPUT_BUFFER_FLUSH_INTERVAL']}"
          retry_forever "#{ENV['OUTPUT_BUFFER_RETRY_FOREVER']}"
          retry_max_interval "#{ENV['OUTPUT_BUFFER_RETRY_MAX_INTERVAL']}"
          chunk_limit_size "#{ENV['OUTPUT_BUFFER_CHUNK_LIMIT']}"
          queue_limit_length "#{ENV['OUTPUT_BUFFER_QUEUE_LIMIT']}"
          overflow_action "#{ENV['OUTPUT_BUFFER_OVERFLOW_ACTION']}"
        </buffer>
      </match>
    </label>
```

## Updating Fluentd Version

There are, unfortunately, a few places that need to be updated to update the Fluentd version used in the container.

- `azure-pipelines.yml`: The version needs to be provided for the CI build.
- `docker-compose.yml`: During the build, the version arg needs to be provided.
- `Invoke-DevBuild.ps1`: The default version parameter value needs to be updated.

## Local Testing

Running `Invoke-DevBuild.ps1` will build the container and do a cursory check to see that all the expected plugins are present.

You can actually see the container in action using Docker Compose. The example in our repo is similar to [the example here.](https://github.com/digikin/fluentd-elastic-kibana/blob/master/README.md)

```powershell
# Build/rebuild the container.
docker compose build

# Bring up a small web server, ElasticSearch, Kibana, and Fluentd.
docker compose up

# You can do it in the background, too, so you don't see the containers
# streaming logs.
docker compose up -d

# If you started in the background, you can look at the Fluentd container
# logs. This is where you'll find issues in startup.
docker logs docker-fluentd-fluentd-1

# Send a request to the web server to generate logs. You should see the log
# flow through Fluentd.
Invoke-WebRequest http://localhost:8888

# Go to http://localhost:5601/app/management/kibana/indexPatterns
# and set up an index pattern for "fluentd-*" using "@timestamp as the
# time field. Go to the Analytics => Discover tab and you should see logs
# in Kibana.

# When you're done, shut it down.
docker compose down
```

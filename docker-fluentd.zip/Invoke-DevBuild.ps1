﻿<#
.SYNOPSIS
    Runs a local dev build to test container image changes. Optionally runs
    tests on an existing image.
.DESCRIPTION
    Builds and tests a local version of the image. Represents a smaller version
    of what happens in the matrix pipeline. Using the available parameters you
    may also test an existing image without building.
.PARAMETER ContainerName
    The name of the container to build and test.
.PARAMETER FluentdVersion
    The version of Fluentd on which the container should be based. May only be
    specified if building the container.
.PARAMETER SkipBuild
    If provided, indicates only the tests should run. It is assumed the
    image has been built and exists.
.EXAMPLE
    ./Invoke-DevBuild.ps1

    Builds and tests a default version of the container.
.EXAMPLE
    ./Invoke-DevBuild -FluentdVersion v4.3.1

    Builds and tests a local version of the container with a specific
    Fluentd version.
.EXAMPLE
    ./Invoke-DevBuild -ContainerName "acrdsl1centralus.azurecr.io/digital-nexus/fluentd:1.0.0" -SkipBuild

    Tests the specific version of the container as found on the local
    machine. Does not do a pull first.
#>
[CmdletBinding(DefaultParameterSetName = "build")]
Param(
    [Parameter(ParameterSetName = "build")]
    [Parameter(ParameterSetName = "test")]
    [ValidateNotNullOrEmpty()]
    [string]
    $ContainerName = "fluentd-local",

    [Parameter(ParameterSetName = "build")]
    [ValidateNotNullOrEmpty()]
    [string]
    $FluentdVersion = "v3.4.0",

    [Parameter(ParameterSetName = "test")]
    [switch]
    $SkipBuild
)

if (-not $SkipBuild.IsPresent) {
    write-host "Building image $ContainerName"
    &docker build -t $ContainerName --build-arg GIT_COMMIT=local --build-arg GIT_REPO=local --build-arg FLUENTD_VERSION=$FluentdVersion .
    write-host "Finished Building image $ContainerName"
}

$existingImageId = &docker images $ContainerName
if ($null -eq $existingImageId) {
    Throw "Docker image '$ContainerName' does not exist. Either build the image or pull it first."
}

$containerId = &docker run --rm -e HEC_HOST=$HECHost -e HEC_PORT=$HECPort -e HEC_INDEX=$HECIndex -e HEC_TOKEN=$HECToken -d $ContainerName

Write-Host "Waiting for container to start..." -NoNewLine
do {
    $state = docker container inspect --format '{{.State.Status}}' $containerId
    Write-Host "." -NoNewLine
    Start-Sleep -s 1
} until ($state -eq "running")
Write-Host "Started."

$logContent = &docker container logs $containerId

# Make sure proper versions of plugins are loaded
$versions = $logcontent -match "gem" | ForEach-Object { $_ -split "gem".Trim() }

$index = 0;
$loadedPluginVersions = $versions | ForEach-Object { if ( $index % 2 -ne 0 ) { $arr = $versions[$index].Trim() -split " version"; $arr[0] -replace "'".Trim()}; $index++ }

# Versions to check
$pluginVersions = @("fluent-plugin-concat",
    "fluent-plugin-detect-exceptions"
    "fluent-plugin-elasticsearch"
    "fluent-plugin-kubernetes_metadata_filter"
    "fluent-plugin-multi-format-parser"
    "fluent-plugin-prometheus"
    "fluent-plugin-splunk-hec"
    "fluent-plugin-systemd"
    "fluentd")

&docker stop $containerId

Write-Host "Container has the following plugins:"
$loadedPluginVersions | ForEach-Object {
    Write-Host "- $_"
}

$pluginVersions | ForEach-Object {
    $expected = $_
    If (-not ($loadedPluginVersions -contains $expected)) {
        Throw "Docker image '$ContainerName' is missing the plugin '$expected'."
    }
}

Write-Host "All expected plugins found."

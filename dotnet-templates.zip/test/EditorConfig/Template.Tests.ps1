Describe "EditorConfig.Template" {
    BeforeAll {
        # Register template
        $templateShortName = "fiserv-editorconfig"
        $templateName = "EditorConfig.Template"
        $templateSource = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates/$templateName")
        dotnet new -i $templateSource | Out-Null
    }
    AfterAll {
        # Unregister template
        dotnet new -u $templateSource | Out-Null
    }
    Context "Default Item" {
        BeforeAll {
            $templatePath = (Get-PSDrive TestDrive).Root
            dotnet new $templateShortName -o $templatePath
            $itemPath = Join-Path $templatePath -ChildPath ".editorconfig"
        }
        It "is named .editorconfig" {
            Test-Path $itemPath | Should -Be $true
        }
    }
}

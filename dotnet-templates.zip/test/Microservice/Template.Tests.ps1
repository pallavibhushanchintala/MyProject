Describe "Microservice.Template" {
    BeforeAll {
        # Register template and dependencies
        $templateShortName = "fiserv-microservice"
        $templateName = "Microservice.Template"
        $templateBase = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates")
        $requiredTemplates = @(
            (Join-Path -Path $templateBase -ChildPath $templateName),
            (Join-Path -Path $templateBase -ChildPath "SourceRuleset.Template"),
            (Join-Path -Path $templateBase -ChildPath "StyleCopJson.Template")
        )
        $requiredTemplates | ForEach-Object { dotnet new -i $_ | Out-Null }

        . $PSScriptRoot/Assertions.ps1
    }
    AfterAll {
        # Unregister templates
        $requiredTemplates | ForEach-Object { dotnet new -u $_ | Out-Null }
    }

    Context "Default settings" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $src = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "src") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $templatePath = Join-Path -Path $src -ChildPath "MicroserviceTemplateTest"
            &dotnet new "fiserv-sourceruleset" -o $build
            &dotnet new "fiserv-stylecopjson" -o $build
            &dotnet new "nugetconfig" -o $solutionBase
            If ($IsWindows -or $IsMacOS) {
                # On Windows, nuget.exe command line should be in the path.
                # On Mac, install nuget with `brew install nuget` and it'll handle the mono call.
                # Either way, calling 'nuget' like this should "just work."
                &nuget sources add -name "nexus" -configfile $solutionBase/nuget.config -source https://pkgs.dev.azure.com/F-DC/_packaging/nexus/nuget/v3/index.json
            }
            Else {
                # On Linux, install the nuget.exe binary and execute it manually with mono.
                $pathToNuGet = Get-Command nuget.exe | Select-Object -ExpandProperty Source
                &mono $pathToNuGet sources add -name "nexus" -configfile $solutionBase/nuget.config -source https://pkgs.dev.azure.com/F-DC/_packaging/nexus/nuget/v3/index.json
            }

            &dotnet new $templateShortName -o $templatePath
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "has code analysis enabled" {
            Assert_CodeAnalysisEnabled $templatePath
        }
        It "has a management port" {
            Assert_ManagementPortEnabled $templatePath
        }
        It "has HTTPS enabled" {
            Assert_HttpsEnabled $templatePath
        }
        It "has a Dockerfile" {
            Assert_DockerfileExists $templatePath
        }
    }

    Context "HTTPS turned off" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $src = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "src") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $templatePath = Join-Path -Path $src -ChildPath "MicroserviceTemplateTest"
            &dotnet new "fiserv-sourceruleset" -o $build
            &dotnet new "fiserv-stylecopjson" -o $build
            &dotnet new $templateShortName -o $templatePath --no-https
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "has code analysis enabled" {
            Assert_CodeAnalysisEnabled $templatePath
        }
        It "has a management port" {
            Assert_ManagementPortEnabled $templatePath
        }
        It "has HTTPS disabled" {
            Assert_HttpsDisabled $templatePath
        }
        It "has a Dockerfile" {
            Assert_DockerfileExists $templatePath
        }
    }

    Context "Everything turned off" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $src = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "src") -ItemType Directory
            $templatePath = Join-Path -Path $src -ChildPath "MicroserviceTemplateTest"
            &dotnet new $templateShortName -o $templatePath --no-codeanalysis --no-https
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "has code analysis disabled" {
            Assert_CodeAnalysisDisabled $templatePath
        }
        It "has HTTPS disabled" {
            Assert_HttpsDisabled $templatePath
        }
        It "has a Dockerfile" {
            Assert_DockerfileExists $templatePath
        }
    }

    Context "Specify stylecop.json location" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $src = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "src") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $buildOther = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "buildOther") -ItemType Directory
            $templatePath = Join-Path -Path $src -ChildPath "MicroserviceTemplateTest"
            &dotnet new "fiserv-sourceruleset" -o $build
            &dotnet new "fiserv-stylecopjson" -o $buildOther
            &dotnet new $templateShortName -o $templatePath --stylecop-json "../../buildOther/stylecop.json"
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "has code analysis enabled and configured with custom stylecop.json" {
            Assert_CodeAnalysisEnabled $templatePath -StyleCopPath "../../buildOther/stylecop.json"
        }
    }

    Context "Specify Source.ruleset location" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $src = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "src") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $buildOther = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "buildOther") -ItemType Directory
            $templatePath = Join-Path -Path $src -ChildPath "MicroserviceTemplateTest"
            &dotnet new "fiserv-sourceruleset" -o $buildOther
            &dotnet new "fiserv-stylecopjson" -o $build
            &dotnet new $templateShortName -o $templatePath --analysis-ruleset "../../buildOther/Source.ruleset"
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "has code analysis enabled and configured with custom Source.ruleset" {
            Assert_CodeAnalysisEnabled $templatePath -RuleSetPath "../../buildOther/Source.ruleset"
        }
    }
}

#
# COMMON FEATURE ASSERTIONS
# This helps in reusing assertions about specific features being enabled
# or disabled across permutations of the template parameters.
#
function Assert_CodeAnalysisDisabled {
    param($TemplatePath)
    $projectFileName = "$((Get-Item $TemplatePath).Name).csproj"
    [xml]$projectFile = Get-Content (Join-Path -Path $TemplatePath -ChildPath $projectFileName)
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/CodeAnalysisRuleSet") | Should -Be $null
    (Select-Xml -Xml $projectFile -XPath "/Project/ItemGroup/AdditionalFiles") | Should -Be $null
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/AnalysisMode").ToString() | Should -Be "None"
}

function Assert_CodeAnalysisEnabled {
    param($TemplatePath, $RuleSetPath = "../../build/Source.ruleset", $StyleCopPath = "../../build/stylecop.json")
    $projectFileName = "$((Get-Item $TemplatePath).Name).csproj"
    [xml]$projectFile = Get-Content (Join-Path -Path $TemplatePath -ChildPath $projectFileName)
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/CodeAnalysisRuleSet").ToString() | Should -Be $RuleSetPath
    (Select-Xml -Xml $projectFile -XPath "/Project/ItemGroup/AdditionalFiles[@Include='$StyleCopPath']") | Should -Not -Be $null
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/AnalysisMode").ToString() | Should -Be "AllEnabledByDefault"
}

function Assert_Compiles {
    param($TemplatePath, $Configuration)
    $output = (dotnet build $TemplatePath -c $Configuration /p:TreatWarningsAsErrors=true /warnaserror) | Out-String
    if ($LASTEXITCODE -ne 0) {
        Write-Host $output
    }
    $LASTEXITCODE | Should -Be 0
}

function Assert_DockerfileExists {
    param($TemplatePath)
    Test-Path (Join-Path -Path $TemplatePath -ChildPath "Dockerfile") | Should -Be $true
}

function Assert_HttpsDisabled {
    param($TemplatePath)
    $namespace = (Get-Item $TemplatePath).Name
    $launchSettings = Get-Content (Join-Path -Path $TemplatePath -ChildPath "Properties/launchSettings.json") -Raw | ConvertFrom-Json
    $launchSettings.profiles.Development.applicationUrl.Contains("https://localhost") | Should -Be $false
    $launchSettings.profiles.Development.environmentVariables.ASPNETCORE_URLS.Contains("https://localhost") | Should -Be $false
}

function Assert_HttpsEnabled {
    param($TemplatePath)
    $launchSettings = Get-Content (Join-Path -Path $TemplatePath -ChildPath "Properties/launchSettings.json") -Raw | ConvertFrom-Json
    $launchSettings.profiles.Development.applicationUrl.Contains("https://localhost") | Should -Be $true
    $launchSettings.profiles.Development.environmentVariables.ASPNETCORE_URLS.Contains("https://localhost") | Should -Be $true
}

function Assert_ManagementPortEnabled {
    param($TemplatePath)
    # launchSettings.json
    $launchSettings = Get-Content (Join-Path -Path $TemplatePath -ChildPath "Properties/launchSettings.json") -Raw | ConvertFrom-Json
    $port = $launchSettings.profiles.Development.environmentVariables.ASPNETCORE_MANAGEMENTPORT
    $port | Should -Not -BeNullOrEmpty
    $listeners = $launchSettings.profiles.Development.applicationUrl.Split(';')
    $listeners.Contains("http://localhost:$port") | Should -Be $true
    $listeners = $launchSettings.profiles.Development.environmentVariables.ASPNETCORE_URLS.Split(';')
    $listeners.Contains("http://localhost:$port") | Should -Be $true

    # Startup.cs
    $startup = Join-Path -Path $TemplatePath -ChildPath "Startup.cs"
    $startup | Should -FileContentMatch "var managementPort = configuration\.GetManagementPort\(\);"
    $startup | Should -FileContentMatch "management\.UseHealthChecks\(`"/healthz`", healthOptions\);"
    $startup | Should -FileContentMatch "management\.UseOpenTelemetryPrometheusScrapingEndpoint\(\);"
}

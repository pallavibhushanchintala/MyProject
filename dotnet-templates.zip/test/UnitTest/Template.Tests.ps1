Describe "UnitTest.Template" {
    BeforeAll {
        # Register template and dependencies
        $templateShortName = "fiserv-unittest"
        $templateName = "UnitTest.Template"
        $templateBase = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates")
        $requiredTemplates = @(
            (Join-Path -Path $templateBase -ChildPath $templateName),
            (Join-Path -Path $templateBase -ChildPath "TestRuleset.Template"),
            (Join-Path -Path $templateBase -ChildPath "StyleCopJson.Template")
        )
        $requiredTemplates | ForEach-Object { dotnet new -i $_ | Out-Null }

        . $PSScriptRoot/Assertions.ps1
    }
    AfterAll {
        # Unregister templates
        $requiredTemplates | ForEach-Object { dotnet new -u $_ | Out-Null }
    }
    Context "Default settings" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $test = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "test") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $templatePath = Join-Path -Path $test -ChildPath "UnitTestTemplateTest"
            &dotnet new "fiserv-testruleset" -o $build
            &dotnet new "fiserv-stylecopjson" -o $build
            &dotnet new $templateShortName -o $templatePath
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "runs and passes tests in Debug mode" {
            Assert_TestsRun $templatePath "Debug"
        }
        It "runs and passes tests in Release mode" {
            Assert_TestsRun $templatePath "Release"
        }
        It "has code analysis enabled" {
            Assert_CodeAnalysisEnabled $templatePath
        }
    }


    Context "Everything turned off" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $test = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "test") -ItemType Directory
            $templatePath = Join-Path -Path $test -ChildPath "UnitTestTemplateTest"
            &dotnet new $templateShortName -o $templatePath --no-codeanalysis
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "runs and passes tests in Debug mode" {
            Assert_TestsRun $templatePath "Debug"
        }
        It "runs and passes tests in Release mode" {
            Assert_TestsRun $templatePath "Release"
        }
        It "has code analysis disabled" {
            Assert_CodeAnalysisDisabled $templatePath
        }
    }

    Context "Specify stylecop.json location" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $test = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "test") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $buildOther = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "buildOther") -ItemType Directory
            $templatePath = Join-Path -Path $test -ChildPath "UnitTestTemplateTest"
            &dotnet new "fiserv-testruleset" -o $build
            &dotnet new "fiserv-stylecopjson" -o $buildOther
            &dotnet new $templateShortName -o $templatePath --stylecop-json "../../buildOther/stylecop.json"
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "runs and passes tests in Debug mode" {
            Assert_TestsRun $templatePath "Debug"
        }
        It "runs and passes tests in Release mode" {
            Assert_TestsRun $templatePath "Release"
        }
        It "has code analysis enabled and configured with custom stylecop.json" {
            Assert_CodeAnalysisEnabled $templatePath -StyleCopPath "../../buildOther/stylecop.json"
        }
    }

    Context "Specify Test.ruleset location" {
        BeforeAll {
            $solutionBase = (Get-PSDrive TestDrive).Root
            $test = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "test") -ItemType Directory
            $build = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "build") -ItemType Directory
            $buildOther = New-Item -Path (Join-Path -Path $solutionBase -ChildPath "buildOther") -ItemType Directory
            $templatePath = Join-Path -Path $test -ChildPath "UnitTestTemplateTest"
            &dotnet new "fiserv-testruleset" -o $buildOther
            &dotnet new "fiserv-stylecopjson" -o $build
            &dotnet new $templateShortName -o $templatePath --analysis-ruleset "../../buildOther/Test.ruleset"
        }
        It "compiles in Debug mode" {
            Assert_Compiles $templatePath "Debug"
        }
        It "compiles in Release mode" {
            Assert_Compiles $templatePath "Release"
        }
        It "runs and passes tests in Debug mode" {
            Assert_TestsRun $templatePath "Debug"
        }
        It "runs and passes tests in Release mode" {
            Assert_TestsRun $templatePath "Release"
        }
        It "has code analysis enabled and configured with custom Test.ruleset" {
            Assert_CodeAnalysisEnabled $templatePath -RuleSetPath "../../buildOther/Test.ruleset"
        }
    }
}

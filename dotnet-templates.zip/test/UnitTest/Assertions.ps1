#
# COMMON FEATURE ASSERTIONS
# This helps in reusing assertions about specific features being enabled
# or disabled across permutations of the template parameters.
#
function Assert_CodeAnalysisDisabled {
    param($TemplatePath)
    $projectFileName = "$((Get-Item $TemplatePath).Name).csproj"
    [xml]$projectFile = Get-Content (Join-Path -Path $TemplatePath -ChildPath $projectFileName)
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/CodeAnalysisRuleSet") | Should -Be $null
    (Select-Xml -Xml $projectFile -XPath "/Project/ItemGroup/AdditionalFiles") | Should -Be $null
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/AnalysisMode").ToString() | Should -Be "None"
}

function Assert_CodeAnalysisEnabled {
    param($TemplatePath, $RuleSetPath = "../../build/Test.ruleset", $StyleCopPath = "../../build/stylecop.json")
    $projectFileName = "$((Get-Item $TemplatePath).Name).csproj"
    [xml]$projectFile = Get-Content (Join-Path -Path $TemplatePath -ChildPath $projectFileName)
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/CodeAnalysisRuleSet").ToString() | Should -Be $RuleSetPath
    (Select-Xml -Xml $projectFile -XPath "/Project/ItemGroup/AdditionalFiles[@Include='$StyleCopPath']") | Should -Not -Be $null
    (Select-Xml -Xml $projectFile -XPath "/Project/PropertyGroup/AnalysisMode").ToString() | Should -Be "AllEnabledByDefault"
}

function Assert_Compiles {
    param($TemplatePath, $Configuration)
    $output = (dotnet build $TemplatePath -c $Configuration /p:TreatWarningsAsErrors=true /warnaserror) | Out-String
    if ($LASTEXITCODE -ne 0) {
        Write-Host $output
    }
    $LASTEXITCODE | Should -Be 0
}

function Assert_TestsRun {
    param($TemplatePath, $Configuration)
    dotnet test $TemplatePath -c $Configuration
    if ($LASTEXITCODE -ne 0) {
        Write-Host $output
    }
    $LASTEXITCODE | Should -Be 0
}

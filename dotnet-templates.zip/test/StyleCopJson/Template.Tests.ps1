Describe "StyleCopJson.Template" {
    BeforeAll {
        # Register template
        $templateShortName = "fiserv-stylecopjson"
        $templateName = "StyleCopJson.Template"
        $templateSource = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates/$templateName")
        dotnet new -i $templateSource | Out-Null
    }
    AfterAll {
        # Unregister template
        dotnet new -u $templateSource | Out-Null
    }
    Context "Default Item" {
        BeforeAll {
            $templatePath = (Get-PSDrive TestDrive).Root
            dotnet new $templateShortName -o $templatePath
            $itemPath = Join-Path $templatePath -ChildPath "stylecop.json"
        }
        It "is named stylecop.json" {
            Test-Path $itemPath | Should -Be $true
        }
        It "has the company name set to Fiserv" {
            $content = Get-Content $itemPath -Raw | ConvertFrom-Json
            $content.settings.documentationRules.companyName | Should -Be "Fiserv"
        }
        It "has using directives placed outside namespaces" {
            $content = Get-Content $itemPath -Raw | ConvertFrom-Json
            $content.settings.orderingRules.usingDirectivesPlacement | Should -Be "outsideNamespace"
        }
    }
}

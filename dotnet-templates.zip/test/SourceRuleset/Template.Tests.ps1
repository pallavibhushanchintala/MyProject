Describe "SourceRuleset.Template" {
    BeforeAll {
        # Register template
        $templateShortName = "fiserv-sourceruleset"
        $templateName = "SourceRuleset.Template"
        $templateSource = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates/$templateName")
        dotnet new -i $templateSource | Out-Null
    }
    AfterAll {
        # Unregister template
        dotnet new -u $templateSource | Out-Null
    }
    Context "Default Item" {
        BeforeAll {
            $templatePath = (Get-PSDrive TestDrive).Root
            dotnet new $templateShortName -o $templatePath
            $itemPath = Join-Path $templatePath -ChildPath "Source.ruleset"
        }
        It "is named Source.ruleset" {
            Test-Path $itemPath | Should -Be $true
        }
        It "defaults to Warning" {
            [xml]$content = Get-Content $itemPath
            (Select-Xml -Xml $content -XPath "/RuleSet/IncludeAll/@Action").ToString() | Should -Be "Warning"
        }
        It "sets Microsoft.CodeAnalysis.Analyzers rule '<Rule>' to '<Status>'" -TestCases @(
            @{ Rule = 'CA1014'; Status = 'None' }
            @{ Rule = 'CA1032'; Status = 'None' }
            @{ Rule = 'CA1054'; Status = 'None' }
            @{ Rule = 'CA1055'; Status = 'None' }
            @{ Rule = 'CA1056'; Status = 'None' }
            @{ Rule = 'CA1303'; Status = 'None' }
            @{ Rule = 'CA2007'; Status = 'None' }
            @{ Rule = 'CA2234'; Status = 'None' }
            @{ Rule = 'CA2237'; Status = 'None' }
        ) {
            param ($Rule, $Status)
            [xml]$content = Get-Content $itemPath
            (Select-Xml -Xml $content -XPath "/RuleSet/Rules[@AnalyzerId='Microsoft.CodeAnalysis.Analyzers']/Rule[@Id='$Rule']/@Action").ToString() | Should -Be "$Status"
        }
        It "sets StyleCop.Analyzers rule '<Rule>' to '<Status>'" -TestCases @(
            @{ Rule = 'SA1119'; Status = 'None' }
            @{ Rule = 'SA1121'; Status = 'None' }
            @{ Rule = 'SA1122'; Status = 'None' }
            @{ Rule = 'SA1306'; Status = 'None' }
            @{ Rule = 'SA1309'; Status = 'None' }
            @{ Rule = 'SA1633'; Status = 'None' }
        ) {
            param ($Rule, $Status)
            [xml]$content = Get-Content $itemPath
            (Select-Xml -Xml $content -XPath "/RuleSet/Rules[@AnalyzerId='StyleCop.Analyzers']/Rule[@Id='$Rule']/@Action").ToString() | Should -Be "$Status"
        }
        It "sets SecurityCodeScan rule '<Rule>' to '<Status>'" -TestCases @(
            @{ Rule = 'SCS0016'; Status = 'None' }
        ) {
            param ($Rule, $Status)
            [xml]$content = Get-Content $itemPath
            (Select-Xml -Xml $content -XPath "/RuleSet/Rules[@AnalyzerId='SecurityCodeScan']/Rule[@Id='$Rule']/@Action").ToString() | Should -Be "$Status"
        }
    }
}

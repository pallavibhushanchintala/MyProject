# Several describe blocks are used to "reset" the TestDrive across large
# operations. This ensures file modifications from one set of tests don't affect
# a different logical set of tests.

Describe "TerraformModule.Template - Files" {
    BeforeAll {
        # Register template
        $templateShortName = "fiserv-terraform"
        $templateName = "TerraformModule.Template"
        $templateSource = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates/$templateName")
        dotnet new -i $templateSource | Out-Null
    }
    AfterAll {
        # Unregister template
        dotnet new -u $templateSource | Out-Null
    }
    Context "Default settings" {
        BeforeAll {
            $templatePath = (Get-PSDrive TestDrive).Root

            # You have to name it or you'll get the GUID as a name. Module names
            # can't start with numbers so you'll end up failing validation,
            # seemingly at random.
            dotnet new $templateShortName -o $templatePath -n "terraform-random-string"
        }
        It "has the root module files" {
            Join-Path $templatePath -ChildPath "main.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "outputs.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "variables.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "README.md" | Should -Exist
        }
        It "has the root metadata and build files" {
            Join-Path $templatePath -ChildPath ".editorconfig" | Should -Exist
            Join-Path $templatePath -ChildPath ".gitignore" | Should -Exist
            Join-Path $templatePath -ChildPath ".tflint.hcl" | Should -Exist
            Join-Path $templatePath -ChildPath "azure-pipelines.yml" | Should -Exist
            Join-Path $templatePath -ChildPath "build.ps1" | Should -Exist

            # File renames should work.
            Join-Path $templatePath -ChildPath "editorconfig" | Should -Not -Exist
            Join-Path $templatePath -ChildPath "gitignore" | Should -Not -Exist
        }
        It "has the VS Code integration files" {
            Join-Path $templatePath -ChildPath ".vscode/extensions.json" | Should -Exist
            Join-Path $templatePath -ChildPath ".vscode/launch.json" | Should -Exist
        }
        It "has the basic example" {
            Join-Path $templatePath -ChildPath "examples/basic/main.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "examples/basic/outputs.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "examples/basic/variables.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "examples/basic/README.md" | Should -Exist
        }
        It "has the plan fixture" {
            Join-Path $templatePath -ChildPath "test/fixtures/plan/main.tf" | Should -Exist
            Join-Path $templatePath -ChildPath "test/fixtures/plan/README.md" | Should -Exist
        }
        It "has the default set of Terratest tests" {
            Join-Path $templatePath -ChildPath "test/basic_test.go" | Should -Exist
            Join-Path $templatePath -ChildPath "test/terratest_stages.go" | Should -Exist
            Join-Path $templatePath -ChildPath "test/go.mod" | Should -Exist
            Join-Path $templatePath -ChildPath "test/go.sum" | Should -Exist
        }
        It "does not include Go artifacts" {
            Join-Path $templatePath -ChildPath "test/Gopkg.lock" | Should -Not -Exist
            Join-Path $templatePath -ChildPath "test/vendor" | Should -Not -Exist
        }
    }
}

Describe "TerraformModule.Template - Local Build" {
    BeforeAll {
        # Register template
        $templateShortName = "fiserv-terraform"
        $templateName = "TerraformModule.Template"
        $templateSource = Resolve-Path (Join-Path $PSScriptRoot -ChildPath "../../templates/$templateName")
        dotnet new -i $templateSource | Out-Null
    }
    AfterAll {
        # Unregister template
        dotnet new -u $templateSource | Out-Null
    }

    Context "Default settings" {
        BeforeAll {
            $templatePath = (Get-PSDrive TestDrive).Root

            # You have to name it or you'll get the GUID as a name. Module names
            # can't start with numbers so you'll end up failing validation,
            # seemingly at random.
            dotnet new $templateShortName -o $templatePath -n "terraform-random-string" --force
        }
        It "can pass local build validation" {
            If ($Null -eq (Get-Command terraform -ErrorAction Ignore)) {
                Set-ItResult -Skipped -Because 'The Terraform command is not found.'
                return
            }
            If ($Null -eq (Get-Command tflint -ErrorAction Ignore)) {
                Set-ItResult -Skipped -Because 'The tflint command is not found.'
                return
            }

            $build = Join-Path $templatePath -ChildPath "build.ps1"
            &$build
        }
    }
}

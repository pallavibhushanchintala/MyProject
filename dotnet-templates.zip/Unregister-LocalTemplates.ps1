Get-ChildItem -Path $PSScriptRoot\templates -Directory | ForEach-Object { dotnet new -u $_.FullName | Out-Null }

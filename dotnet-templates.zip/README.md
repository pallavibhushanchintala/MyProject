# dotnet CLI Templates

Templates for items and projects in .NET Core projects, accessible via `dotnet new`.

## Install the Templates

If you are a developer who wants to use the templates, they can be installed directly from the Azure Artifacts feed.

```powershell
dotnet new --nuget-source https://pkgs.dev.azure.com/F-DC/_packaging/nexus/nuget/v3/index.json -i Fiserv.DotNet.Templates
```

Make sure you have the [Azure Artifacts credential provider](https://github.com/microsoft/artifacts-credprovider) so you can authenticate to the feed!

If you've never installed anything from the feed before, you can initialize the credential provider directly.

Windows:

```bat
dotnet %USERPROFILE%\.nuget\plugins\netcore\CredentialProvider.Microsoft\CredentialProvider.Microsoft.dll -U https://pkgs.dev.azure.com/F-DC/_packaging/nexus/nuget/v3/index.json
```

Linux:

```bash
dotnet ~/.nuget/plugins/netcore/CredentialProvider.Microsoft/CredentialProvider.Microsoft.dll -U https://pkgs.dev.azure.com/F-DC/_packaging/nexus/nuget/v3/index.json
```

## Packaging

Use the `TemplatePackage.csproj` for packaging. This also controls what goes in the package (e.g., ignoring `*.user` files).

```powershell
dotnet pack TemplatePackage.csproj -c Release
```

For CI or pre-release packages, you can specify a `--version-suffix`:

The version of the package is controlled by the `VersionPrefix` element in the `TemplatePackage.csproj`.

## Developing

[Templates are "runnable projects"](https://github.com/dotnet/templating/wiki/%22Runnable-Project%22-Templates) so you can develop them in Visual Studio, build them, run them, and make sure everything is working as you expect. When the template is packaged, build output and user-specific files (e.g., `*.user`) get excluded.

Use the `TemplateDevelopment.sln` to develop templates. It's only used for dev and trying out the various runnable projects. The packaging project doesn't execute any sort of build since templates are treated as content.

### Development Tips

It's recommended you use a two-part simple template name/namespace like `Microservice.Template` rather than one part (`Microservice`) or anything more complex. This ensures [a unique `sourceName`](https://github.com/dotnet/templating/wiki/Naming-and-default-value-forms) that makes for more accurate template transformations.

Phrase flags in a way such that the default value is `false`. This allows the flag to be the default value of `true` when it's specified and makes the CLI a bit easier to work with.

```powershell
# If HTTPS is the default, having no flags will leave it default:
dotnet new mytemplate

# This would disable it with the user opting out...
dotnet new mytemplate --no-https

# ...and that's the same as...
dotnet new mytemplate --no-https true

# Using a flag where you need the value to be false makes
# it so you MUST specify the value. Not as pretty.
dotnet new mytemplate --enable-https false
```

If you have a `choice` parameter that only has one choice then the `dotnet` CLI help will omit the parameter. The user can't override it anyway.

### SpecialCustomOperations

You'll notice a section `specialCustomOperations` in the `template.json` for the `Microservice.Template`. This adds some processing to all JSON files in that template such that any triple-slash (`///`) will get removed after all the if/else stuff is processed. Doing this allows you to keep a "running template" in there with valid JSON but still allow if/else processing to include different sections.

```json
"iisExpress": {
  "applicationUrl": "http://localhost:8080",
  //#if(!NoHttps)
  "sslPort": 44300
  //#else
  ///"sslPort": 0
  //#endif
}
```

It must be triple-slash or something that isn't something that can be broken up into even slashes (`//` or `////` won't work) due to the way template tokenization happens. This custom action configuration is documented [in the templating wiki on GitHub](https://github.com/dotnet/templating/wiki/%22Runnable-Project%22-Templates).

### Testing Templates

Tests for the templates are written using [Pester](https://github.com/pester/Pester). It's recommended that if content, especially parameterized content, is added to a template that tests get added to ensure the template behaves as expected. You can run the tests using `Invoke-Pester`.

```powershell
Invoke-Pester ./test
```

### Development Resources

You can learn more about creating custom templates here:

- [Custom templates for dotnet new](https://docs.microsoft.com/en-us/dotnet/core/tools/custom-templates)
- [Dotnet templating wiki](https://github.com/dotnet/templating/wiki)
- [Tutorial on creating templates](https://docs.microsoft.com/en-us/dotnet/core/tutorials/cli-templates-create-item-template)
- [ASP.NET Core product template source](https://github.com/aspnet/AspNetCore/tree/v3.0.0-preview8.19405.7/src/ProjectTemplates)

## Testing

You can install a locally checked-out version of the templates for testing. There are scripts included here for automating that.

1. Delete any per-user files or build output files that wouldn't normally be included in packaging. An easy way to do this if you have everything checked in is to use `git clean -dfx` to remove all files not under source control.
2. Install: `.\Register-LocalTemplates.ps1`
3. Change to a different folder and try your template.
4. Uninstall: `.\Unregister-LocalTemplates.ps1`

Example:

```powershell
.\Register-LocalTemplates.ps1
pushd C:\dev
mkdir test
cd test
# List the Fiserv templates
dotnet new fiserv -l
# Show the parameters / help
dotnet new fiserv-microservice -h
# Deploy the template
dotnet new fiserv-microservice -n Cool.Test.Service
dir
popd
.\Unregister-LocalTemplates.ps1
```

Get-ChildItem -Path $PSScriptRoot\templates -Directory | ForEach-Object { dotnet new -i $_.FullName | Out-Null }
dotnet new fiserv -l

﻿using System.Text.Json;
using System.Text.Json.Serialization;
using Autofac;
using Fiserv.AspNetCore.Authentication;
using Fiserv.AspNetCore.Diagnostics.HealthChecks;
using Fiserv.AspNetCore.Http.Routing;
using Fiserv.AspNetCore.Mvc.ApiExplorer;
using Fiserv.AspNetCore.Mvc.Infrastructure;
using Hellang.Middleware.ProblemDetails;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Newtonsoft.Json.Serialization;
using OpenTelemetry;
using OpenTelemetry.Metrics;
using OpenTelemetry.Trace;
using Serilog;

namespace Microservice.Template;

/// <summary>
/// Startup logic for the microservice pipeline.
/// </summary>
[ExcludeFromCodeCoverage]
public class Startup
{
    /// <summary>
    /// Initializes a new instance of the <see cref="Startup"/> class.
    /// </summary>
    /// <param name="configuration">
    /// The <see cref="IConfiguration"/> built by the host.
    /// </param>
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));

        // Set up Serilog with enhanced logging.
        // Note: If you're NOT deploying in Istio, set the environment variable
        // ASPNETCORE_FORWARDEDHEADERS_ENABLED=true
        // to enable ASP.NET Core to handle `X-Forwarded-For` headers, which
        // affects IP address auditing/logging.
        var (uaid, application) = configuration.GetApplicationProperties();
        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .EnrichWithEnhancedLoggingData(uaid, application)
            .CreateLogger();
    }

    /// <summary>
    /// Gets or sets the application configuration.
    /// </summary>
    /// <value>
    /// An <see cref="IConfiguration"/> containing application configuration.
    /// </value>
    public static IConfiguration Configuration { get; set; } = null!;

    /// <summary>
    /// Called by the ASP.NET Core startup loader after all services are registered
    /// with dependency injection. Configures the application pipeline.
    /// </summary>
    /// <param name="app">
    /// The <see cref="IApplicationBuilder"/> used to create the application pipeline.
    /// </param>
    /// <param name="configuration">
    /// The <see cref="IConfiguration"/> with application configuration settings.
    /// </param>
    /// <param name="provider">
    /// The <see cref="IApiDescriptionProvider"/> that discovers registered API versions.
    /// </param>
    public static void Configure(IApplicationBuilder app, IConfiguration configuration, IApiVersionDescriptionProvider provider)
    {
        ArgumentNullException.ThrowIfNull(app);
        ArgumentNullException.ThrowIfNull(configuration);
        ArgumentNullException.ThrowIfNull(provider);

        var managementPort = configuration.GetManagementPort();
        var healthOptions = new HealthCheckOptions
        {
            AllowCachingResponses = true,
            ResponseWriter = HealthCheckResponseWriter.WriteReport,
        };

        app.UseContainerIpAddress()
            .UsePort(
                managementPort,
                management =>
                {
                    // Branch the pipeline and put all the management port things on it.
                    management.UseHealthChecks("/healthz", healthOptions);
                    management.UseOpenTelemetryPrometheusScrapingEndpoint();
                })
            .UseHeaderPropagation()
            .Use(async (context, next) =>
                {
                    // OWASP zaproxy scanner 10021
                    context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
                    await next();
                })
            .UseProblemDetails()
            .UseFiservSwagger(provider)
            .UseRouting()
            .UseAuthentication()
            .UseAuthorization()
            .UseEndpoints(endpoints =>
                {
                    endpoints.MapControllers();
                });
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after <see cref="ConfigureServices(IServiceCollection)"/>
    /// to register services directly with Autofac. Items registered here may override
    /// things registered in <see cref="ConfigureServices(IServiceCollection)"/>.
    /// </summary>
    /// <param name="builder">
    /// The <see cref="ContainerBuilder"/> used to register services with Autofac.
    /// </param>
    public static void ConfigureContainer(ContainerBuilder builder)
    {
        ArgumentNullException.ThrowIfNull(builder);

        // TODO: Register services with Autofac.
        var (uaid, application) = Configuration.GetApplicationProperties();
        builder.RegisterFiservAuditLogger(Configuration, uaid, application);
        builder.RegisterFiservAggregateLogger();
    }

    /// <summary>
    /// Called by the ASP.NET Core runtime after startup begins to register services
    /// with the generic .NET Core dependency management system. Items registered here
    /// will end up in the Autofac container and may be overridden by
    /// <see cref="ConfigureContainer(ContainerBuilder)"/>.
    /// </summary>
    /// <param name="services">
    /// The <see cref="IServiceCollection"/> used to register services with .NET Core
    /// dependency management.
    /// </param>
    public static void ConfigureServices(IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);

        // Note: Use Istio to enforce token validation!
        services.AddIstioAuthentication();
        services
            .AddTransient<IApiDescriptionProvider, ApiDescriptionProvider>()
            .AddSingleton<Microsoft.AspNetCore.Mvc.Infrastructure.ProblemDetailsFactory, CustomProblemDetailsFactory>()
            .AddSingleton<IHttpContextAccessor, HttpContextAccessor>()
            .AddFiservHeaderPropagation()
            .AddProblemDetails()
            .AddFiservSwagger("Microservice.Template")
            .AddApiVersioning(options =>
                {
                    // Reporting api versions will return the headers
                    // "api-supported-versions" and "api-deprecated-versions."
                    options.ReportApiVersions = true;
                })
            .AddVersionedApiExplorer(options =>
                {
                    // Add the versioned API Explorer, which also adds the
                    // IApiVersionDescriptionProvider service. The specified
                    // format code will format the version as "'v'major" like
                    // 'v1' or 'v2'.
                    // https://github.com/microsoft/aspnet-api-versioning/wiki/Version-Format
                    options.GroupNameFormat = "'v'V";

                    // note: this option is only necessary when versioning by url segment. the SubstitutionFormat
                    // can also be used to control the format of the API version in route templates
                    options.SubstituteApiVersionInUrl = true;
                })
            .AddControllers(opt =>
                {
                    opt.Conventions.Add(new RouteTokenTransformerConvention(new CamelCaseParameterTransformer()));
                })
            .AddJsonOptions(opt =>
                {
                    opt.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
                    opt.JsonSerializerOptions.Converters.Add(new JsonStringEnumMemberConverter(JsonNamingPolicy.CamelCase));
                })
            .AddNewtonsoftJson(opt =>
                {
                    opt.UseCamelCasing(processDictionaryKeys: true);
                    opt.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                });

        services
            .AddHealthChecks()
            .WithStandardReportFormat();

        services
            .NormalizeAspNetCoreTracingDisplayNames()
            .NormalizeHttpClientTracingDisplayNames()
            .IncludeIdentityWithTrace()
            .IgnoreTelemetryFromPaths("/favicon.ico", "/healthz", "/metrics")
            .AddOpenTelemetry()
            .WithMetrics(builder =>
                builder
                    .SetResourceBuilder(Configuration)
                    .AddStandardAspNetCoreMetrics())
            .WithTracing(builder =>
                builder
                    .SetResourceBuilder(Configuration)
                    .AddAspNetCoreInstrumentation()
                    .AddHttpClientInstrumentation()
                    .SetErrorStatusOnException()
                    .AddOtlpExporterIf(Configuration.IsOpenTelemetryTraceExporterEnabled)
                    .AddConsoleExporterIf(Configuration.IsConsoleTraceExporterEnabled))
            .StartWithHost();

        // Note: Use Istio to handle retry and circuit breaker as part of the
        // Envoy sidecar!
        services
            .AddHttpClient("GitHub", client =>
            {
                client.BaseAddress = new Uri("https://api.github.com/");
                client.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");
            })
            .AddHeaderPropagation();
    }
}

﻿using Autofac.Extensions.DependencyInjection;
using Serilog;

namespace Microservice.Template;

/// <summary>
/// Main entry point for the microservice.
/// </summary>
[ExcludeFromCodeCoverage]
public static class Program
{
    /// <summary>
    /// Creates the basic host builder that will become the microservice host.
    /// </summary>
    /// <param name="args">
    /// The command line arguments to provide to the host.
    /// </param>
    /// <returns>
    /// An <see cref="IHostBuilder"/> for continued configuration and execution.
    /// </returns>
    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .UseServiceProviderFactory(new AutofacServiceProviderFactory())
            .UseSerilog()
            .ConfigureWebHostDefaults(webBuilder => webBuilder.UseStartup<Startup>());

    /// <summary>
    /// Main entry point for execution of the microservice host.
    /// </summary>
    /// <param name="args">
    /// The command line arguments to provide to the host.
    /// </param>
    /// <returns>
    /// A <see cref="Task"/> to await completion of the program.
    /// </returns>
    public static async Task Main(string[] args)
    {
        await CreateHostBuilder(args).Build().RunAsync();
    }
}

﻿namespace Microservice.Template.Models;

/// <summary>
/// Model with information about a single GitHub repository.
/// </summary>
public class GitRepository
{
    /// <summary>
    /// Gets or sets the repository clone URL.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the URL that a git client would use
    /// to clone the repository.
    /// </value>
    public string? CloneUrl { get; set; }

    /// <summary>
    /// Gets or sets the repository description.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the human-readable description that
    /// outlines the purpose of the repository.
    /// </value>
    public string? Description { get; set; }

    /// <summary>
    /// Gets or sets the repository name.
    /// </summary>
    /// <value>
    /// A <see cref="string"/> with the full repository name as seen
    /// in GitHub.
    /// </value>
    public string? Name { get; set; }
}

namespace Microservice.Template.Controllers;

/// <summary>
/// Extension methods for logging GitHub actions.
/// </summary>
[ExcludeFromCodeCoverage]
internal static class GitHubLoggingExtensions
{
    private static readonly Action<ILogger, Exception?> ErrorGettingRepositories = LoggerMessage.Define(LogLevel.Error, new EventId(0), "Unable to retrieve GitHub organization repositories.");
    private static readonly Action<ILogger, Exception?> GettingRepositoryList = LoggerMessage.Define(LogLevel.Information, new EventId(0), "Getting repository list from GitHub organization.");

    /// <summary>
    /// Logs that an error occurred while reading repos from the GitHub API.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    /// <param name="ex">The error that occurred.</param>
    public static void LogErrorGettingRepositories(this ILogger logger, Exception ex)
    {
        ErrorGettingRepositories(logger, ex);
    }

    /// <summary>
    /// Logs that reading repos from the GitHub API has started.
    /// </summary>
    /// <param name="logger">The diagnostic logger.</param>
    public static void LogGettingRepositoryList(this ILogger logger)
    {
        GettingRepositoryList(logger, null);
    }
}

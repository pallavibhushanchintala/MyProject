﻿using System.Text.Json;
using Fiserv.Extensions.Logging;
using Microservice.Template.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace Microservice.Template.Controllers;

/// <summary>
/// API controller that provides GitHub repository information. Shows usage of
/// HTTP client to request data from a remote API.
/// </summary>
[ApiController]
[AllowAnonymous]
[ApiVersion("1")]
[Route("v{version:apiVersion}/[controller]")]
[Produces("application/json")]
public class GitHubController : ControllerBase
{
    private readonly IHttpClientFactory _clientFactory;

    private readonly IAggregateLogger<GitHubController> _logger;

    /// <summary>
    /// Initializes a new instance of the <see cref="GitHubController"/> class.
    /// </summary>
    /// <param name="logger">
    /// The <see cref="ILogger{T}"/> that can be used for diagnostic logging.
    /// </param>
    /// <param name="clientFactory">
    /// The <see cref="IHttpClientFactory"/> for generating REST clients.
    /// </param>
    public GitHubController(IAggregateLogger<GitHubController> logger, IHttpClientFactory clientFactory)
    {
        this._logger = logger ?? throw new ArgumentNullException(nameof(logger));
        this._clientFactory = clientFactory ?? throw new ArgumentNullException(nameof(clientFactory));
    }

    /// <summary>
    /// Gets the list of repositories in the GitHub organization.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with information about the repositories
    /// owned by the GitHub organization in GitHub.
    /// </returns>
    [HttpGet("repositories")]
    [SwaggerResponse(200, "Retrieves the list of git repositories for the GitHub organization.")]
    [SwaggerResponse(503, "Unable to get the list of repositories from GitHub.")]
    public async ValueTask<ActionResult<IEnumerable<GitRepository>>> GetRepositoriesAsync()
    {
        // This shows an example of how you might log an audit message. The
        // message will be written automatically when the 'audit' object is
        // disposed at the end of the method.
        using var audit = this._logger.AuditLogger.BeginAudit();
        audit.Action = ActionType.Fail;
        audit.Activity = ActivityType.Read;
        audit.Message = "Read GitHub repositories.";
        audit.Signature = SignatureType.User_Audit;

        var client = this._clientFactory.CreateClient("GitHub");
        this._logger.DiagnosticLogger.LogGettingRepositoryList();

        // This will automatically be handled by Polly circuit breaking policies.
        var response = await client.GetAsync("/orgs/github/repos");

        try
        {
            response.EnsureSuccessStatusCode();
            audit.Action = ActionType.Success;
        }
        catch (HttpRequestException ex)
        {
            // GitHub isn't responding so we're "service unavailable."
            this._logger.DiagnosticLogger.LogErrorGettingRepositories(ex);
            return this.StatusCode(503);
        }

        // This is just one way to parse - it's easy and fast but not pretty.
        // You can also use JsonSerializer.DeserializeAsync<T> to do model
        // binding to a strong-typed object.
        var responseStream = await response.Content.ReadAsStreamAsync();
        var source = await JsonDocument.ParseAsync(responseStream);
        var dest = new List<GitRepository>();
        foreach (var sourceRepo in source.RootElement.EnumerateArray())
        {
            var destRepo = new GitRepository
            {
                CloneUrl = sourceRepo.GetProperty("clone_url").GetString(),
                Description = sourceRepo.GetProperty("description").GetString(),
                Name = sourceRepo.GetProperty("full_name").GetString(),
            };
            dest.Add(destRepo);
        }

        audit.Count = dest.Count;
        return this.Ok(dest);
    }
}

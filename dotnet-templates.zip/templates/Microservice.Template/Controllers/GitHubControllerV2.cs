﻿using System.Text.Json;
using Microservice.Template.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace Microservice.Template.Controllers;

/// <summary>
/// Version 2 of an API controller that provides GitHub repository information. Shows usage of
/// versioning for an API.
/// </summary>
[ApiController]
[AllowAnonymous]
[ApiVersion("2")]
[Route("v{version:apiVersion}/[controller]")]
[Produces("application/json")]
public class GitHubControllerV2 : ControllerBase
{
    private readonly IHttpClientFactory _clientFactory;

    private readonly ILogger<GitHubController> _logger;

    /// <summary>
    /// Initializes a new instance of the <see cref="GitHubControllerV2"/> class.
    /// </summary>
    /// <param name="logger">
    /// The <see cref="ILogger{T}"/> that can be used for diagnostic logging.
    /// </param>
    /// <param name="clientFactory">
    /// The <see cref="IHttpClientFactory"/> for generating REST clients.
    /// </param>
    public GitHubControllerV2(ILogger<GitHubController> logger, IHttpClientFactory clientFactory)
    {
        this._logger = logger ?? throw new ArgumentNullException(nameof(logger));
        this._clientFactory = clientFactory ?? throw new ArgumentNullException(nameof(clientFactory));
    }

    /// <summary>
    /// Gets the top 5 repositories in the GitHub organization.
    /// </summary>
    /// <returns>
    /// An <see cref="IEnumerable{T}"/> with information about the repositories
    /// owned by the GitHub organization in GitHub.
    /// </returns>
    [HttpGet("repositories")]
    [SwaggerResponse(200, "Retrieves the list of git repositories for the GitHub organization.")]
    [SwaggerResponse(503, "Unable to get the list of repositories from GitHub.")]
    public async ValueTask<ActionResult<IEnumerable<GitRepository>>> GetRepositoriesAsync()
    {
        var client = this._clientFactory.CreateClient("GitHub");
        this._logger.LogGettingRepositoryList();

        // This will automatically be handled by Polly circuit breaking policies.
        var response = await client.GetAsync("/orgs/github/repos");

        try
        {
            response.EnsureSuccessStatusCode();
        }
        catch (HttpRequestException ex)
        {
            // GitHub isn't responding so we're "service unavailable."
            this._logger.LogErrorGettingRepositories(ex);
            return this.StatusCode(503);
        }

        // This is just one way to parse - it's easy and fast but not pretty.
        // You can also use JsonSerializer.DeserializeAsync<T> to do model
        // binding to a strong-typed object.
        var responseStream = await response.Content.ReadAsStreamAsync();
        var source = await JsonDocument.ParseAsync(responseStream);
        var dest = new List<GitRepository>();
        foreach (var sourceRepo in source.RootElement.EnumerateArray().Take(5))
        {
            var destRepo = new GitRepository
            {
                CloneUrl = sourceRepo.GetProperty("clone_url").GetString(),
                Description = sourceRepo.GetProperty("description").GetString(),
                Name = sourceRepo.GetProperty("full_name").GetString(),
            };
            dest.Add(destRepo);
        }

        return this.Ok(dest);
    }
}

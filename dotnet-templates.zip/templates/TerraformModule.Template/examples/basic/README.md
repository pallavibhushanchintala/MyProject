# Example: Basic Deployment

This example consumes the terraform-module-name module in the simplest manner.

# Terraform Module: terraform-module-name

**TODO:** Provide an overview of your Terraform module here. Explain at a high-level what it's intended to do.

## Usage

```hcl
module "terraform_module_name" {
  source      = "git::https://server/repo/?ref=vX.Y.Z"
  data_length = 10
}
```

**TODO:** Update the above HCL to show how to consume the module. Include some explanation here of major use cases or things folks should know about the variables if it's not clear from reading `variables.tf` and `outputs.tf`.

## Build and Test

The build script `build.ps1` can be used to format and validate the module.

```powershell
# Enable AutoFormat to format things for you during build.
# To check your formatting, leave -AutoFormat off.
./build.ps1 -AutoFormat
```

Tests can run from the `test` folder using Go.

```powershell
dep ensure
go test -v -timeout 90m .
```

The Azure Pipelines build requires some build task extensions to be installed in the Azure DevOps organization:

- [SetVersions](https://dev.azure.com/F-DC/Architecture/_git/pipeline-task-set-versions)
- [TerraformInstaller](https://marketplace.visualstudio.com/items?itemName=ms-devlabs.custom-terraform-tasks)
- [TFLintInstaller](https://dev.azure.com/F-DC/Architecture/_git/pipeline-task-tflint-installer)

### Visual Studio Code

The `test` folder has a Go module in it, which messes up the `gopls` language server because it [requires modules be in the root of the repo.](https://github.com/golang/vscode-go/issues/275). Go modules are generally assumed to be in the root because [multi-module repos are hard](https://github.com/golang/go/wiki/Modules#faqs--multi-module-repositories). Using Go modules in this Terraform repo, though, means you don't need to check the code out specifically under your `GOPATH`. It should still just work.

To work around this, the `module.code-workspace` is provided which opens the test module as a separate folder in the workspace. This [the allows build and test to work in VS Code.](https://github.com/golang/vscode-go/issues/529).

package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

// Using test stages allows you to skip long-running things like setup
// or teardown as you develop tests.
var stage = test_structure.RunTestStage

// Saves the provided Terraform options for later stages, initializes
// Terraform, and applies the configuration.
func apply(t *testing.T, dir string, opts *terraform.Options) {
	// Save data to disk so that other test stages executed at a later time can
	// read the data back in. This is useful if you use SKIP_stagename to ensure
	// it remains consistent. Test data gets stored in a .test-data folder
	// inside the specified location and should not be checked in.
	test_structure.SaveTerraformOptions(t, dir, opts)

	terraform.InitAndApply(t, opts)
}

// Tears down the deployed infrastructure components after tests are complete.
func destroy(t *testing.T, dir string) {
	opts := test_structure.LoadTerraformOptions(t, dir)
	defer terraform.Destroy(t, opts)
}

# Module Plan Generator

This test fixture is used for generating the plan output during the module continuous integration build. It has enough in place to create these items but is not unique/secure enough to actually deploy directly.

In live modules this is required so the remote state block in the module can be overridden. In a generic module this may be simplified by using a `testing.tfvars` file to generate the plan right from the top-level module, but to keep builds and practices standard a fixture was used here.

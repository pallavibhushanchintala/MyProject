package test

import (
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
	"github.com/stretchr/testify/assert"
)

// This is the example to run for testing.

func TestBasicExample(t *testing.T) {
	const exampleDir = "../examples/basic"

	t.Parallel()

	// Set up the options to use for the test.
	opts := &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: exampleDir,
	}

	// Using test stages allows you to skip long-running things like setup
	// or teardown as you develop tests.
	stage := test_structure.RunTestStage

	// Deploy the module. Setting SKIP_destroy or SKIP_apply will skip the
	// corresponding stage for easier local test development.
	defer stage(t, "destroy", func() { destroy(t, exampleDir) })
	stage(t, "apply", func() { apply(t, exampleDir, opts) })

	// Validate the module works. Setting SKIP_validate will skip
	// this so an apply/destroy cycle can be tested without failing
	// on assertions.
	stage(t, "validate", func() { validateBasicExample(t, exampleDir) })
}

func validateBasicExample(t *testing.T, dir string) {
	opts := test_structure.LoadTerraformOptions(t, dir)

	// TODO: Use the terraform object and assertions to test the module.
	randomValue := terraform.OutputRequired(t, opts, "random_value")
	assert.NotNil(t, randomValue)
	assert.Equal(t, 10, len(randomValue))
}

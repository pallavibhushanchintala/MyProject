<#
.SYNOPSIS
    Build/validation for the Terraform module.
.PARAMETER AutoFormat
    Enabling auto-format will format the module rather than failing the build on unformatted code.
#>
[CmdletBinding()]
Param(
    [Parameter()]
    [Switch]
    $AutoFormat
)

$check = If (-not $AutoFormat) { "-check" }
Write-Host "Executing recursive format."
&terraform fmt $check -recursive $PSScriptRoot
If ($LASTEXITCODE -ne 0) {
    If ($AutoFormat) {
        Throw "Error auto-formatting the module."
    }
    Else {
        Throw "Incorrectly formatted items found. Use -AutoFormat to fix."
    }
}

# Folders that contain modules directly underneath
$moduleContainers = @("$PSScriptRoot/examples", "$PSScriptRoot/modules", "$PSScriptRoot/test/fixtures")

# Get all the module folders that exist so each can be analyzed
$moduleFolders = @($PSScriptRoot)
$moduleFolders += $moduleContainers |
    Where-Object { Test-Path $_ } |
    ForEach-Object { Get-ChildItem -Path $_ -Directory | Select-Object -ExpandProperty FullName }

# Analysis for each module in turn
$moduleFolders | ForEach-Object {
    $module = $_
    Push-Location $module

    Try {
        Write-Host "Executing module validation process: $module"

        &terraform init -backend=false
        If ($LASTEXITCODE -ne 0) {
            Throw "Error during initialization - $module"
        }

        &terraform validate
        If ($LASTEXITCODE -ne 0) {
            Throw "Error during validation - $module"
        }

        &tflint --config $PSScriptRoot/.tflint.hcl
        If ($LASTEXITCODE -ne 0) {
            Throw "Error during linting - $module"
        }
    }
    Finally {
        Pop-Location
    }
}

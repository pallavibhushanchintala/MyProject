package test

import (
	"fmt"
	"strings"
	"testing"

	servicebus "github.com/Azure/azure-service-bus-go"
	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"

	test_structure "github.com/gruntwork-io/terratest/modules/test-structure"
)

func TestBasicExample(t *testing.T) {
	const exampleDir = "../examples/basic"
	t.Parallel()

	uniqueID := strings.ToLower(random.UniqueId())
	opts := &terraform.Options{
		TerraformDir: exampleDir,

		Vars: map[string]interface{}{
			"location":                  "westus2",
			"resource_group_name_base":  fmt.Sprintf("test%s", uniqueID),
			"servicebus_namespace_base": fmt.Sprintf("test%s", uniqueID),
		},
	}

	// Deploy the cluster. Setting SKIP_destroy or SKIP_apply will
	// skip the corresponding stage for easier local test development.
	defer stage(t, "destroy", func() { destroy(t, exampleDir) })
	stage(t, "apply", func() { apply(t, exampleDir, opts) })

	// Validate the cluster works. Setting SKIP_validate will skip
	// this so an apply/destroy cycle can be tested without failing
	// on assertions.
	stage(t, "validate", func() { validateBasicExample(t, exampleDir) })
}

func validateBasicExample(t *testing.T, dir string) {
	opts := test_structure.LoadTerraformOptions(t, dir)
	serviceBusId := strings.Trim(terraform.OutputRequired(t, opts, "id"), "\"")
	primaryConnectionKey := strings.Trim(terraform.OutputRequired(t, opts, "primary_connection_string"), "\"")
	sharedAccessKey := "SharedAccessKeyName=RootManageSharedAccessKey"
	serviceBusName := opts.Vars["servicebus_namespace_base"].(string)
	assert.True(t, strings.Index(serviceBusId, serviceBusName) > 0, "The Service Bus ID should end with the Service Bus name.")
	assert.True(t, len(primaryConnectionKey) != 0)
	assert.True(t, strings.Contains(primaryConnectionKey, sharedAccessKey))
	ns, err := servicebus.NewNamespace(servicebus.NamespaceWithConnectionString(primaryConnectionKey))
	if err != nil {
		t.Fatalf("unexpected error accessing Service Bus namespace: %s", err)
	}

	if ns == nil {
		t.Fatalf("unexpected error accessing Service Bus namespace: %s", "empty namespace")
	}

	assert.Equal(t, ns.Name, serviceBusName, "The namespace name was incorrect.")
	assert.Equal(t, ns.Suffix, "servicebus.windows.net", "The namespace suffix was incorrect.")
}

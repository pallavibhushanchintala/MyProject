# Digital Nexus Environment Module: Service Bus

This module deploys a Azure Service Bus namespace in the format expected for [Digital Nexus infrastructure](https://F-DC@dev.azure.com/F-DC/Digital%20Nexus/_git/nexus-infrastructure). It is not intended to be reused across products or systems. See the [Terraform Module Guidelines](https://dev.azure.com/F-DC/Infrastructure/_wiki/wikis/Infrastructure/129/Terraform-Module-Guidelines) for an overview of the difference between a 'generic module' and an 'environment module.'

## Development

You need:

- Terraform (Version specified in `azure-pipelines.yml`)
- tflint (Version specified in `azure-pipelines.yml`)
- Go
- PowerShell

Running `build.ps1` will do lint and general validation of the module.

### Azure Connection Configuration

If you want to run the tests, Terraform and the Azure SDK for Go both need subscription and credential information provided via environment variables.

| Terraform Provider Variable | Azure SDK for Go Variable | Description |
| ---                   | ---                     | --- |
| `ARM_CLIENT_ID`       | `AZURE_CLIENT_ID`       | The application ID for the service principal. This is a GUID. |
| `ARM_CLIENT_SECRET`   | `AZURE_CLIENT_SECRET`   | The password for the service principal. |
| `ARM_TENANT_ID`       | `AZURE_TENANT_ID`       | The tenant ID to which the service principal belongs. This is a GUID. |
| `ARM_SUBSCRIPTION_ID` | `AZURE_SUBSCRIPTION_ID` | The subscription ID into which test objects are deployed. This is a GUID. |

You'll need a personal service principal that has rights to deploy the module. You can set that up using the following commands. Note the subscription here is the R&D subscription, and the GUID used here is also used in the filename of the `env` file expected by the VS Code `launch.json`.

```powershell
# Target subscription - ARM_SUBSCRIPTION_ID / AZURE_SUBSCRIPTION_ID
$subscription = "35abf82e-a23b-49c4-8bae-88baead6f7d3"

# The 'app name' is a friendly name that can
# be used for managing service principals. Try
# to make it easy to understand.
$appName = "$($env:USERNAME) Azure CLI"
az login
az account set --subscription $subscription
az ad sp create-for-rbac --name $appName
```

Take note of the principal ID, secret, and tenant ID that is shown. These are the `CLIENT_ID`, `CLIENT_SECRET`, and `TENANT_ID` environment variables, respectively.

Create a text file called `azure-tf-35abf82e-a23b-49c4-8bae-88baead6f7d3.env` in your user profile folder (`/Users/yourname` or `C:\Users\yourname`) that has the credentials in it like below. This file will be used by the `launch.json` in VS Code. (Naming it with the subscription ID allows you to work on different modules from different subscriptions.)

```text
# azure-tf-35abf82e-a23b-49c4-8bae-88baead6f7d3.env

# Subscription ID:
ARM_SUBSCRIPTION_ID=35abf82e-a23b-49c4-8bae-88baead6f7d3
AZURE_SUBSCRIPTION_ID=35abf82e-a23b-49c4-8bae-88baead6f7d3

# Tenant ID (both shown after the command line and available in the Azure portal)
ARM_TENANT_ID=a172c77d-91cf-47f0-a813-30aee710c0dc
AZURE_TENANT_ID=a172c77d-91cf-47f0-a813-30aee710c0dc

# This is the principal ID that was generated:
ARM_CLIENT_ID=2243f121-2d82-4ed6-870b-355731390c0f
AZURE_CLIENT_ID=2243f121-2d82-4ed6-870b-355731390c0f

# This is the secret that was generated:
ARM_CLIENT_SECRET=ee+uysb01gAXLE8832mfksuynnvlsaSHJXe555H2VKUE=
AZURE_CLIENT_SECRET=ee+uysb01gAXLE8832mfksuynnvlsaSHJXe555H2VKUE=
```

### Run Tests

Tests can be run from the command line:

```powershell
# Run all the tests
cd test
go test -v -timeout 60m

# Run a specific test
cd test
go test -v -timeout 60m -run NameOfTest
```

### Visual Studio Code

The `test` folder has a Go module in it, which messes up the `gopls` language server because it [requires modules be in the root of the repo.](https://github.com/golang/vscode-go/issues/275). Go modules are generally assumed to be in the root because [multi-module repos are hard](https://github.com/golang/go/wiki/Modules#faqs--multi-module-repositories). Using Go modules in this Terraform repo, though, means you don't need to check the code out specifically under your `GOPATH`. It should still just work.

To work around this, the `module.code-workspace` is provided which opens the test module as a separate folder in the workspace. This [the allows build and test to work in VS Code.](https://github.com/golang/vscode-go/issues/529).

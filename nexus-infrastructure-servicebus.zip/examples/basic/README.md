# Service Bus Example: Basic

This example shows basic consumption of the Service Bus module. It creates a resource group then deploys the Service Bus module into that resource group.

# Diagnostics and Troubleshooting Container

This builds a customized Ubuntu container that has troubleshooting and diagnostics tooling. This is required for troubleshooting inside the commercial tenant since the network connectivity there is restricted and tooling can't be installed.

## Available Tools

- `entrypoint.sh` script to ensure it can run in Kubernetes context
- PowerShell
- Azure `az` CLI
- Kubernetes `kubectl` CLI
- Python (2 and 3)
- openssl
- wget
- curl
- sftp
- vim
- nano
- net-tools
- traceroute
- telnet

## Usage

The entrypoint is a `sleep` command. The intended usage is to `kubectl exec` to get a running shell.

First, deploy the pod. This is done with a `deployment` instead of a `pod` to allow for the potential for Istio to inject a sidecar. Istio doesn't inject into a `pod` directly.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: diagnostics
  namespace: my-namespace
spec:
  replicas: 1
  selector:
    matchLabels:
      app: diagnostics
  template:
    metadata:
      labels:
        app: diagnostics
    spec:
      containers:
      - name: diagnostics
        image: acrdsl1centralus.azurecr.io/digital-nexus/diagnostics:latest
        imagePullPolicy: Always
```

Once the deployment is running, you can get a shell. Locate the pods via the `selector` from the deployment:

```powershell
$pod = kubectl get pods -n my-namespace -l=app=diagnostics -o jsonpath='{.items[0].metadata.name}'

# Get PowerShell. Use /bin/bash instead if you want Bash.
kubectl exec --stdin --tty $pod -n my-namespace -c diagnostics -- /usr/bin/pwsh
```

**Don't forget to remove the deployment when you're done.**

```powershell
kubectl delete deployment/diagnostics -n my-namespace
```

## Build and Test

The `Invoke-DevBuild.ps1` script will execute a container build then will run a script in the container to check for a subset of the installed tools. If any are missing, an error will be written to note which weren't found. The report of the tools will be in the `artifacts` folder. You can use the `Invoke-ShellInContainer.ps1` script to get a PowerShell session in the container you just built so you an verify anything additional or troubleshoot setup.

If you add a tool that should be verified, also update the `Get-InstalledTools.ps1` script - this is what's used to generate the report.

The VS Code integration is set up to run `Invoke-DevBuild.ps1` as the default build action.

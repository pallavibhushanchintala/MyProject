﻿<#
.SYNOPSIS
    Runs a local dev build to test container changes.
.DESCRIPTION
    Builds and tests a local version of the container. Represents a smaller
    version of what happens in the matrix pipeline.
.EXAMPLE
    ./Invoke-DevBuild.ps1
#>
[CmdletBinding()]
Param(
)

$tag = "diagnostics-local"
&docker build -t $tag --build-arg GIT_COMMIT=local --build-arg GIT_REPO=local .

New-Item "artifacts/log" -ItemType Directory -Force | Out-Null
&docker run --name "test-diagnostics-local" --rm -d $tag
$results = docker exec -i test-diagnostics-local /usr/bin/pwsh -NoProfile -File /usr/bin/Get-InstalledTools.ps1
$results | Out-File -FilePath "artifacts/log/installed-tools.json"
&docker stop "test-diagnostics-local"

$results = $results | ConvertFrom-Json
If ($results.Missing.Length -gt 0) {
    Write-Error "Missing $($results.Missing.Length) tool(s)."
    $results.Missing | ForEach-Object { Write-Error "- $_" }
}
Else {
    Write-Output "All tools installed."
}

﻿<#
.SYNOPSIS
    Gets a shell in a previously built dev container for local testing.
.DESCRIPTION
    Gets a running PowerShell session in the `diagnostics-local` container that
    was built by the dev build. Useful for local testing of tools.
.EXAMPLE
    ./Invoke-DevBuild.ps1
    ./Invoke-ShellInContainer.ps1
#>
[CmdletBinding()]
Param(
)
&docker run --rm -d --name vscode-diagnostics-local diagnostics-local
&docker exec -it vscode-diagnostics-local /usr/bin/pwsh
&docker stop vscode-diagnostics-local

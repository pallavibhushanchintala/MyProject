<#
.SYNOPSIS
    Lists information about the installed tools in the container. Used for
    validating the set of tools from the custom install.
.DESCRIPTION
    Gets a JSON-formatted document that can be used to validate whether all the
    tools in the diagnostics image were successfully installed.
#>
[CmdletBinding(SupportsShouldProcess = $False)]
Param(
)
Begin {
    $ToolsToCheck = @(
        @{
            "Name"        = "Bash"
            "Command"     = "bash"
            "VersionTest" = { ((bash --version) -join ' ') -match 'version ([^ ]+) ' | Out-Null; $Matches[1] }
        },
        @{
            "Name"        = "Curl"
            "Command"     = "curl"
            "VersionTest" = { ((curl -V) -join ' ') -match 'curl ([^ ]+) ' | Out-Null; $Matches[1] }
        },
        @{
            "Name"        = "Wget"
            "Command"     = "wget"
            "VersionTest" = { ((wget -V) -join ' ') -match 'Wget ([^ ]+) ' | Out-Null; $Matches[1] }
        },
        @{
            "Name"        = "PowerShell"
            "Command"     = "pwsh"
            "VersionTest" = { $PSVersionTable.PSVersion.ToString() }
        },
        @{
            "Name"        = "Azure CLI"
            "Command"     = "az"
            "VersionTest" = { (az version | ConvertFrom-Json)."azure-cli" }
        },
        @{
            "Name"        = "Kubectl"
            "Command"     = "kubectl"
            "VersionTest" = { (kubectl version --client -o json | ConvertFrom-Json).clientVersion.gitVersion }
        },
        @{
            "Name"        = "OpenSSL"
            "Command"     = "openssl"
            "VersionTest" = { openssl version }
        },
        @{
            "Name"        = "SFTP"
            "Command"     = "sftp"
            "VersionTest" = { "0.0.0" } # no great way to get version
        }
    )
}
Process {
    $installed = New-Object System.Collections.ArrayList
    $missing = New-Object System.Collections.ArrayList
    ForEach ($tool in $ToolsToCheck) {
        $command = Get-Command $tool.Command -ErrorAction Ignore
        If ($Null -eq $command) {
            $missing.Add($tool.Name) | Out-Null
        }
        Else {
            $version = Invoke-Command -ScriptBlock $tool.VersionTest
            $info = @{
                "Name"    = $command.Name
                "Source"  = $command.Source
                "Version" = $version
            }
            $installed.Add($info) | Out-Null
        }
    }

    $result = @{
        "Installed" = $installed
        "Missing"   = $missing
    }

    $result | ConvertTo-Json
}

#!/bin/sh
# The container finishes but the Istio sidecar stays alive so we have to
# manually exit or the job never finishes. To support local running, we only do
# this if the Kubernetes service account mount is present.
# https://github.com/istio/istio/issues/11659
if [ -d "/var/run/secrets/kubernetes.io/serviceaccount" ]; then
  echo "Running in Kubernetes context, will end Istio sidecar when finished."
  trap "curl --max-time 2 -s -f -XPOST http://127.0.0.1:15020/quitquitquit" EXIT
  while ! curl -s -f http://127.0.0.1:15020/healthz/ready; do sleep 1; done
fi

# Sleep for 10 years. The container is supposed to just sit and wait for an
# interactive shell.
/bin/sleep 3650d
